use DAOB;
insert into Roles(Id, Name) Values ('111ecccc-6fce-4b9f-a492-746c6c8a1bfa', 0);
insert into Roles(Id, Name) Values ('111ecccc-6fce-4b9f-a492-746c6c8a1bfb', 1);
insert into Roles(Id, Name) Values ('111ecccc-6fce-4b9f-a492-746c6c8a1bfc', 2);
insert into Roles(Id, Name) Values ('111ecccc-6fce-4b9f-a492-746c6c8a1bfd', 3);
insert into Roles(Id, Name) Values ('111ecccc-6fce-4b9f-a492-746c6c8a1bfe', 4);

insert into Users (Id, UserName, Password, FirstName, LastName, PhoneNumber, Role_Id)
values('ddddcccc-6fce-4b9f-a492-746c6c8a1bfa', 'admin', 'pass', 'testadmin', 'user', '09090909', '111ecccc-6fce-4b9f-a492-746c6c8a1bfa');