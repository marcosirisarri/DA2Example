﻿using System;
using System.Collections.Generic;

namespace DAOB.Logger.Definition
{
    public abstract class LogBase
    {
        public const char SEPARATOR = '|';

        public abstract void AddEntry(LogEntry entry);
        public abstract ICollection<LogEntry> GetLogsBetweenDates(DateTime starDate, DateTime endDate);
    }
}
