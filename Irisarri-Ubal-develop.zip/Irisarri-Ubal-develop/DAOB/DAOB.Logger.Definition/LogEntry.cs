﻿using System;

namespace DAOB.Logger.Definition
{
    public class LogEntry
    {
        public Guid Id { get; set; }
        public DateTime DateTime { get; set; }
        public string UserName { get; set; }
        public LogAction Action { get; set; }
        public string Message { get; set; }

        public override string ToString()
        {
            string logAction = GetActionName(Action);
            return $"{DateTime} {LogBase.SEPARATOR} {UserName} {LogBase.SEPARATOR} {logAction} {LogBase.SEPARATOR} {Message}";
        }

        private string GetActionName(LogAction action)
        {
            string actionName;
            switch(action)
            {
                case LogAction.UserLogin:
                    actionName = "Login";
                    break;
                case LogAction.VehicleImport:
                    actionName = "Vehicle import";
                    break;
                default:
                    throw new InvalidOperationException("Undefined log action");
            }

            return actionName;
        }

        public LogAction GetAction(string action)
        {
            LogAction actionEnum;
            switch (action)
            {
                case "Login":
                    actionEnum = LogAction.UserLogin;
                    break;
                case "Vehicle import":
                    actionEnum = LogAction.VehicleImport;
                    break;
                default:
                    throw new InvalidOperationException("Undefined log action");
            }

            return actionEnum;
        }
    }
}
