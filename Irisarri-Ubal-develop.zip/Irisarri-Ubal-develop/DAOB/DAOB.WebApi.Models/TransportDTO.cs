﻿using System;
using System.Collections.Generic;

namespace DAOB.WebApi.Models
{
    public class TransportDTO
    {
        public Guid Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public Guid CarrierId { get; set; }
        public virtual ICollection<Guid> LotIds { get; set; }
    }
}
