﻿using System;

namespace DAOB.WebApi.Models
{
    public class Base64ImageDTO
    {
        public Guid Id { get; set; }
        public string Base64EncodedImage { get; set; }
    }
}
