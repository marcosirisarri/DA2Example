﻿using System;

namespace DAOB.WebApi.Models
{
    public abstract class SuperZoneDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int MaxCapacity { get; set; }
    }
}
