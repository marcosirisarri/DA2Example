﻿using System;
using System.Collections.Generic;

namespace DAOB.WebApi.Models
{
    public class InspectionDTO
    {
        public Guid Id { get; set; }
        public DateTime DateTime { get; set; }
        public string Place { get; set; }
        public Guid VehicleId { get; set; }
        public Guid InspectorId { get; set; }
        public virtual ICollection<DamageDTO> Damages { get; set; }
        public InspectionTypes Type { get; set; }
    }
}
