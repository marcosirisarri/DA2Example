﻿namespace DAOB.WebApi.Models
{
    public class SubzoneDTO : SuperZoneDTO
    {
    }
}
