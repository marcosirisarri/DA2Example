﻿using System;

namespace DAOB.WebApi.Models
{
    public class SessionDTO
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
    }
}
