﻿using System;
using System.Collections.Generic;

namespace DAOB.WebApi.Models
{
    public class LotDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        //public LotState Status { get; set; }
        public Guid CarrierId { get; set; }
        public Guid CreatedById { get; set; }
        public ICollection<Guid> VehicleIds { get; set; }
        //public Guid TransportId { get; set; }
    }
}
