﻿using System;

namespace DAOB.WebApi.Models
{
    public class VehicleDTO
    {
        public Guid Id { get; set; }
        public string VIN { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
        public VehicleType Type { get; set; }
    }
}
