﻿using System;
using System.Collections.Generic;

namespace DAOB.WebApi.Models
{
    public class DamageDTO
    {
        public Guid Id { get; set; }
        public string Description { get; set; }
        public virtual ICollection<Base64ImageDTO> Images { get; set; }
    }
}
