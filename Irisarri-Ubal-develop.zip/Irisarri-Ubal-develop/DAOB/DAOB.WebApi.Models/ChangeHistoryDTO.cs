﻿using System;

namespace DAOB.WebApi.Models
{
    public class ChangeHistoryDTO
    {
        public Guid Id { get; set; }
        public DateTime Datetime { get; set; }
        public string Description { get; set; }
    }
}
