﻿using System;
using System.Collections.Generic;

namespace DAOB.WebApi.Models
{
    public class ZoneDTO : SuperZoneDTO
    {
        public ICollection<Guid> SubzoneIds { get; set; }
    }
}
