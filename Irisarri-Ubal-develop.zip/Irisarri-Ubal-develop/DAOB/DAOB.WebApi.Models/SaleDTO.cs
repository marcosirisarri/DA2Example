﻿using System;

namespace DAOB.WebApi.Models
{
    public class SaleDTO
    {
        public Guid Id { get; set; }
        public Guid SalesmanId { get; set; }
        public Guid VehicleId { get; set; }
        public Guid BuyerId { get; set; }
        public decimal Price { get; set; }
    }
}
