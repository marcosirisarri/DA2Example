﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class InspectionsDataTransfer : IInspectionsDataTransfer
    {
        private IInspectionsBusinessLogic inspectionsBusinessLogic;
        private IVehiclesBusinessLogic vehiclesBusinessLogic;
        private IUsersBusinessLogic usersBusinessLogic;

        public InspectionsDataTransfer(IInspectionsBusinessLogic inspectionsBusinessLogic, IVehiclesBusinessLogic vehiclesBusinessLogic,
             IUsersBusinessLogic usersBusinessLogic)
        {
            this.inspectionsBusinessLogic = inspectionsBusinessLogic;
            this.vehiclesBusinessLogic = vehiclesBusinessLogic;
            this.usersBusinessLogic = usersBusinessLogic;
        }

        public ICollection<InspectionDTO> GetAllInspections(Guid sessionToken)
        {
            ICollection<Inspection> inspections = inspectionsBusinessLogic.GetAllInspections(sessionToken);
            return InspectionsToDTOs(inspections);
        }

        public InspectionDTO GetById(Guid id, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            Inspection inspection = inspectionsBusinessLogic.GetById(id, sessionToken);
            return InspectionToDTO(inspection);
        }

        public void Add(InspectionDTO inspection, Guid sessionToken)
        {
            if (inspection == null)
            {
                throw new ArgumentNullException(nameof(inspection));
            }
            Inspection newInspection = DTOtoInspection(inspection, sessionToken);
            inspectionsBusinessLogic.Add(newInspection, sessionToken);
        }
        
        private Inspection DTOtoInspection(InspectionDTO inspection, Guid sessionToken)
        {
            if (inspection == null)
            {
                return null;
            }

            Inspection newInspection = new Inspection();
            newInspection.Id = inspection.Id;
            newInspection.DateTime = inspection.DateTime;
            newInspection.Place = inspection.Place;
            newInspection.Vehicle = vehiclesBusinessLogic.GetById(inspection.VehicleId, sessionToken);
            newInspection.Inspector = usersBusinessLogic.GetById(inspection.InspectorId, sessionToken);
            newInspection.Damages = DTOsToDamages(inspection.Damages);
            newInspection.Type = inspection.Type;

            return newInspection;
        }

        private InspectionDTO InspectionToDTO(Inspection inspection)
        {
            if (inspection == null)
            {
                return null;
            }

            InspectionDTO newInspection = new InspectionDTO();
            newInspection.Id = inspection.Id;
            newInspection.DateTime = inspection.DateTime;
            newInspection.Place = inspection.Place;
            newInspection.VehicleId = inspection.Vehicle.Id;
            newInspection.InspectorId = inspection.Inspector.Id;
            newInspection.Damages = DamagesToDTOs(inspection.Damages);
            newInspection.Type = inspection.Type;

            return newInspection;
        }

        private ICollection<InspectionDTO> InspectionsToDTOs(ICollection<Inspection> inspections)
        {
            ICollection<InspectionDTO> dtos = new List<InspectionDTO>();
            foreach (Inspection inspection in inspections)
            {
                InspectionDTO inspectionDTO = InspectionToDTO(inspection);
                dtos.Add(inspectionDTO);
            }

            return dtos;
        }

        private ICollection<DamageDTO> DamagesToDTOs(ICollection<Damage> damages)
        {
            ICollection<DamageDTO> dtos = new List<DamageDTO>();
            foreach (Damage damage in damages)
            {
                DamageDTO damageDTO = DamageToDTO(damage);
                dtos.Add(damageDTO);
            }

            return dtos;
        }

        private DamageDTO DamageToDTO(Damage damage)
        {
            if (damage == null)
            {
                return null;
            }

            DamageDTO newDamage = new DamageDTO();
            newDamage.Id = damage.Id;
            newDamage.Description = damage.Description;
            newDamage.Images = ImagesToDTOs(damage.Images);
            
            return newDamage;
        }

        private ICollection<Base64ImageDTO> ImagesToDTOs(ICollection<Base64Image> images)
        {
            ICollection<Base64ImageDTO> dtos = new List<Base64ImageDTO>();
            foreach (Base64Image image in images)
            {
                Base64ImageDTO imageDTO = ImageToDTO(image);
                dtos.Add(imageDTO);
            }

            return dtos;
        }

        private Base64ImageDTO ImageToDTO(Base64Image image)
        {
            if (image == null)
            {
                return null;
            }

            Base64ImageDTO newImage = new Base64ImageDTO();
            newImage.Id = image.Id;
            newImage.Base64EncodedImage = image.Base64EncodedImage;

            return newImage;
        }

        private ICollection<Damage> DTOsToDamages(ICollection<DamageDTO> dtos)
        {
            if (dtos == null)
            {
                return null;
            }

            ICollection<Damage> damages = new List<Damage>();
            foreach (DamageDTO damageDTO in dtos)
            {
                Damage damage = DTOtoDamage(damageDTO);
                damages.Add(damage);
            }

            return damages;
        }

        private Damage DTOtoDamage(DamageDTO damageDTO)
        {
            if (damageDTO == null)
            {
                return null;
            }

            Damage newDamage = new Damage();
            newDamage.Id = damageDTO.Id;
            newDamage.Description = damageDTO.Description;
            newDamage.Images = DTOsToImages(damageDTO.Images);

            return newDamage;
        }

        private ICollection<Base64Image> DTOsToImages(ICollection<Base64ImageDTO> dtos)
        {
            if (dtos == null)
            {
                return null;
            }

            ICollection<Base64Image> images = new List<Base64Image>();
            foreach (Base64ImageDTO imageDTO in dtos)
            {
                Base64Image image = DTOtoImage(imageDTO);
                images.Add(image);
            }

            return images;
        }

        private Base64Image DTOtoImage(Base64ImageDTO imageDTO)
        {
            if (imageDTO == null)
            {
                return null;
            }

            Base64Image newImage = new Base64Image();
            newImage.Id = imageDTO.Id;
            newImage.Base64EncodedImage = imageDTO.Base64EncodedImage;

            return newImage;
        }
    }
}
