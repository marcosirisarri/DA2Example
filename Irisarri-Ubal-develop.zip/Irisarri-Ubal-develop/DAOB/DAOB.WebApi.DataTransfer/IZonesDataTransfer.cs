﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface IZonesDataTransfer
    {
        ICollection<ZoneDTO> GetAllZones(Guid sessionToken);
        ZoneDTO GetByName(string name, Guid sessionToken);
        void Add(ZoneDTO newZone, Guid sessionToken);
        bool Update(Guid id, ZoneDTO updatedZone, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}
