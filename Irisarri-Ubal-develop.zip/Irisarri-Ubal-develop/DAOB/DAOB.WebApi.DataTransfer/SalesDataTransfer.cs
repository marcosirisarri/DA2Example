﻿using System;
using DAOB.WebApi.Models;

namespace DAOB.WebApi.DataTransfer
{
    public class SalesDataTransfer : ISalesDataTransfer
    {
        public void Add(SaleDTO newSale, Guid sessionToken)
        {
            throw new NotImplementedException();
        }
    }
}
