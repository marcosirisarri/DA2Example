﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface ILotsDataTransfer
    {
        void Add(LotDTO newLot, Guid sessionToken);
        ICollection<LotDTO> GetAllLots(Guid sessionToken);
        LotDTO GetById(Guid id, Guid sessionToken);
        LotDTO GetByName(string name, Guid sessionToken);
        ICollection<LotDTO> GetReadyToDepartLots(Guid sessionToken);
    }
}
