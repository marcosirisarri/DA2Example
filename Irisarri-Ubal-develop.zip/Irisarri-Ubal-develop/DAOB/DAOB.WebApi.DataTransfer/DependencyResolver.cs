﻿using DAOB.DependencyResolver;
using System.ComponentModel.Composition;

namespace DAOB.WebApi.DataTransfer
{
    [Export(typeof(IComponent))]
    public class DependencyResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<IChangeHistoryDataTransfer, ChangeHistoryDataTransfer>();
            registerComponent.RegisterType<IInspectionsDataTransfer, InspectionsDataTransfer>();
            registerComponent.RegisterType<ILotsDataTransfer, LotsDataTransfer>();
            registerComponent.RegisterType<ISalesDataTransfer, SalesDataTransfer>();
            registerComponent.RegisterType<ISessionsDataTransfer, SessionsDataTransfer>();
            registerComponent.RegisterType<ISubzonesDataTransfer, SubzonesDataTransfer>();
            registerComponent.RegisterType<ITransportsDataTransfer, TransportsDataTransfer>();
            registerComponent.RegisterType<IUsersDataTransfer, UsersDataTransfer>();
            registerComponent.RegisterType<IVehiclesDataTransfer, VehiclesDataTransfer>();
            registerComponent.RegisterType<IZonesDataTransfer, ZonesDataTransfer>();
        }
    }
}
