﻿using DAOB.WebApi.Models;
using System;

namespace DAOB.WebApi.DataTransfer
{
    public interface ISalesDataTransfer
    {
        void Add(SaleDTO newSale, Guid sessionToken);
    }
}
