﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface IVehiclesDataTransfer
    {
        ICollection<VehicleDTO> GetAllVehicles(Guid sessionToken);
        VehicleDTO GetByVIN(string VIN, Guid sessionToken);
        void Add(VehicleDTO newVehicle, Guid sessionToken);
        bool Update(Guid id, VehicleDTO updatedVehicle, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}
