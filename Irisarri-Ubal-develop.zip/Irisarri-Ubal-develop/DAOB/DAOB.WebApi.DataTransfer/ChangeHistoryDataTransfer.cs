﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class ChangeHistoryDataTransfer : IChangeHistoryDataTransfer
    {
        public IChangeHistoryBusinessLogic changeHistoryBusinessLogic;

        public ChangeHistoryDataTransfer(IChangeHistoryBusinessLogic changeHistoryBusinessLogic)
        {
            this.changeHistoryBusinessLogic = changeHistoryBusinessLogic;
        }

        public ICollection<ChangeHistoryDTO> Get(Guid id)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            ICollection<ChangeHistory> changeHistories = changeHistoryBusinessLogic.Get(id);
            return ChangeHistoriesToDTOs(changeHistories);
        }

        private ChangeHistoryDTO ChangeHistoryToDTO(ChangeHistory changeHistory)
        {
            if (changeHistory == null)
            {
                return null;
            }

            ChangeHistoryDTO newChangeHistory = new ChangeHistoryDTO();
            newChangeHistory.Id = changeHistory.Id;
            newChangeHistory.Datetime = changeHistory.Datetime;
            newChangeHistory.Description = changeHistory.Description;
            
            return newChangeHistory;
        }

        private ICollection<ChangeHistoryDTO> ChangeHistoriesToDTOs(ICollection<ChangeHistory> changeHistories)
        {
            ICollection<ChangeHistoryDTO> dtos = new List<ChangeHistoryDTO>();
            foreach (ChangeHistory changeHistory in changeHistories)
            {
                ChangeHistoryDTO changeHistoryDTO = ChangeHistoryToDTO(changeHistory);
                dtos.Add(changeHistoryDTO);
            }

            return dtos;
        }
    }
}
