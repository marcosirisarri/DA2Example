﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class UsersDataTransfer : IUsersDataTransfer
    {
        private IUsersBusinessLogic usersBusinessLogic;

        public UsersDataTransfer(IUsersBusinessLogic usersBusinessLogic)
        {
            this.usersBusinessLogic = usersBusinessLogic;
        }

        public ICollection<UserDTO> GetAllUsers(Guid sessionToken)
        {
            ICollection<User> users = usersBusinessLogic.GetAllUsers(sessionToken);
            ICollection<UserDTO> usersDTO = new List<UserDTO>();
            foreach (User user in users)
            {
                UserDTO userDTO = UserToDTO(user);
                usersDTO.Add(userDTO);
            }
            return usersDTO;
        }

        public UserDTO GetByUserName(string userName, Guid sessionToken)
        {
            if (userName == null)
            {
                throw new ArgumentNullException(nameof(userName));
            }
            User user = usersBusinessLogic.GetByUserName(userName, sessionToken);
            return UserToDTO(user);
        }

        public void Add(UserDTO user, Guid sessionToken)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            User newUser = DTOtoUser(user);
            if (newUser.Role == null)
            {
                throw new ArgumentException("Selected role does not exist");
            }
            usersBusinessLogic.Add(newUser, sessionToken);
        }

        public bool Update(Guid id, UserDTO user, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            User updatedUser = DTOtoUser(user);
            if (updatedUser.Role == null)
            {
                throw new ArgumentException("Selected role does not exist");
            }
            return usersBusinessLogic.Update(id, updatedUser, sessionToken);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            return usersBusinessLogic.Delete(id, sessionToken);
        }
        
        private User DTOtoUser(UserDTO user)
        {
            if (user == null)
            {
                return null;
            }

            User newUser = new User();
            newUser.Id = user.Id;
            newUser.UserName = user.UserName;
            newUser.Password = user.Password;
            newUser.FirstName = user.FirstName;
            newUser.LastName = user.LastName;
            newUser.PhoneNumber = user.PhoneNumber;
            newUser.Role = usersBusinessLogic.GetRoleById(user.RoleId);

            return newUser;
        }

        private UserDTO UserToDTO(User user)
        {
            if (user == null)
            {
                return null;
            }

            UserDTO newUser = new UserDTO();
            newUser.Id = user.Id;
            newUser.UserName = user.UserName;
            newUser.Password = user.Password;
            newUser.FirstName = user.FirstName;
            newUser.LastName = user.LastName;
            newUser.PhoneNumber = user.PhoneNumber;
            newUser.RoleId = user.Role.Id;

            return newUser;
        }
    }
}
