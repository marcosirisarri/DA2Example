﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface IChangeHistoryDataTransfer
    {
        ICollection<ChangeHistoryDTO> Get(Guid id);
    }
}
