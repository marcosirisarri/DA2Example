﻿using DAOB.WebApi.Models;

namespace DAOB.WebApi.DataTransfer
{
    public interface ISessionsDataTransfer
    {
        SessionDTO Add(UserDTO user);
    }
}
