﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface ISubzonesDataTransfer
    {
        ICollection<SubzoneDTO> GetAllSubzones(Guid sessionToken);
        SubzoneDTO GetById(Guid id, Guid sessionToken);
        SubzoneDTO GetByName(string name, Guid sessionToken);
        void Add(SubzoneDTO newSubzone, Guid sessionToken);
        bool Update(Guid id, SubzoneDTO updatedSubzone, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}
