﻿using DAOB.WebApi.Models;
using System;

namespace DAOB.WebApi.DataTransfer
{
    public interface ITransportsDataTransfer
    {
        void Add(TransportDTO newTransport, Guid sessionToken);
        bool MarkAsFinished(Guid id, DateTime endDate, Guid sessionToken);
    }
}
