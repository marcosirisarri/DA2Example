﻿using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public interface IUsersDataTransfer
    {
        ICollection<UserDTO> GetAllUsers(Guid sessionToken);
        UserDTO GetByUserName(string userName, Guid sessionToken);
        void Add(UserDTO newUser, Guid sessionToken);
        bool Update(Guid id, UserDTO updatedUser, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}
