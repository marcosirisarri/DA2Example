﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class ZonesDataTransfer : IZonesDataTransfer
    {
        private IZonesBusinessLogic zonesBusinessLogic;
        private ISubzonesBusinessLogic subzonesBusinessLogic;

        public ZonesDataTransfer(IZonesBusinessLogic zonesBusinessLogic, ISubzonesBusinessLogic subzonesBusinessLogic)
        {
            this.zonesBusinessLogic = zonesBusinessLogic;
            this.subzonesBusinessLogic = subzonesBusinessLogic;
        }

        public ICollection<ZoneDTO> GetAllZones(Guid sessionToken)
        {
            ICollection<Zone> zones = zonesBusinessLogic.GetAllZones(sessionToken);
            ICollection<ZoneDTO> zonesDTO = new List<ZoneDTO>();
            foreach (Zone zone in zones)
            {
                ZoneDTO zoneDTO = ZoneToDTO(zone);
                zonesDTO.Add(zoneDTO);
            }
            return zonesDTO;
        }

        public ZoneDTO GetByName(string name, Guid sessionToken)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            Zone zone = zonesBusinessLogic.GetByName(name, sessionToken);
            return ZoneToDTO(zone);
        }

        public void Add(ZoneDTO zone, Guid sessionToken)
        {
            if (zone == null)
            {
                throw new ArgumentNullException(nameof(zone));
            }
            Zone newZone = DTOtoZone(zone, sessionToken);
            zonesBusinessLogic.Add(newZone, sessionToken);
        }

        public bool Update(Guid id, ZoneDTO zone, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }

            Zone updatedZone = DTOtoZone(zone, sessionToken);
            return zonesBusinessLogic.Update(id, updatedZone, sessionToken);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return zonesBusinessLogic.Delete(id, sessionToken);
        }

        private Zone DTOtoZone(ZoneDTO zone, Guid sessionToken)
        {
            if (zone == null)
            {
                return null;
            }

            Zone newZone = new Zone();
            newZone.Id = zone.Id;
            newZone.Name = zone.Name;
            newZone.MaxCapacity = zone.MaxCapacity;
            newZone.Subzones = new List<Subzone>();
            foreach (Guid subzoneId in  zone.SubzoneIds)
            {
                Subzone subzone = subzonesBusinessLogic.GetById(subzoneId, sessionToken);
                newZone.Subzones.Add(subzone);
            }

            return newZone;
        }

        private ZoneDTO ZoneToDTO(Zone zone)
        {
            if (zone == null)
            {
                return null;
            }

            ZoneDTO newZone = new ZoneDTO();
            newZone.Id = zone.Id;
            newZone.Name = zone.Name;
            newZone.MaxCapacity = zone.MaxCapacity;
            newZone.SubzoneIds = new List<Guid>();
            foreach (Subzone subzone in zone.Subzones)
            {
                newZone.SubzoneIds.Add(subzone.Id);
            }
            
            return newZone;
        }
    }
}
