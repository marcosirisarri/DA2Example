﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class LotsDataTransfer : ILotsDataTransfer
    {
        private ILotsBusinessLogic lotsBusinessLogic;
        private IVehiclesBusinessLogic vehiclesBusinessLogic;
        private IUsersBusinessLogic usersBusinessLogic;

        public LotsDataTransfer(ILotsBusinessLogic lotsBusinessLogic, IVehiclesBusinessLogic vehiclesBusinessLogic, IUsersBusinessLogic usersBusinessLogic)
        {
            this.lotsBusinessLogic = lotsBusinessLogic;
            this.vehiclesBusinessLogic = vehiclesBusinessLogic;
            this.usersBusinessLogic = usersBusinessLogic;
        }

        public ICollection<LotDTO> GetAllLots(Guid sessionToken)
        {
            ICollection<Lot> lots = lotsBusinessLogic.GetAllLots(sessionToken);
            return LotsToDTOs(lots);
        }

        public LotDTO GetById(Guid id, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            Lot lot = lotsBusinessLogic.GetById(id, sessionToken);
            return LotToDTO(lot);
        }

        public LotDTO GetByName(string name, Guid sessionToken)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            Lot lot = lotsBusinessLogic.GetByName(name, sessionToken);
            return LotToDTO(lot);
        }

        public ICollection<LotDTO> GetReadyToDepartLots(Guid sessionToken)
        {
            ICollection<Lot> lots = lotsBusinessLogic.GetReadyToDepartLots(sessionToken);
            return LotsToDTOs(lots);
        }

        public void Add(LotDTO lotDTO, Guid sessionToken)
        {
            Lot newLot = DTOtoLot(lotDTO, sessionToken);     
            lotsBusinessLogic.Add(newLot, sessionToken);
        }
        
        private Lot DTOtoLot(LotDTO lot, Guid sessionToken)
        {
            if (lot == null)
            {
                return null;
            }

            Lot newLot = new Lot();
            newLot.Id = lot.Id;
            newLot.Name = lot.Name;
            newLot.Description = lot.Description;
            newLot.Carrier = usersBusinessLogic.GetById(lot.CarrierId, sessionToken);
            newLot.CreatedBy = usersBusinessLogic.GetById(lot.CreatedById, sessionToken);
            newLot.Vehicles = new List<Vehicle>();
            foreach (Guid vehicleId in lot.VehicleIds)
            {
                Vehicle vehicle = vehiclesBusinessLogic.GetById(vehicleId, sessionToken);
                newLot.Vehicles.Add(vehicle);
            }
            return newLot;
        }

        private LotDTO LotToDTO(Lot lot)
        {
            if (lot == null)
            {
                return null;
            }

            LotDTO newLot = new LotDTO();
            newLot.Id = lot.Id;
            newLot.Name = lot.Name;
            newLot.Description = lot.Description;
            newLot.CarrierId = lot.Carrier.Id;
            newLot.CreatedById = lot.CreatedBy.Id;
            newLot.VehicleIds = new List<Guid>();
            foreach (Vehicle vehicle in lot.Vehicles)
            {
                newLot.VehicleIds.Add(vehicle.Id);
            }
            return newLot;
        }

        private ICollection<LotDTO> LotsToDTOs(ICollection<Lot> lots)
        {
            ICollection<LotDTO> dtos = new List<LotDTO>();
            foreach (Lot lot in lots)
            {
                LotDTO lotDTO = LotToDTO(lot);
                dtos.Add(lotDTO);
            }

            return dtos;
        }
    }
}
