﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;

namespace DAOB.WebApi.DataTransfer
{
    public class SessionsDataTransfer : ISessionsDataTransfer
    {
        private ISessionsBusinessLogic sessionsBusinessLogic;
        private IUsersBusinessLogic usersBusinessLogic;

        public SessionsDataTransfer(ISessionsBusinessLogic sessionsBusinessLogic, IUsersBusinessLogic usersBusinessLogic)
        {
            this.sessionsBusinessLogic = sessionsBusinessLogic;
            this.usersBusinessLogic = usersBusinessLogic;
        }

        public SessionDTO Add(UserDTO userDTO)
        {
            if (userDTO == null)
            {
                throw new ArgumentNullException(nameof(userDTO));
            }

            User user = DTOtoUser(userDTO);
            Session session = sessionsBusinessLogic.Add(user);
            return SessionToDTO(session);
        }

        private User DTOtoUser(UserDTO user)
        {
            if (user == null)
            {
                return null;
            }

            User newUser = new User();
            newUser.Id = user.Id;
            newUser.UserName = user.UserName;
            newUser.Password = user.Password;
            newUser.FirstName = user.FirstName;
            newUser.LastName = user.LastName;
            newUser.PhoneNumber = user.PhoneNumber;
            newUser.Role = usersBusinessLogic.GetRoleById(user.RoleId);

            return newUser;
        }

        private SessionDTO SessionToDTO(Session session)
        {
            if (session == null)
            {
                return null;
            }

            SessionDTO newSession = new SessionDTO();
            newSession.Id = session.Id;
            newSession.UserId = session.User.Id;

            return newSession;
        }
    }
}