﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class VehiclesDataTransfer : IVehiclesDataTransfer
    {
        private IVehiclesBusinessLogic vehiclesBusinessLogic;

        public VehiclesDataTransfer(IVehiclesBusinessLogic vehiclesBusinessLogic)
        {
            this.vehiclesBusinessLogic = vehiclesBusinessLogic;
        }

        public ICollection<VehicleDTO> GetAllVehicles(Guid sessionToken)
        {
            ICollection<Vehicle> vehicles = vehiclesBusinessLogic.GetAllVehicles(sessionToken);
            ICollection<VehicleDTO> vehiclesDTO = new List<VehicleDTO>();
            foreach (Vehicle vehicle in vehicles)
            {
                VehicleDTO vehicleDTO = VehicleToDTO(vehicle);
                vehiclesDTO.Add(vehicleDTO);
            }
            return vehiclesDTO;
        }

        public VehicleDTO GetByVIN(string VIN, Guid sessionToken)
        {
            if (VIN == null)
            {
                throw new ArgumentNullException(nameof(VIN));
            }
            Vehicle vehicle = vehiclesBusinessLogic.GetByVIN(VIN, sessionToken);
            return VehicleToDTO(vehicle);
        }

        public void Add(VehicleDTO vehicle, Guid sessionToken)
        {
            if (vehicle == null)
            {
                throw new ArgumentNullException(nameof(vehicle));
            }
            Vehicle newVehicle = DTOtoVehicle(vehicle);
            vehiclesBusinessLogic.Add(newVehicle, sessionToken);
        }

        public bool Update(Guid id, VehicleDTO vehicle, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            if (vehicle == null)
            {
                throw new ArgumentNullException(nameof(vehicle));
            }
            Vehicle updatedVehicle = DTOtoVehicle(vehicle);
            return vehiclesBusinessLogic.Update(id, updatedVehicle, sessionToken);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            return vehiclesBusinessLogic.Delete(id, sessionToken);
        }
        
        private Vehicle DTOtoVehicle(VehicleDTO vehicle)
        {
            if (vehicle == null)
            {
                return null;
            }

            Vehicle newVehicle = new Vehicle();
            newVehicle.Id = vehicle.Id;
            newVehicle.VIN = vehicle.VIN;
            newVehicle.Brand = vehicle.Brand;
            newVehicle.Model = vehicle.Model;
            newVehicle.Year = vehicle.Year;
            newVehicle.Color = vehicle.Color;
            newVehicle.Type = vehicle.Type;

            return newVehicle;
        }

        private VehicleDTO VehicleToDTO(Vehicle vehicle)
        {
            if (vehicle == null)
            {
                return null;
            }

            VehicleDTO newVehicle = new VehicleDTO();
            newVehicle.Id = vehicle.Id;
            newVehicle.VIN = vehicle.VIN;
            newVehicle.Brand = vehicle.Brand;
            newVehicle.Model = vehicle.Model;
            newVehicle.Year = vehicle.Year;
            newVehicle.Color = vehicle.Color;
            newVehicle.Type = vehicle.Type;

            return newVehicle;
        }
    }
}
