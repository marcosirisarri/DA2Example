﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;

namespace DAOB.WebApi.DataTransfer
{
    public class SubzonesDataTransfer : ISubzonesDataTransfer
    {
        private ISubzonesBusinessLogic subzonesBusinessLogic;

        public SubzonesDataTransfer(ISubzonesBusinessLogic subzonesBusinessLogic)
        {
            this.subzonesBusinessLogic = subzonesBusinessLogic;
        }

        public ICollection<SubzoneDTO> GetAllSubzones(Guid sessionToken)
        {
            ICollection<Subzone> subzones = subzonesBusinessLogic.GetAllSubzones(sessionToken);
            ICollection<SubzoneDTO> subzonesDTO = new List<SubzoneDTO>();
            foreach (Subzone subzone in subzones)
            {
                SubzoneDTO subzoneDTO = SubzoneToDTO(subzone);
                subzonesDTO.Add(subzoneDTO);
            }
            return subzonesDTO;
        }

        public SubzoneDTO GetById(Guid id, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            Subzone subzone = subzonesBusinessLogic.GetById(id, sessionToken);
            return SubzoneToDTO(subzone);
        }

        public SubzoneDTO GetByName(string name, Guid sessionToken)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            Subzone subzone = subzonesBusinessLogic.GetByName(name, sessionToken);
            return SubzoneToDTO(subzone);
        }

        public void Add(SubzoneDTO subzone, Guid sessionToken)
        {
            if (subzone == null)
            {
                throw new ArgumentNullException(nameof(subzone));
            }
            Subzone newSubzone = DTOtoSubzone(subzone);
            subzonesBusinessLogic.Add(newSubzone, sessionToken);
        }

        public bool Update(Guid id, SubzoneDTO subzone, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            Subzone updatedSubzone = DTOtoSubzone(subzone);
            return subzonesBusinessLogic.Update(id, updatedSubzone, sessionToken);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }

            return subzonesBusinessLogic.Delete(id, sessionToken);
        }

        private SubzoneDTO SubzoneToDTO(Subzone subzone)
        {
            if (subzone == null)
            {
                return null;
            }

            SubzoneDTO newSubzone = new SubzoneDTO();
            newSubzone.Id = subzone.Id;
            newSubzone.Name = subzone.Name;
            newSubzone.MaxCapacity = subzone.MaxCapacity;
            
            return newSubzone;
        }

        private Subzone DTOtoSubzone(SubzoneDTO subzoneDTO)
        {
            if (subzoneDTO == null)
            {
                return null;
            }

            Subzone newSubzone = new Subzone();
            newSubzone.Id = subzoneDTO.Id;
            newSubzone.Name = subzoneDTO.Name;
            newSubzone.MaxCapacity = subzoneDTO.MaxCapacity;

            return newSubzone;
        }
    }
}
