﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.WebApi.DataTransfer
{
    public class TransportsDataTransfer : ITransportsDataTransfer
    {
        private ITransportsBusinessLogic transportsBusinessLogic;
        private ILotsBusinessLogic lotsBusinessLogic;
        private IUsersBusinessLogic usersBusinessLogic;

        public TransportsDataTransfer(ITransportsBusinessLogic transportsBusinessLogic, ILotsBusinessLogic lotsBusinessLogic,
            IUsersBusinessLogic usersBusinessLogic)
        {
            this.transportsBusinessLogic = transportsBusinessLogic;
            this.lotsBusinessLogic = lotsBusinessLogic;
            this.usersBusinessLogic = usersBusinessLogic;
        }

        public void Add(TransportDTO transport, Guid sessionToken)
        {
            if (transport == null)
            {
                throw new ArgumentNullException();
            }
            Transport newTransport = DTOtoTransport(transport, sessionToken);
            transportsBusinessLogic.Add(newTransport, sessionToken);
        }

        public bool MarkAsFinished(Guid id, DateTime endDate, Guid sessionToken)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return transportsBusinessLogic.MarkAsFinished(id, endDate, sessionToken);
        }

        private Transport DTOtoTransport(TransportDTO transport, Guid sessionToken)
        {
            if (transport == null)
            {
                return null;
            }

            Transport newTransport = new Transport();
            newTransport.Id = transport.Id;
            newTransport.StartDate = transport.StartDate;
            newTransport.EndDate = transport.EndDate;
            newTransport.Carrier = usersBusinessLogic.GetById(transport.CarrierId, sessionToken);

            newTransport.Lots = new List<Lot>();
            foreach (Guid lotId in transport.LotIds)
            {
                Lot lot = lotsBusinessLogic.GetById(lotId, sessionToken);
                newTransport.Lots.Add(lot);
            }
            return newTransport;
        }
    }
}
