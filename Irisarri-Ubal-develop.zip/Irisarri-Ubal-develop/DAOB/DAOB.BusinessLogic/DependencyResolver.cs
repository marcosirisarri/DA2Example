﻿using DAOB.DependencyResolver;
using System.ComponentModel.Composition;

namespace DAOB.BusinessLogic
{
    [Export(typeof(IComponent))]
    public class DependencyResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<IChangeHistoryBusinessLogic, ChangeHistoryBusinessLogic>();
            registerComponent.RegisterType<IInspectionsBusinessLogic, InspectionsBusinessLogic>();
            registerComponent.RegisterType<ILotsBusinessLogic, LotsBusinessLogic>();
            registerComponent.RegisterType<ISalesBusinessLogic, SalesBusinessLogic>();
            registerComponent.RegisterType<ISessionsBusinessLogic, SessionsBusinessLogic>();
            registerComponent.RegisterType<ISubzonesBusinessLogic, SubzonesBusinessLogic>();
            registerComponent.RegisterType<ITransportsBusinessLogic, TransportsBusinessLogic>();
            registerComponent.RegisterType<IUsersBusinessLogic, UsersBusinessLogic>();
            registerComponent.RegisterType<IVehiclesBusinessLogic, VehiclesBusinessLogic>();
            registerComponent.RegisterType<IZonesBusinessLogic, ZonesBusinessLogic>();
        }
    }
}
