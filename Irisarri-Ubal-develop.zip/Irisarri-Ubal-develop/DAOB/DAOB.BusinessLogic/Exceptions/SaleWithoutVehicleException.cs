﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class SaleWithoutVehicleException : Exception
    {
        public SaleWithoutVehicleException()
        {
        }

        public SaleWithoutVehicleException(string message) : base(message)
        {
        }

        public SaleWithoutVehicleException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SaleWithoutVehicleException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}