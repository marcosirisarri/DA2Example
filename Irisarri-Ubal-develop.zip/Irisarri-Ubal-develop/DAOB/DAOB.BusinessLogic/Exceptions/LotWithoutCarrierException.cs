﻿using DAOB.Data.Entities;
using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class LotWithoutCarrierException : Exception
    {
        public LotWithoutCarrierException()
        {
        }

        public LotWithoutCarrierException(string message) : base(message)
        {
        }

        public LotWithoutCarrierException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected LotWithoutCarrierException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}