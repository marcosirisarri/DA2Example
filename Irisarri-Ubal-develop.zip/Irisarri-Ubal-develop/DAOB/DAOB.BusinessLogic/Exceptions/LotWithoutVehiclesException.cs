﻿using DAOB.Data.Entities;
using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class LotWithoutVehiclesException : Exception
    {
        public LotWithoutVehiclesException()
        {
        }

        public LotWithoutVehiclesException(string message) : base(message)
        {
        }

        public LotWithoutVehiclesException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected LotWithoutVehiclesException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}