﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    public class EmptyVehicleVINException : Exception
    {
        public EmptyVehicleVINException()
        {
        }

        public EmptyVehicleVINException(string message) : base(message)
        {
        }

        public EmptyVehicleVINException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected EmptyVehicleVINException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}