﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class SaleWithoutSalesmanException : Exception
    {
        public SaleWithoutSalesmanException()
        {
        }

        public SaleWithoutSalesmanException(string message) : base(message)
        {
        }

        public SaleWithoutSalesmanException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SaleWithoutSalesmanException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}