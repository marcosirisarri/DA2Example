﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class VehicleNotForSaleException : Exception
    {
        public VehicleNotForSaleException()
        {
        }

        public VehicleNotForSaleException(string message) : base(message)
        {
        }

        public VehicleNotForSaleException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected VehicleNotForSaleException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}