﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class LotNameNotEmptyException : Exception
    {
        public LotNameNotEmptyException()
        {
        }

        public LotNameNotEmptyException(string message) : base(message)
        {
        }

        public LotNameNotEmptyException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected LotNameNotEmptyException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
