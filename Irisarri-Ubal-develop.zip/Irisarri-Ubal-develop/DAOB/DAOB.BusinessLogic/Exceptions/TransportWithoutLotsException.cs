﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    public class TransportWithoutLotsException : Exception
    {
        public TransportWithoutLotsException()
        {
        }

        public TransportWithoutLotsException(string message) : base(message)
        {
        }

        public TransportWithoutLotsException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TransportWithoutLotsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
