﻿using DAOB.Data.Entities;
using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class LotWithoutCreatorException : Exception
    {
        public LotWithoutCreatorException()
        {
        }

        public LotWithoutCreatorException(string message) : base(message)
        {
        }

        public LotWithoutCreatorException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected LotWithoutCreatorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}