﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class SaleWithoutBuyerException : Exception
    {
        public SaleWithoutBuyerException()
        {
        }

        public SaleWithoutBuyerException(string message) : base(message)
        {
        }

        public SaleWithoutBuyerException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected SaleWithoutBuyerException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}