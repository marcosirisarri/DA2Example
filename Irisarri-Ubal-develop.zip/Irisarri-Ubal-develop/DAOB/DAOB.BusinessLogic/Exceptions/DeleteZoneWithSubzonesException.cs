﻿using System;
using System.Runtime.Serialization;

namespace DAOB.BusinessLogic.Exceptions
{
    public class DeleteZoneWithSubzonesException : Exception
    {
        public DeleteZoneWithSubzonesException()
        {
        }

        public DeleteZoneWithSubzonesException(string message) : base(message)
        {
        }

        public DeleteZoneWithSubzonesException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DeleteZoneWithSubzonesException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
