﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class TransportWithoutVehiclesException : Exception
    {
        public TransportWithoutVehiclesException()
        {
        }

        public TransportWithoutVehiclesException(string message) : base(message)
        {
        }

        public TransportWithoutVehiclesException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TransportWithoutVehiclesException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
