﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class FutureDateNotExpectedException : Exception
    {
        public FutureDateNotExpectedException()
        {
        }

        public FutureDateNotExpectedException(string message) : base(message)
        {
        }

        public FutureDateNotExpectedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected FutureDateNotExpectedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
