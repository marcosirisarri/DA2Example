﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class InspectionNotFoundException : Exception
    {
        public InspectionNotFoundException()
        {
        }

        public InspectionNotFoundException(string message) : base(message)
        {
        }

        public InspectionNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InspectionNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
