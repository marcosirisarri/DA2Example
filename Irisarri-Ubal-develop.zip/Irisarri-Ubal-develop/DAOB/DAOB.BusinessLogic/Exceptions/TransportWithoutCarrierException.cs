﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.BusinessLogic.Exceptions
{
    [Serializable]
    public class TransportWithoutCarrierException : Exception
    {
        public TransportWithoutCarrierException()
        {
        }

        public TransportWithoutCarrierException(string message) : base(message)
        {
        }

        public TransportWithoutCarrierException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TransportWithoutCarrierException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
