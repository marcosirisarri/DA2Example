﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public interface IChangeHistoryBusinessLogic
    {
        ICollection<ChangeHistory> Get(Guid id);
    }
}
