﻿using System.Collections.Generic;
using System;
using DAOB.Data.Entities;

namespace DAOB.BusinessLogic
{
    public interface IVehiclesBusinessLogic
    {
        ICollection<Vehicle> GetAllVehicles(Guid sessionToken);
        Vehicle GetById(Guid id, Guid sessionToken);
        Vehicle GetByVIN(string VIN, Guid sessionToken);
        void Add(Vehicle newVehicle, Guid sessionToken);
        bool Update(Guid id, Vehicle updatedVehicle, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}