﻿using DAOB.Data.Entities;
using System;

namespace DAOB.BusinessLogic
{
    public interface ISalesBusinessLogic
    {
        void Add(Sale newVehicle, Guid sessionToken);
    }
}
