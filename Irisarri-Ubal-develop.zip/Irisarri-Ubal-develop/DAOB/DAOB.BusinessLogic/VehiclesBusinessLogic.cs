﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class VehiclesBusinessLogic : IVehiclesBusinessLogic
    {
        private IVehiclesRepository vehiclesRepository;
        private ISessionsRepository sessionsRepository;

        public VehiclesBusinessLogic(IVehiclesRepository vehiclesRepository, ISessionsRepository sessionsRepository)
        {
            this.vehiclesRepository = vehiclesRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public ICollection<Vehicle> GetAllVehicles(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveVehicle, "El usuario no tiene permisos para consultar vehiculos");
            return vehiclesRepository.GetAll();
        }

        public Vehicle GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveVehicle, "El usuario no tiene permisos para consultar vehiculos");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return vehiclesRepository.GetById(id);
        }

        public Vehicle GetByVIN(string VIN, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveVehicle, "El usuario no tiene permisos para consultar vehiculos");
            if (VIN == null)
            {
                throw new ArgumentNullException(nameof(VIN));
            }
            return vehiclesRepository.GetByVIN(VIN);
        }

        public void Add(Vehicle newVehicle, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddVehicle, "El usuario no tiene permisos para agregar vehiculos");
            if (newVehicle == null)
            {
                throw new ArgumentNullException(nameof(newVehicle));
            }
            newVehicle.AddChangeDetails("Vehículo ingresado.");
            newVehicle.State = VehicleState.Arrived;
            vehiclesRepository.Add(newVehicle);
        }

        public bool Update(Guid id, Vehicle updatedVehicle, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.UpdateVehicle, "El usuario no tiene permisos para actualizar información de vehiculos");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return vehiclesRepository.Update(id, updatedVehicle);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.DeleteVehicle, "El usuario no tiene permisos para borrar vehiculos");
            return vehiclesRepository.DeleteById(id);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
