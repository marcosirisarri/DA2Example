﻿using DAOB.Data.Entities;
using System;

namespace DAOB.BusinessLogic
{
    public interface ITransportsBusinessLogic
    {
        void Add(Transport newTransport, Guid sessionToken);
        bool MarkAsFinished(Guid id, DateTime endDate, Guid sessionToken);
    }
}