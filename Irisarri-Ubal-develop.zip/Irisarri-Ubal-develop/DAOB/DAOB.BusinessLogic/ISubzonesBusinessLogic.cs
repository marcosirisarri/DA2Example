﻿using System;
using System.Collections.Generic;
using DAOB.Data.Entities;

namespace DAOB.BusinessLogic
{
    public interface ISubzonesBusinessLogic
    {
        ICollection<Subzone> GetAllSubzones(Guid sessionToken);
        Subzone GetById(Guid id, Guid sessionToken);
        Subzone GetByName(string name, Guid sessionToken);
        void Add(Subzone newSubzone, Guid sessionToken);
        bool Update(Guid id, Subzone updatedSubzone, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}