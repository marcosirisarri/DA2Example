﻿using System;
using System.Collections.Generic;
using DAOB.Data.Entities;

namespace DAOB.BusinessLogic
{
    public interface IUsersBusinessLogic
    {
        ICollection<User> GetAllUsers(Guid sessionToken);
        User GetById(Guid id, Guid sessionToken);
        User GetByUserName(string userName, Guid sessionToken);
        void Add(User newUser, Guid sessionToken);
        bool Update(Guid id, User updatedUser, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
        Role GetRoleById(Guid id);
    }
}