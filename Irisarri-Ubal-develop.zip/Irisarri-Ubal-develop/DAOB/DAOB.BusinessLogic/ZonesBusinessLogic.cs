﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class ZonesBusinessLogic : IZonesBusinessLogic
    {
        private IZonesRepository zonesRepository;
        private ISessionsRepository sessionsRepository;
        
        public ZonesBusinessLogic(IZonesRepository zonesRepository, ISessionsRepository sessionsRepository)
        {
            this.zonesRepository = zonesRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public ICollection<Zone> GetAllZones(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            return zonesRepository.GetAll();
        }

        public Zone GetByName(string name, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            return zonesRepository.GetByName(name);
        }

        public Zone GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            if (id.Equals(new Guid("00000000-0000-0000-0000-000000000000")))
            {
                throw new ArgumentNullException(nameof(id));
            }
            return zonesRepository.GetById(id);
        }

        public void Add(Zone newZone, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddZone, "El usuario no tiene permisos para agregar zonas");
            if (newZone == null)
            {
                throw new ArgumentNullException(nameof(newZone));
            }

            zonesRepository.Add(newZone);
        }
        
        public bool Update(Guid id, Zone updatedZone, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.UpdateZone, "El usuario no tiene permisos para modificar zonas");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return zonesRepository.Update(id, updatedZone);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.DeleteZone, "El usuario no tiene permisos para borrar zonas");
            Zone zoneToBeDeleted = zonesRepository.GetById(id);
            if (zoneToBeDeleted.Subzones.Count > 0)
            {
                throw new DeleteZoneWithSubzonesException();
            }
            return zonesRepository.DeleteById(id);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
