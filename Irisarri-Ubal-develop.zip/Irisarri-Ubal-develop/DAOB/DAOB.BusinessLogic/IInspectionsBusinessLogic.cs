﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public interface IInspectionsBusinessLogic
    {
        ICollection<Inspection> GetAllInspections(Guid sessionToken);
        Inspection GetById(Guid id, Guid sessionToken);
        void Add(Inspection newInspection, Guid sessionToken);
    }
}