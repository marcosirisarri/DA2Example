﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class SubzonesBusinessLogic : ISubzonesBusinessLogic
    {
        private ISubzonesRepository subzonesRepository;
        private ISessionsRepository sessionsRepository;
        
        public SubzonesBusinessLogic(ISubzonesRepository subzonesRepository, ISessionsRepository sessionsRepository)
        {
            this.subzonesRepository = subzonesRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public ICollection<Subzone> GetAllSubzones(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            return subzonesRepository.GetAll();
        }

        public Subzone GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return subzonesRepository.GetById(id);
        }

        public Subzone GetByName(string name, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveZone, "El usuario no tiene permisos para consultar zonas");
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            return subzonesRepository.GetByName(name);
        }

        public void Add(Subzone newSubzone, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddZone, "El usuario no tiene permisos para agregar zonas");
            if (newSubzone == null)
            {
                throw new ArgumentNullException(nameof(newSubzone));
            }
            subzonesRepository.Add(newSubzone);
        }

        public bool Update(Guid id, Subzone updatedSubzone, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.UpdateZone, "El usuario no tiene permisos para modificar zonas");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return subzonesRepository.Update(id, updatedSubzone);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.DeleteZone, "El usuario no tiene permisos para borrar zonas");
            return subzonesRepository.DeleteById(id);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
