﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class ChangeHistoryBusinessLogic : IChangeHistoryBusinessLogic
    {
        public IChangeHistoryRepository changeHistoryRepository;
        public IVehiclesRepository vehicleRepository;

        public ChangeHistoryBusinessLogic(IChangeHistoryRepository changeHistoryRepository, IVehiclesRepository vehiclesRepository)
        {
            this.changeHistoryRepository = changeHistoryRepository;
            this.vehicleRepository = vehiclesRepository;
        }

        public ICollection<ChangeHistory> Get(Guid id)
        {
            if (id.Equals(new Guid()))
            {
                throw new EmptyVehicleVINException();
            }
            return changeHistoryRepository.Get(id);
        }
    }
}
