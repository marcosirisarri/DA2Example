﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class UsersBusinessLogic : IUsersBusinessLogic
    {
        private IUsersRepository usersRepository;
        private ISessionsRepository sessionsRepository;

        public UsersBusinessLogic(IUsersRepository usersRepository, ISessionsRepository sessionsRepository)
        {
            this.usersRepository = usersRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public ICollection<User> GetAllUsers(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveUser, "El usuario no tiene permisos para consultar usuarios");
            return usersRepository.GetAll();
        }

        public User GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveUser, "El usuario no tiene permisos para consultar usuarios");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return usersRepository.GetById(id);
        }

        public User GetByUserName(string userName, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveUser, "El usuario no tiene permisos para consultar usuarios");
            if (userName == null)
            {
                throw new ArgumentNullException(nameof(userName));
            }
            return usersRepository.GetByUserName(userName);
        }

        public void Add(User newUser, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddUser, "El usuario no tiene permisos para agregar usuarios");
            if (newUser == null)
            {
                throw new ArgumentNullException(nameof(newUser));
            }
            if (newUser.Role == null)
            {
                throw new ArgumentException("Selected role does not exist");
            }
            usersRepository.Add(newUser);
        }

        public bool Update(Guid id, User updatedUser, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.UpdateUser, "El usuario no tiene permisos para modificar usuarios");
            if (id == null || updatedUser == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            if (updatedUser.Role == null)
            {
                throw new ArgumentException("Selected role does not exist");
            }
            return usersRepository.Update(id, updatedUser);
        }

        public bool Delete(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.DeleteUser, "El usuario no tiene permisos para borrar usuarios");
            return usersRepository.DeleteById(id);
        }

        public Role GetRoleById(Guid id)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return usersRepository.GetRoleById(id);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
