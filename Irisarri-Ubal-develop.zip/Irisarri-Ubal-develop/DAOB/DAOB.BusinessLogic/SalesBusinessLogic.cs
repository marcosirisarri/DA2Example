﻿using System;
using DAOB.Data.Entities;
using DAOB.Repository;
using DAOB.BusinessLogic.Exceptions;

namespace DAOB.BusinessLogic
{
    public class SalesBusinessLogic : ISalesBusinessLogic
    {
        private ISalesRepository salesRepository;
        private IVehiclesRepository vehiclesRepository;
        private ISessionsRepository sessionsRepository;
        
        public SalesBusinessLogic(ISalesRepository salesRepository, IVehiclesRepository vehiclesRepository, ISessionsRepository sessionsRepository)
        {
            this.salesRepository = salesRepository;
            this.vehiclesRepository = vehiclesRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public void Add(Sale newSale, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddSale, "El usuario no tiene permisos para agregar ventas");
            ValidateSale(newSale);
            UpdateVehicleState(newSale.Vehicle);
            salesRepository.Add(newSale);
        }

        private void UpdateVehicleState(Vehicle vehicle)
        {
            vehicle.State = VehicleState.Sold;
            vehicle.AddChangeDetails("Se vende el vehículo.");
            vehiclesRepository.Update(vehicle.Id, vehicle);
        }

        private static void ValidateSale(Sale newSale)
        {
            if (newSale == null)
            {
                throw new ArgumentNullException(nameof(newSale));
            }
            if(newSale.Vehicle == null)
            {
                throw new SaleWithoutVehicleException();
            }
            if (newSale.Salesman == null)
            {
                throw new SaleWithoutSalesmanException();
            }
            if (newSale.Buyer == null)
            {
                throw new SaleWithoutBuyerException();
            }

            if(newSale.Vehicle.State != VehicleState.ReadyForSale)
            {
                throw new VehicleNotForSaleException();
            }
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
