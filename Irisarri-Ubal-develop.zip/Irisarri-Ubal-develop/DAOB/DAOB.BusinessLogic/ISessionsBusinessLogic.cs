﻿using DAOB.Data.Entities;

namespace DAOB.BusinessLogic
{
    public interface ISessionsBusinessLogic
    {
        Session Add(User user);
    }
}