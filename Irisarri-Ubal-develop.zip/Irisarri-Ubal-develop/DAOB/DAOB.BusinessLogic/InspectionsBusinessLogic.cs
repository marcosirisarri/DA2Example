﻿using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Linq;
using System.Collections.Generic;
using DAOB.BusinessLogic.Exceptions;

namespace DAOB.BusinessLogic
{
    public class InspectionsBusinessLogic : IInspectionsBusinessLogic
    {
        private IInspectionsRepository inspectionsRepository;
        private IVehiclesRepository vehiclesRepository;
        private ILotsRepository lotsRepository;
        private IUsersRepository usersRepository;
        private ISessionsRepository sessionRepository;

        public InspectionsBusinessLogic(IInspectionsRepository inspectionsRepository, IVehiclesRepository vehiclesRepository, ILotsRepository lotsRepository,
                                        IUsersRepository usersRepository, ISessionsRepository sessionRepository)
        {
            this.inspectionsRepository = inspectionsRepository;
            this.vehiclesRepository = vehiclesRepository;
            this.lotsRepository = lotsRepository;
            this.usersRepository = usersRepository;
            this.sessionRepository = sessionRepository;
        }

        public ICollection<Inspection> GetAllInspections(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveInspection, "El usuario no tiene permisos para consultar inspecciones");
            return inspectionsRepository.GetAll();
        }

        public Inspection GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveInspection, "El usuario no tiene permisos para consultar inspecciones");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return inspectionsRepository.GetById(id);
        }

        public void Add(Inspection newInspection, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddInspection, "El usuario no tiene permisos para agregar inspecciones");
            if (newInspection.Type == InspectionTypes.Lot)
            {
                AddLotInspection(newInspection, sessionToken);
            }
            else
            {
                AddYardInspection(newInspection, sessionToken);
            }
        }
        
        private void AddLotInspection(Inspection newInspection, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddLotInspection, "El usuario no tiene permisos para agregar inspecciones de vehiculos");
            if (newInspection == null)
            {
                throw new ArgumentNullException(nameof(newInspection));
            }

            Vehicle vehicle = newInspection.Vehicle;
            if (vehicle == null)
            {
                throw new ArgumentException("El vehículo seleccionado no existe");
            }

            inspectionsRepository.Add(newInspection);
            vehicle.AddFirstInspection(newInspection);
            vehiclesRepository.Update(vehicle.Id, vehicle);

            UpdateInspectedVehicleLot(vehicle);
        }

        private void UpdateInspectedVehicleLot(Vehicle vehicle)
        {
            ICollection<Lot> lots = lotsRepository.GetAll();
            Lot lot = lots.FirstOrDefault(l => l.Vehicles.Contains(vehicle));
            if (lot == null)
            {
                throw new ArgumentException("No se pudo encontrar el lote correspondiente al vehículo seleccionado");
            }
            LotState currentState = lot.Status;
            lot.UpdateStatusAfterFirstInspection();
            if (currentState != lot.Status)
            {
                lotsRepository.Update(lot.Id, lot);
            }
        }
        
        private void AddYardInspection(Inspection newInspection, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddYardInspection, "El usuario no tiene permisos para agregar inspecciones de vehículo en el patio");
            if (newInspection == null)
            {
                throw new ArgumentNullException(nameof(newInspection));
            }

            Vehicle vehicle = newInspection.Vehicle;
            if (vehicle == null)
            {
                throw new ArgumentNullException(nameof(vehicle));
            }
            
            Inspection lotInspection = vehicle.FirstInspection;
            if (newInspection == null)
            {
                throw new InspectionNotFoundException("Este vehículo no posee una inspeccion de lote");
            }

            inspectionsRepository.Add(newInspection);

            vehicle.AddYardInspection(newInspection);
            vehiclesRepository.Update(vehicle.Id, vehicle);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
