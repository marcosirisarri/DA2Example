﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class TransportsBusinessLogic : ITransportsBusinessLogic
    {
        private ITransportsRepository transportsRepository;
        private IVehiclesRepository vehiclesRepository;
        private ILotsRepository lotsRepository;
        private IUsersRepository usersRepository;
        private ISessionsRepository sessionsRepository;

        public TransportsBusinessLogic(ITransportsRepository transportsRepo, ILotsRepository lotsRepo, IVehiclesRepository vehiclesRepo, 
            IUsersRepository usersRepo, ISessionsRepository sessionsRepo)
        {
            transportsRepository = transportsRepo;
            lotsRepository = lotsRepo;
            vehiclesRepository = vehiclesRepo;
            usersRepository = usersRepo;
            sessionsRepository = sessionsRepo;
        }

        public void Add(Transport newTransport, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.StartTransport, "El usuario no tiene permisos para realizar transportes");

            ValidateTransport(newTransport);
            UpdateLotsStatus(newTransport);
            transportsRepository.Add(newTransport);
        }

        private void UpdateLotsStatus(Transport transport)
        {
            foreach (Lot lot in transport.Lots)
            {
                foreach (Vehicle vehicle in lot.Vehicles)
                {
                    vehicle.State = VehicleState.Departed;
                    vehicle.AddChangeDetails("Se inicia transporte.");
                    vehiclesRepository.Update(vehicle.Id, vehicle);
                }
                lot.Status = LotState.Departed;
                lotsRepository.Update(lot.Id, lot);
            }
        }

        private static void ValidateTransport(Transport transport)
        {
            if (transport == null)
            {
                throw new ArgumentNullException();
            }
            if (transport.Carrier == null)
            {
                throw new TransportWithoutCarrierException();
            }
            if (transport.Lots.Count == 0)
            {
                throw new TransportWithoutLotsException();
            }
        }

        public bool MarkAsFinished(Guid id, DateTime endDate, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.FinishTransport, "El usuario no tiene permisos para finalizar transportes");
            Transport transport = transportsRepository.GetById(id);

            if (transport == null)
            {
                throw new ArgumentNullException("No se ha especificado un transporte");
            }
            if (endDate > DateTime.Now)
            {
                throw new FutureDateNotExpectedException("No se puede ingresar una fecha futura");
            }
            
            foreach (Lot l in transport.Lots)
            {
                foreach (Vehicle vehicle in l.Vehicles)
                {
                    vehicle.State = VehicleState.YardArrived;
                    vehicle.AddChangeDetails("Finaliza transporte.");
                    vehiclesRepository.Update(vehicle.Id, vehicle);
                }
                l.Status = LotState.Delivered;
                lotsRepository.Update(l.Id, l);
            }
            return transportsRepository.MarkAsFinished(transport, endDate);
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
