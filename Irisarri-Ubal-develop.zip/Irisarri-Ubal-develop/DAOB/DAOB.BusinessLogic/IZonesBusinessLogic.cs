﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public interface IZonesBusinessLogic
    {
        ICollection<Zone> GetAllZones(Guid sessionToken);
        Zone GetByName(string name, Guid sessionToken);
        Zone GetById(Guid id, Guid sessionToken);
        void Add(Zone newZone, Guid sessionToken);
        bool Update(Guid id, Zone updatedZone, Guid sessionToken);
        bool Delete(Guid id, Guid sessionToken);
    }
}