﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public class LotsBusinessLogic : ILotsBusinessLogic
    {
        private ILotsRepository lotsRepository;
        private IVehiclesRepository vehiclesRepository;
        private IUsersRepository usersRepository;
        private ISessionsRepository sessionsRepository;

        public LotsBusinessLogic(ILotsRepository lotsRepository, IVehiclesRepository vehiclesRepository, IUsersRepository usersRepository, ISessionsRepository sessionsRepository)
        {
            this.lotsRepository = lotsRepository;
            this.vehiclesRepository = vehiclesRepository;
            this.usersRepository = usersRepository;
            this.sessionsRepository = sessionsRepository;
        }

        public ICollection<Lot> GetAllLots(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveLot, "El usuario no tiene permisos para buscar lotes");
            return lotsRepository.GetAll();
        }

        public Lot GetById(Guid id, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveLot, "El usuario no tiene permisos para buscar lotes");
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }
            return lotsRepository.GetById(id);
        }

        public Lot GetByName(string name, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveLot, "El usuario no tiene permisos para buscar lotes");
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }
            return lotsRepository.GetByName(name);
        }

        public ICollection<Lot> GetReadyToDepartLots(Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.RetrieveLotsReadyToDepart, "El usuario no tiene permisos para ver los lotes prontos para partir");
            return lotsRepository.GetReadyToDepartLots();
        }
        
        public void Add(Lot newLot, Guid sessionToken)
        {
            CheckPermission(sessionToken, RolePermission.AddLot, "El usuario no tiene permisos para ingresar lotes");
            ValidateLot(newLot);
            newLot.Status = LotState.Created;
            foreach (Vehicle vehicle in newLot.Vehicles)
            {
                vehicle.State = VehicleState.Departed;
                vehicle.AddChangeDetails("Se inicia transporte.");
                vehiclesRepository.Update(vehicle.Id, vehicle);
            }
            lotsRepository.Add(newLot);
        }

        private static void ValidateLot(Lot lot)
        {
            if (lot == null)
            {
                throw new ArgumentNullException("El lote no puede ser nulo");
            }
            if (string.IsNullOrWhiteSpace(lot.Name))
            {
                throw new LotNameNotEmptyException();
            }
            if (lot.CreatedBy == null)
            {
                throw new LotWithoutCreatorException();
            }
            if (lot.Carrier == null)
            {
                throw new LotWithoutCarrierException();
            }
            if (lot.Vehicles.Count == 0)
            {
                throw new LotWithoutVehiclesException();
            }
        }

        private void CheckPermission(Guid sessionToken, RolePermission permission, string errorMessage)
        {
            if (!sessionsRepository.CheckPermission(sessionToken, permission))
            {
                throw new MissingPermissionException(errorMessage);
            }
        }
    }
}
