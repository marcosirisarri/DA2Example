﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic
{
    public interface ILotsBusinessLogic
    {
        void Add(Lot newLot, Guid sessionToken);
        ICollection<Lot> GetAllLots(Guid sessionToken);
        Lot GetById(Guid id, Guid sessionToken);
        Lot GetByName(string name, Guid sessionToken);
        ICollection<Lot> GetReadyToDepartLots(Guid sessionToken);
    }
}