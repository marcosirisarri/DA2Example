﻿using DAOB.Data.Entities;
using DAOB.Logger.Definition;
using DAOB.Logger.Facade;
using DAOB.Repository;
using System;

namespace DAOB.BusinessLogic
{
    public class SessionsBusinessLogic : ISessionsBusinessLogic
    {
        private ISessionsRepository sessionsRepository;
        private IUsersRepository usersRepository;

        public SessionsBusinessLogic(ISessionsRepository sessionsRepository, IUsersRepository usersRepository)
        {
            this.sessionsRepository = sessionsRepository;
            this.usersRepository = usersRepository;
        }

        public Session Add(User user)
        {
            ValidateSession(user);
            User loggedUser = usersRepository.Check(user);

            if (loggedUser != null)
            {
                Session session = sessionsRepository.Add(loggedUser);
                session.User = loggedUser;
                LogUserLogin(loggedUser.UserName);
                return session;
            }
            return null;
        }

        private void LogUserLogin(string userName)
        {
            LogEntry entry = new LogEntry();
            entry.Action = LogAction.UserLogin;
            entry.DateTime = DateTime.Now;
            entry.UserName = userName;
            entry.Message = "User successfully logged";

            LoggerUtil.AddEntry(entry);
        }

        private static void ValidateSession(User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException();
            }
            if (string.IsNullOrWhiteSpace(user.UserName))
            {
                throw new ArgumentNullException();//change for EmptyUserNameAtLoginException
            }
        }
    }
}
