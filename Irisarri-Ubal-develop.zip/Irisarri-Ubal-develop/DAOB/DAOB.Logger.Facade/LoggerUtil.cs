﻿using DAOB.Logger.Definition;
using DAOB.Logger.Implementation;
using System;
using System.Collections.Generic;

namespace DAOB.Logger.Facade
{
    public static class LoggerUtil
    {
        private static LogBase logger = new TxtLogger();

        public static void AddEntry(LogEntry entry)
        {
            logger.AddEntry(entry);
        }

        public static ICollection<LogEntry> GetLogsBetweenDates(DateTime starDate, DateTime endDate)
        {
            return logger.GetLogsBetweenDates(starDate, endDate);
        }
    }
}
