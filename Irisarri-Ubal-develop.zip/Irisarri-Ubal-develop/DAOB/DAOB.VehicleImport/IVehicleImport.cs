﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.VehicleImport
{
    public interface IVehicleImport
    {
        /// <summary>
        /// Sends a request for a dictionary containing pairs of <Type of field required>/<name of field>.
        /// These are the fields required for the configuration of the Vehicle import process.
        /// </summary>
        /// <returns></returns>
        Dictionary<RequestedFieldType, string> RequestFields();

        /// <summary>
        /// Obtains a list of vehicles to be imported.
        /// </summary>
        /// <param name="fields">A dictionary containing pairs of <field name>/<field value>.
        /// The field names are the ones obtained through the RequestFields method.</param>
        /// <returns>A List of vehicles which complain with the VehicleImportDTO class</returns>
        List<VehicleImportDTO> ObtainVehicles(Dictionary<string, object> fields); 
    }
}
