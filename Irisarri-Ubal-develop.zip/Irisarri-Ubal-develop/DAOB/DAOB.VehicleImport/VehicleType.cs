﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.VehicleImport
{
    public enum VehicleType
    {
        Car = 0,
        Truck = 1,
        SUV = 2,
        Van = 3,
        Minivan = 4
    }
}
