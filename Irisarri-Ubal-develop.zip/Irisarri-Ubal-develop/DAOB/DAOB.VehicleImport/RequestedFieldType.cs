﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.VehicleImport
{
    public enum RequestedFieldType
    {
        String = 0,
        Int = 1,
        Url = 2,
        Date = 3,
        FilePath = 4,
        ConnectionString = 5
    }
}
