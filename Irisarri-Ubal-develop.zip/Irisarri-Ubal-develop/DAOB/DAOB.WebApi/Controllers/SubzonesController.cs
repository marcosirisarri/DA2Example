﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class SubzonesController : CommonApiController
    {
        private ISubzonesDataTransfer subzonesDataTransfer;

        public SubzonesController(ISubzonesDataTransfer subzonesLogic)
        {
            subzonesDataTransfer = subzonesLogic;
        }

        // GET: api/Subzones
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                ICollection<SubzoneDTO> subzones = subzonesDataTransfer.GetAllSubzones(token);
                if (subzones == null)
                {
                    return NotFound();
                }
                return Ok(subzones);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Subzones/5
        public IHttpActionResult Get(string name)
        {
            try
            {
                Guid token = GetRequestToken();
                SubzoneDTO subzone = subzonesDataTransfer.GetByName(name, token);
                if (subzone == null)
                {
                    return NotFound();
                }
                return Ok(subzone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Subzones
        public IHttpActionResult Post([FromBody] SubzoneDTO newSubzone)
        {
            try
            {
                Guid token = GetRequestToken();
                subzonesDataTransfer.Add(newSubzone, token);
                return CreatedAtRoute("DefaultApi", new { name = newSubzone.Name }, newSubzone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: api/Subzones/5
        public IHttpActionResult Put(Guid id, [FromBody] SubzoneDTO updatedSubzone)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = subzonesDataTransfer.Update(id, updatedSubzone, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, updatedSubzone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE: api/Subzones/5
        public IHttpActionResult Delete(Guid id)
        {
            try {
                Guid token = GetRequestToken();
                bool updateResult = subzonesDataTransfer.Delete(id, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
