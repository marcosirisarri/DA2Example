﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class SessionsController : CommonApiController
    {
        private ISessionsDataTransfer sessionsDataTransfer;
        
        public SessionsController(ISessionsDataTransfer sessionsDataTransfer)
        {
            this.sessionsDataTransfer = sessionsDataTransfer;
        }

        public IHttpActionResult Post([FromBody]UserDTO user)
        {
            try
            {
                SessionDTO session = sessionsDataTransfer.Add(user);
                if (session == null)
                {
                    return BadRequest("Usuario y/o contraseña incorrectos");
                }
                return Ok(session);// CreatedAtRoute("DefaultApi", new { id = id }, user);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
