﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class ZonesController : CommonApiController
    {
        private IZonesDataTransfer zonesDataTransfer;

        public ZonesController(IZonesDataTransfer zonesLogic)
        {
            zonesDataTransfer = zonesLogic;
        }

        // GET: api/Zones
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                ICollection<ZoneDTO> zones = zonesDataTransfer.GetAllZones(token);
                if (zones == null)
                {
                    return NotFound();
                }
                return Ok(zones);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Zones/Z1
        public IHttpActionResult Get(string name)
        {
            try
            {
                Guid token = GetRequestToken();
                ZoneDTO zone = zonesDataTransfer.GetByName(name, token);
                if (zone == null)
                {
                    return NotFound();
                }
                return Ok(zone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Zones
        public IHttpActionResult Post([FromBody] ZoneDTO zone)
        {
            try
            {
                Guid token = GetRequestToken();
                zonesDataTransfer.Add(zone, token);
                return CreatedAtRoute("DefaultApi", new { name = zone.Name }, zone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: api/Zones/5
        public IHttpActionResult Put(Guid id, [FromBody] ZoneDTO zone)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = zonesDataTransfer.Update(id, zone, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, zone);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE: api/Zones/5
        public IHttpActionResult Delete(Guid id)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = zonesDataTransfer.Delete(id, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
