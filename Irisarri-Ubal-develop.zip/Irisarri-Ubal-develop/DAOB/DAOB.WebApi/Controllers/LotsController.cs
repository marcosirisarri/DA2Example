﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    [RoutePrefix("api")]
    public class LotsController : CommonApiController
    {
        private ILotsDataTransfer lotsDataTransfer;

        public LotsController(ILotsDataTransfer logic)
        {
            lotsDataTransfer = logic;
        }

        // GET: api/Lots
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                var lots = lotsDataTransfer.GetAllLots(token);
                if (lots == null)
                {
                    return NotFound();
                }
                return Ok(lots);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Lots/lotName
        [Route("Lots/{name}")]
        [HttpGet]
        public IHttpActionResult Get([FromUri]string name)
        {
            try
            {
                Guid token = GetRequestToken();
                var lot = lotsDataTransfer.GetByName(name, token);
                if (lot == null)
                {
                    return NotFound();
                }
                return Ok(lot);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [Route("Lots/ReadyToDepart")]
        public IHttpActionResult GetReadyToDepartLots()
        {
            try
            {
                Guid token = GetRequestToken();
                var lots = lotsDataTransfer.GetReadyToDepartLots(token);
                if (lots == null)
                {
                    return NotFound();
                }
                return Ok(lots);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Lots
        public IHttpActionResult Post([FromBody]LotDTO newLot)
        {
            try
            {
                Guid token = GetRequestToken();
                lotsDataTransfer.Add(newLot, token);
                return CreatedAtRoute("DefaultApi", new { name = newLot.Name }, newLot);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
