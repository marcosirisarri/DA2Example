﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using DAOB.WebApi.Models;
using DAOB.WebApi.DataTransfer;

namespace DAOB.WebApi.Controllers
{
    [RoutePrefix("api")]
    public class VehiclesController : CommonApiController
    {
        private IVehiclesDataTransfer vehiclesDataTransfer;

        public VehiclesController(IVehiclesDataTransfer vehiclesDataTransfer)
        {
            this.vehiclesDataTransfer = vehiclesDataTransfer;
        }

        // GET: api/Vehicles
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                ICollection<VehicleDTO> vehicles = vehiclesDataTransfer.GetAllVehicles(token);
                if (vehicles == null || vehicles.Count == 0)
                {
                    return NotFound();
                }
                return Ok(vehicles);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Vehicles/5
        [Route("Vehicles/{VIN}")]
        [HttpGet]
        public IHttpActionResult Get([FromUri] string VIN)
        {
            try
            {
                Guid token = GetRequestToken();
                VehicleDTO vehicle = vehiclesDataTransfer.GetByVIN(VIN, token);
                if (vehicle == null)
                {
                    return NotFound();
                }
                return Ok(vehicle);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Vehicles
        public IHttpActionResult Post([FromBody] VehicleDTO vehicle)
        {
            try
            {
                Guid token = GetRequestToken();
                vehiclesDataTransfer.Add(vehicle, token);
                return CreatedAtRoute("DefaultApi", new { VIN = vehicle.VIN }, vehicle);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        // PUT: api/Vehicles/5
        public IHttpActionResult Put([FromBody] VehicleDTO vehicle)
        {
            try
            {
                Guid token = GetRequestToken();
                if (vehicle == null)
                {
                    return BadRequest("Vehículo a actualizar vacío");
                }
                bool updateResult = vehiclesDataTransfer.Update(vehicle.Id, vehicle, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, vehicle);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE: api/Vehicles/5
        [Route("Vehicles/{id}")]
        [HttpDelete]
        public IHttpActionResult Delete([FromUri] Guid id)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = vehiclesDataTransfer.Delete(id, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
