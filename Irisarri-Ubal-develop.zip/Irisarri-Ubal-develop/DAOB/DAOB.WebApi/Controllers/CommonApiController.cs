﻿using DAOB.WebApi.Exceptions;
using System;
using System.Linq;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public abstract class CommonApiController : ApiController
    {
        protected Guid GetRequestToken()
        {
            CheckTokenAvailability();
            string receivedToken = Request.Headers.GetValues("sessiontoken").First().ToString();
            return Guid.Parse(receivedToken);
        }

        protected void CheckTokenAvailability()
        {
            if (Request == null || !Request.Headers.Contains("sessiontoken"))
            {
                throw new MissingPermissionException("Sesión invalida");
            }
        }
    }
}

