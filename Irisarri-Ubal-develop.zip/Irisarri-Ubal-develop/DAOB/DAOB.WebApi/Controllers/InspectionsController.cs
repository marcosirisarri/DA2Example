﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class InspectionsController : CommonApiController
    {
        private IInspectionsDataTransfer inspectionsDataTransfer;

        public InspectionsController(IInspectionsDataTransfer inspectionsDataTransfer)
        {
            this.inspectionsDataTransfer = inspectionsDataTransfer;
        }

        // GET: api/Inspections
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                ICollection<InspectionDTO> inspections = inspectionsDataTransfer.GetAllInspections(token);
                if (inspections == null)
                {
                    return NotFound();
                }
                return Ok(inspections);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Inspections/AFAR42R3RG2WF42
        public IHttpActionResult Get(Guid id)
        {
            try
            {
                Guid token = GetRequestToken();
                InspectionDTO inspection = inspectionsDataTransfer.GetById(id, token);
                if (inspection == null)
                {
                    return NotFound();
                }
                return Ok(inspection);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        // POST: api/Inspections
        public IHttpActionResult Post([FromBody] InspectionDTO newInspection)
        {
            try
            {
                Guid token = GetRequestToken();
                inspectionsDataTransfer.Add(newInspection, token);
                return CreatedAtRoute("DefaultApi", new { DateTime = newInspection.DateTime }, newInspection);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
