﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class TransportsController : CommonApiController
    {
        private ITransportsDataTransfer transportsDataTransfer;

        public TransportsController(ITransportsDataTransfer transportsDataTransfer)
        {
            this.transportsDataTransfer = transportsDataTransfer;
        }

        // POST: api/Transports
        public IHttpActionResult Post([FromBody] TransportDTO newTransport)
        {
            try
            {
                Guid token = GetRequestToken();
                transportsDataTransfer.Add(newTransport, token);
                return CreatedAtRoute("DefaultApi", new { StartDate = newTransport.StartDate }, newTransport);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: api/Transports/5
        public IHttpActionResult Put(Guid id, DateTime endDate)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = transportsDataTransfer.MarkAsFinished(id, endDate, token);
                return Ok(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}