﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    public class ChangeHistoryController : CommonApiController
    {
        private IChangeHistoryDataTransfer changeHistoryDataTransfer;

        public ChangeHistoryController(IChangeHistoryDataTransfer changeHistoryDataTransfer)
        {
            this.changeHistoryDataTransfer = changeHistoryDataTransfer;
        }

        public IHttpActionResult Get([FromBody] Guid vehicleId)
        {
            try
            {
                ICollection<ChangeHistoryDTO> history = changeHistoryDataTransfer.Get(vehicleId);
                if (history == null)
                {
                    return NotFound();
                }
                return Ok(history);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
