﻿using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace DAOB.WebApi.Controllers
{
    [RoutePrefix("api")]
    public class UsersController : CommonApiController
    {
        private IUsersDataTransfer usersDataTransfer;

        public UsersController(IUsersDataTransfer usersDataTransfer)
        {
            this.usersDataTransfer = usersDataTransfer;
        }

        // GET: api/Users
        public IHttpActionResult Get()
        {
            try
            {
                Guid token = GetRequestToken();
                ICollection<UserDTO> users = usersDataTransfer.GetAllUsers(token);
                if (users == null || users.Count == 0)
                {
                    return NotFound();
                }
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Users/johng
        [Route("Users/{userName}")]
        [HttpGet]
        public IHttpActionResult Get([FromUri] string userName)
        {
            try
            {
                Guid token = GetRequestToken();
                UserDTO user = usersDataTransfer.GetByUserName(userName, token);
                if (user == null)
                {
                    return NotFound();
                }
                return Ok(user);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        // POST: api/Users
        public IHttpActionResult Post([FromBody] UserDTO user)
        {
            try
            {
                Guid token = GetRequestToken();
                usersDataTransfer.Add(user, token);
                return CreatedAtRoute("DefaultApi", new { name = user.UserName }, user);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // PUT: api/Users/5
        public IHttpActionResult Put([FromBody] UserDTO user)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = usersDataTransfer.Update(user.Id, user, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, user);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE: api/Users/5
        [Route("Users/{id}")]
        [HttpDelete]
        public IHttpActionResult Delete([FromUri] Guid id)
        {
            try
            {
                Guid token = GetRequestToken();
                bool updateResult = usersDataTransfer.Delete(id, token);
                return CreatedAtRoute("DefaultApi", new { updated = updateResult }, id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
