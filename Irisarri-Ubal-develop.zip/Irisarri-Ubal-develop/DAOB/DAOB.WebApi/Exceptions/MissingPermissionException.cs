﻿using System;
using System.Runtime.Serialization;

namespace DAOB.WebApi.Exceptions
{
    [Serializable]
    public class MissingPermissionException : Exception
    {
        public MissingPermissionException()
        {
        }

        public MissingPermissionException(string message) : base(message)
        {
        }

        public MissingPermissionException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected MissingPermissionException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}