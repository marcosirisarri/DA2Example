﻿using DAOB.DependencyResolver;
using Microsoft.Practices.Unity;
using System.Web.Http;

namespace DAOB.WebApi
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Configuración y servicios de API web

            var container = new UnityContainer();

            ComponentLoader.LoadContainer(container, ".\\bin", "DAOB.*.dll");

            config.EnableCors();
            config.DependencyResolver = new UnityResolver(container);

            // Rutas de API web
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
