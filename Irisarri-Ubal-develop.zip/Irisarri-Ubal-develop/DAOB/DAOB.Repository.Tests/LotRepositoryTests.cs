﻿using DAOB.Data.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class LotRepositoryTests
    {

        [TestMethod]
        public void GetReadyToDepartLotsRepository()
        {
            Lot fakeLot = new Lot()
            {
                CreatedBy = GetFakeCreator(),
                CreatedById = GetFakeCreator().Id,
                Carrier = GetFakeCarrier(),
                CarrierId = GetFakeCarrier().Id,
                Name = "TestLot",
                Description = "it's Ready To Depart",
                Status = LotState.ReadyToDepart,
                Vehicles = new List<Vehicle>()
                {
                    GetFakeVehicle()
                }
            };

            IEnumerable<Lot> fakeLots = new List<Lot>()
            {
                fakeLot
            };
            var lotRepository = new LotsRepository();
            var vehicleRepository = new VehiclesRepository();

            Guid id = lotRepository.Add(fakeLot);
            fakeLot.Id = id;
            //Act
            IEnumerable<Lot> obtainedResult = lotRepository.GetReadyToDepartLots();

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.IsTrue(obtainedResult.Contains(fakeLot));
            
            foreach(Vehicle v in fakeLot.Vehicles)
            {
                vehicleRepository.DeleteById(v.Id);
            }

        }

        private Vehicle GetFakeVehicle()
        {
            return new Vehicle()
            {
                Id = Guid.NewGuid(),
                VIN = "A89CD8DS735F232Q3",
                Brand = "Mercedes Benz",
                Model = "GLX-223",
                Year = 2015,
                Color = "Black",
                Type = VehicleType.Truck,
                State = VehicleState.ReadyToDepart
            };
        }

        private User GetFakeCarrier()
        {
            User carrier = new User()
            {
                Id = new Guid("ddddcccc-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCarrier",
                LastName = "test",
                UserName = "testCarrier",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.Carrier
                }
            };
            carrier.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLotTransportation } };

            return carrier;
        }

        private User GetFakeCreator()
        {
            User creator = new User()
            {
                Id = new Guid("eeeecccc-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCreator",
                LastName = "testC",
                UserName = "testCreator",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.YardOperator
                }
            };
            creator.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLot } };

            return creator;
        }

    }
}
