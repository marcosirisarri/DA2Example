﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using DAOB.Data.Entities;
using System.Linq;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class VehiclesRepositoryTests
    {
        private static ICollection<Vehicle> testVehicles;

        [ClassInitialize]
        public static void CreateTestObjects(TestContext context)
        {
            testVehicles = GetTestVehicles();
        }

        [TestInitialize]
        public void EmptyDBBeforeTests()
        {
            EmptyDB.EmptyAll();
        }

        [TestMethod]
        public void GetAllVehiclesOkTest()
        {
            //Arrange
            var expectedVehicles = GetTestVehicles();
            var repository = new VehiclesRepository();
            AddVehiclesList(repository);

            //Act
            ICollection<Vehicle> obtainedResult = repository.GetAll();

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedVehicles.Count, obtainedResult.Count);
        }

        [TestMethod]
        public void GetAllVehiclesErrorNotFoundTest()
        {
            //Arrange
            var repository = new VehiclesRepository();

            //Act
            var obtainedResult = repository.GetAll();

            //Assert
            Assert.AreEqual(obtainedResult.Count, 0);
        }

        [TestMethod]
        public void GetVehicleByVINOkTest()
        {
            //Arrange
            var testVehicle = GetATestVehicle();
            var testVIN = testVehicle.VIN;
            var repository = new VehiclesRepository();
            AddVehiclesList(repository);

            //Act
            var obtainedResult = repository.GetByVIN(testVIN);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(testVIN, obtainedResult.VIN);
        }

        [TestMethod]
        public void GetVehicleByVINNotFoundErrorTest()
        {
            //Arrange
            var fakeVIN = Guid.NewGuid().ToString();
            var repository = new VehiclesRepository();

            //Act
            var obtainedResult = repository.GetByVIN(fakeVIN);

            //Assert
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void CreateNewVehicleTestOk()
        {
            //Arrange
            var testVehicle = GetATestVehicle();
            var repository = new VehiclesRepository();

            //Act
            repository.Add(testVehicle);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullVehicleErrorTest()
        {
            //Arrange
            Vehicle nullVehicle = null;
            var repository = new VehiclesRepository();

            //Act
            repository.Add(nullVehicle);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateVINRepeatedVehicleErrorTest()
        {
            //Arrange
            Vehicle testVehicle = GetATestVehicle();
            Vehicle testVehicle2 = GetATestVehicle();
            var repository = new VehiclesRepository();

            //Act
            repository.Add(testVehicle);
            repository.Add(testVehicle2);
        }

        [TestMethod]
        public void UpdateExistingVehicleOkTest()
        {
            //Arrange
            var testVehicle = GetATestVehicle();
            var expectedResult = true;
            var repository = new VehiclesRepository();
            AddVehiclesList(repository);

            //Act
            var obtainedResult = repository.Update(testVehicle.Id, testVehicle);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void UpdateVehicleWithNullIdErrorTest()
        {
            //Arrange
            Vehicle nullVehicle = null;
            var expectedResult = false;
            var repository = new VehiclesRepository();

            //Act
            var obtainedResult = repository.Update(new Guid(), nullVehicle);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void DeleteVehicleOkTest()
        {
            //Arrange
            var testVehicle = GetATestVehicle();
            var expectedResult = true;
            var repository = new VehiclesRepository();
            AddVehiclesList(repository);

            //Act
            var obtainedResult = repository.DeleteById(testVehicle.Id);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void DeleteVehicleWithNullIdErrorTest()
        {
            //Arrange
            var expectedResult = false;
            var repository = new VehiclesRepository();

            //Act
            var obtainedResult = repository.DeleteById(new Guid());

            //Assert
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        private static ICollection<Vehicle> GetTestVehicles()
        {
            return new List<Vehicle>
            {
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "A89CD8DS735F232Q3",
                    Brand  = "Mercedes Benz",
                    Model = "GLX-223",
                    Year = 2015,
                    Color = "Black",
                    Type = VehicleType.Truck,
                    State = VehicleState.Arrived
                },
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "HY98UJC337UOK3MF2",
                    Brand  = "Audi",
                    Model = "A8",
                    Year = 2016,
                    Color = "White",
                    Type = VehicleType.Car,
                    State = VehicleState.Arrived
                },
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "AHS76GAR4342HER43",
                    Brand  = "Peugeot",
                    Model = "Partner",
                    Year = 2011,
                    Color = "Grey",
                    Type = VehicleType.Van,
                    State = VehicleState.Arrived
                }
            };
        }

        private Vehicle GetATestVehicle()
        {
            List<Vehicle> vehicles = testVehicles.ToList();
            return testVehicles.FirstOrDefault();
        }

        private void AddVehiclesList(IVehiclesRepository repository)
        {
            foreach (Vehicle vehicle in testVehicles)
            {
                repository.Add(vehicle);
            }
        }
    }
}