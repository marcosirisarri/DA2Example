﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using DAOB.Data.Entities;
using System.Linq;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class ZonesRepositoryTests
    {
        private static ICollection<Zone> testZones;

        [ClassInitialize]
        public static void CreateTestObjects(TestContext context)
        {
            testZones = GetTestZones();
        }

        [TestInitialize]
        public void EmptyDBBeforeTests()
        {
            EmptyDB.EmptyAll();
        }


        [TestMethod]
        public void GetAllZonesOkTest()
        {
            //Arrange
            var expectedZones = GetTestZones();
            var repository = new ZonesRepository();
            AddZonesList(repository);

            //Act
            var obtainedResult = repository.GetAll();

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedZones.Count, obtainedResult.Count);
        }

        [TestMethod]
        public void GetAllZonesErrorNotFoundTest()
        {
            //Arrange
            var repository = new ZonesRepository();

            //Act
            var obtainedResult = repository.GetAll();

            //Assert
            Assert.AreEqual(obtainedResult.Count, 0);
        }

        [TestMethod]
        public void GetZoneByNameOkTest()
        {
            //Arrange
            var testZone = GetATestZone();
            var testZoneName = testZone.Name;
            var repository = new ZonesRepository();
            AddZonesList(repository);

            //Act
            var obtainedResult = repository.GetByName(testZoneName);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(testZoneName, obtainedResult.Name);
        }

        [TestMethod]
        public void GetZoneByNameNotFoundErrorTest()
        {
            //Arrange
            var fakeName = Guid.NewGuid().ToString();
            var repository = new ZonesRepository();

            //Act
            var obtainedResult = repository.GetByName(fakeName);

            //Assert
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void CreateNewZoneTestOk()
        {
            //Arrange
            var testZone = GetATestZone();
            var repository = new ZonesRepository();

            //Act
            repository.Add(testZone);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullZoneErrorTest()
        {
            //Arrange
            Zone nullZone = null;
            var repository = new ZonesRepository();

            //Act
            repository.Add(nullZone);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateNameRepeatedZoneErrorTest()
        {
            //Arrange
            Zone testZone = GetATestZone();
            Zone testZone2 = GetATestZone();
            var repository = new ZonesRepository();

            //Act
            repository.Add(testZone);
            repository.Add(testZone2);
        }

        [TestMethod]
        public void UpdateExistingZoneOkTest()
        {
            //Arrange
            var testZone = GetATestZone();
            var expectedResult = true;
            var repository = new ZonesRepository();
            AddZonesList(repository);

            //Act
            var obtainedResult = repository.Update(testZone.Id, testZone);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void UpdateZoneWithNullIdErrorTest()
        {
            //Arrange
            Zone nullZone = null;
            var expectedResult = false;
            var repository = new ZonesRepository();

            //Act
            var obtainedResult = repository.Update(new Guid(), nullZone);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void DeleteZoneOkTest()
        {
            //Arrange
            var testZone = GetATestZone();
            var expectedResult = true;
            var repository = new ZonesRepository();
            AddZonesList(repository);

            //Act
            var obtainedResult = repository.DeleteById(testZone.Id);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        public void DeleteZonesWithNullIdErrorTest()
        {
            //Arrange
            var expectedResult = false;
            var repository = new ZonesRepository();

            //Act
            var obtainedResult = repository.DeleteById(new Guid());

            //Assert
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        private static ICollection<Zone> GetTestZones()
        {
            return new List<Zone>
            {
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z1",
                    Subzones = new List<Subzone>()
                },
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z2",
                    Subzones = new List<Subzone>()
                },
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z3",
                    Subzones = new List<Subzone>()
                }
            };
        }

        private Zone GetATestZone()
        {
            List<Zone> zones = testZones.ToList();
            return zones.FirstOrDefault();
        }

        private void AddZonesList(IZonesRepository repository)
        {
            foreach (Zone zone in testZones)
            {
                repository.Add(zone);
            }
        }
    }
}
