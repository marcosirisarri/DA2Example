﻿using DAOB.Data.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class LotsRepositoryTests
    {
        /*private static ICollection<Permission> testPermissions;
        //private static Role testRole;
        private static UserDTO testCarrier;
        private static UserDTO testCreator;

        [ClassInitialize]
        public static void CreateTestObjects(TestContext context)
        {
            testPermissions = GetTestPermissions();
            testCarrier = GetFakeCarrier();
            testCreator = GetFakeCreator();
            
        }

        [TestInitialize]
        public void EmptyDBBeforeTests()
        {
            EmptyDB.EmptyAll();
        }

        [TestMethod]
        public void GetReadyToDepartLotsRepository()
        {
            var lotRepository = new LotsRepository();
            var vehicleRepository = new VehiclesRepository();
            var userRepository = new UsersRepository();
            userRepository.Add(testCarrier);
            userRepository.Add(testCreator);
            Vehicle vehicle = GetFakeVehicle();
            vehicleRepository.Add(vehicle);

            Lot fakeLot = new Lot()
            {
                CreatedBy = testCreator,
                CreatedById = testCreator.Id,
                Carrier = testCarrier,
                CarrierId = testCarrier.Id,
                Name = "TestLot",
                Description = "it's Ready To Depart",
                Status = LotState.ReadyToDepart,
                Vehicles = new List<Vehicle>()
                {
                    vehicle
                }
            };
            ICollection<Lot> fakeLots = new List<Lot>()
            {
                fakeLot
            };

            lotRepository.Add(fakeLot);
            ICollection<Lot> readyLots = lotRepository.GetReadyToDepartLots();

            Assert.AreEqual(fakeLots.FirstOrDefault(), readyLots.FirstOrDefault());
        }

        private Vehicle GetFakeVehicle()
        {
            return new Vehicle()
            {
                //Id = Guid.NewGuid(),
                VIN = "A89CD8DS735F232Q3",
                Brand = "Mercedes Benz",
                Model = "GLX-223",
                Year = 2015,
                Color = "Black",
                Type = VehicleType.Truck,
                State = VehicleState.ReadyToDepart
            };
        }

        private static User GetFakeCarrier()
        {
            User carrier = new User()
            {
                //Id = new Guid("ddddcccc-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCarrier",
                LastName = "test",
                UserName = "testCarrier2",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.Carrier
                }
            };
            carrier.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLotTransportation } };

            return carrier;
        }

        private static User GetFakeCreator()
        {
            UserDTO creator = new UserDTO()
            {
                //Id = new Guid("eeeecccc-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCreator",
                LastName = "testC",
                UserName = "testCreator2",
                Password = "test",
                RoleId = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.YardOperator
                }
            };
            creator.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLot } };

            return creator;
        }

        private static ICollection<Permission> GetTestPermissions()
        {
            return new List<Permission>
            {
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddInspection
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddLot
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddLotTransportation
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddUser
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddVehicle
                }
            };
        }
        */
    }
}