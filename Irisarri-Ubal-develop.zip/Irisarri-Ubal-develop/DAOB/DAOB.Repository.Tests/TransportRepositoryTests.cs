﻿using DAOB.Data.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class TransportRepositoryTests
    {/*
        [TestInitialize]
        public void EmptyDBBeforeTests()
        {
            EmptyDB.EmptyAll();
        }

        [TestMethod]
        public void CreateNewTransportOkTest()
        {
            //Arrange
            var testTransports = GetFakeTransport();
            var repository = new TransportsRepository();
            var userRepository = new UsersRepository();
            User carrier = GetFakeCarrier();
            //userRepository.Add(carrier);
            testTransports.Carrier = carrier;
            testTransports.CarrierId = carrier.Id;

            userRepository.Add(testTransports.Carrier);

            //Act
            repository.Add(testTransports);

            //userRepository.DeleteById(testTransports.Carrier.Id);
        }

        [TestMethod]
        public void MarkTransportAsFinishedOk()
        {
            var userRepository = new UsersRepository();
            var testCarrier = new User()
            {
                FirstName = "test",
                LastName = "carrier",
                UserName = "testCarrier",
                Password = "22",
                Role = new Role()
                {
                    Name = UserRole.Carrier,
                }
            };
            var testCreator = new User()
            {
                FirstName = "test",
                LastName = "creator",
                UserName = "testCreator",
                Password = "22",
                Role = new Role()
                {
                    Name = UserRole.Administrator
                }
            };
            var testCarrier2 = new User()
            {
                FirstName = "test2",
                LastName = "carrier2",
                UserName = "testCarrier2",
                Password = "222",
                Role = new Role()
                {
                    Name = UserRole.Administrator
                }
            };
            //userRepository.Add(testCarrier);
            //userRepository.Add(testCarrier2);
            //userRepository.Add(testCreator);
            //Arrange
            var testTransports = new Transport()
            {
                //Id = Guid.NewGuid(),
                Carrier = testCarrier,
                CarrierId = testCarrier.Id,
                StartDate = DateTime.Now,
                Lots = new List<Lot>()
                {
                    new Lot()
                    {
                        Carrier = testCarrier2,
                        CarrierId = testCarrier2.Id,
                        CreatedBy = testCreator,
                        CreatedById = testCreator.Id,
                        Description = "description1",
                        Name="fakeLot1",
                        Vehicles = GetFakeVehicles()
                    }
                }
            };
            var repository = new TransportsRepository();
            
            DateTime endDate = DateTime.Now;
            //userRepository.Add(testTransports.Carrier);
            //testTransports.CarrierId = testTransports.Carrier.Id;

            var lotRepository = new LotsRepository();
            var vehicleRepository = new VehiclesRepository();

            /*
            foreach (var lot in testTransports.Lots)
            {
                //foreach(var v in lot.Vehicles)
                //{
                //    vehicleRepository.Add(v);
                //}
                lotRepository.Add(lot);
            }
            */
            /*
            //Act
            repository.Add(testTransports);
            Assert.IsNull(testTransports.EndDate);
            repository.MarkAsFinished(testTransports, endDate);
            Assert.IsNotNull(testTransports.EndDate);
            Assert.AreEqual(endDate, testTransports.EndDate);
        }

        private static User GetFakeCarrier()
        {
            User carrier = new User()
            {
                //Id = new Guid("ddddcccc-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCarrier",
                LastName = "test",
                UserName = "testCarrier2",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.Carrier
                }
            };
            carrier.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLotTransportation } };

            return carrier;
        }
        private Transport GetFakeTransport()
        {
            Transport transport = new Transport()
            {
                //Id = Guid.NewGuid(),
                Carrier = new User()
                {
                    FirstName = "Test",
                    LastName = "Carrier",
                    Password = "no",
                    UserName = "testcarrier",
                    Role = new Role()
                    {
                        Id = Guid.NewGuid(),
                        Name = UserRole.Carrier,
                        Permissions = new List<Permission>()
                        {
                            new Permission()
                            {
                                Id = Guid.NewGuid(),
                                Name = RolePermission.StartTransport
                            }
                        }
                    }
                },
                StartDate = DateTime.Now,
                Lots = GetFakeLots()
            };
            return transport;
        }

        private ICollection<Lot> GetFakeLots()
        {
            return new List<Lot>()
            {
                new Lot()
                {
                    Description = "description1",
                    Name="fakeLot1",
                    Carrier = new User()
                    {
                        FirstName = "aaaaaaa",
                        LastName = "bbbbbbb",
                        UserName = "testcarrier12",
                        Password = "password12",
                        Role = new Role()
                        {
                            Name = UserRole.Carrier
                        }
                    },
                    Vehicles = GetFakeVehicles()
                }
            };
        }

        private ICollection<Vehicle> GetFakeVehicles()
        {
            return new List<Vehicle>
            {
                new Vehicle
                {
                    VIN = "A89CD8DS735F232Q3",
                    Brand  = "Mercedes Benz",
                    Model = "GLX-223",
                    Year = 2015,
                    Color = "Black",
                    Type = VehicleType.Truck
                },
                new Vehicle
                {
                    VIN = "HY98UJC337UOK3MF2",
                    Brand  = "Audi",
                    Model = "A8",
                    Year = 2016,
                    Color = "White",
                    Type = VehicleType.Car
                },
                new Vehicle
                {
                    VIN = "AHS76GAR4342HER43",
                    Brand  = "Peugeot",
                    Model = "Partner",
                    Year = 2011,
                    Color = "Grey",
                    Type = VehicleType.Van
                }
            };
        }
*/
    }
}
