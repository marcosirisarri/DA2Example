﻿namespace DAOB.Repository.Tests
{
    public static class EmptyDB
    {
        public static void EmptyAll()
        {
            using (var context = new DAOBDbContext())
            {
                EmptyTransports(context);
                EmptyLots(context);
                EmptyInspections(context);
                EmptyDamages(context);
                EmptyImages(context);
                EmptyUsers(context);
                EmptyVehicles(context);
                EmptyChangeHistory(context);
                EmptyZones(context);

                context.SaveChanges();
            }
        }

        private static void EmptyUsers(DAOBDbContext context)
        {
            foreach (var user in context.Users)
            {
                context.Users.Attach(user);
                context.Users.Remove(user);
            }
        }

        private static void EmptyChangeHistory(DAOBDbContext context)
        {
            foreach (var change in context.ChangeHistories)
            {
                context.ChangeHistories.Attach(change);
                context.ChangeHistories.Remove(change);
            }
        }

        private static void EmptyInspections(DAOBDbContext context)
        {
            foreach (var inspection in context.Inspections)
            {
                context.Inspections.Attach(inspection);
                context.Inspections.Remove(inspection);
            }
        }

        private static void EmptyDamages(DAOBDbContext context)
        {
            foreach (var damage in context.Damages)
            {
                context.Damages.Attach(damage);
                context.Damages.Remove(damage);
            }
        }

        private static void EmptyImages(DAOBDbContext context)
        {
            foreach (var image in context.DamageImages)
            {
                context.DamageImages.Attach(image);
                context.DamageImages.Remove(image);
            }
        }

        private static void EmptyVehicles(DAOBDbContext context)
        {
            foreach (var vehicle in context.Vehicles)
            {
                context.Vehicles.Attach(vehicle);
                context.Vehicles.Remove(vehicle);
            }
        }

        private static void EmptyZones(DAOBDbContext context)
        {
            foreach (var zone in context.Zones)
            {
                context.Zones.Attach(zone);
                context.Zones.Remove(zone);
            }
        }

        private static void EmptyTransports(DAOBDbContext context)
        {
            foreach (var transport in context.Transports)
            {
                context.Transports.Attach(transport);
                context.Transports.Remove(transport);
            }
        }

        private static void EmptyLots(DAOBDbContext context)
        {
            foreach (var lot in context.Lots)
            {
                context.Lots.Attach(lot);
                context.Lots.Remove(lot);
            }
        }
    }
}
