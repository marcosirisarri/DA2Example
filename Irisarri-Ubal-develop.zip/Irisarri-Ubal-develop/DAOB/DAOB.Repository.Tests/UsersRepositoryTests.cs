﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using DAOB.Data.Entities;
using System.Linq;

namespace DAOB.Repository.Tests
{
    [TestClass]
    public class UsersRepositoryTests
    {
        private static ICollection<Permission> testPermissions;
        private static ICollection<Role> testRoles;
        private static ICollection<User> testUsers;

        [ClassInitialize]
        public static void CreateTestObjects(TestContext context)
        {
            CreateAdminUser();
            testPermissions = GetTestPermissions();
            testRoles = GetTestRoles();
            testUsers = GetTestUsers();
        }

        private static void CreateAdminUser()
        {
            var testUser =
                new User
                {
                    FirstName = "testadmin",
                    LastName = "user",
                    UserName = "admin",
                    Password = "pass",
                    PhoneNumber = "09090909",
                    Role = new Role()
                    {
                        Name=0
                    }
                };
            var testUserName = testUser.UserName;

            var repository = new UsersRepository();
            repository.Add(testUser);
        }

        private static void AddRolesToDB()
        {
            //RoleRepository repository = new RoleRepository();
        }

        [TestInitialize]
        public void EmptyDBBeforeTests()
        {
            EmptyDB.EmptyAll();
        }

        [TestMethod]
        public void _TestTrue()
        {
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void GetAllUsersOkTest()
        {
            //Arrange
            var expectedUsers = testUsers;
            var repository = new UsersRepository();
            AddUsersList(repository);

            //Act
            ICollection<User> obtainedResult = repository.GetAll();

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedUsers.Count, obtainedResult.Count);
        }


        [TestMethod]
        public void GetAllUsersErrorNotFoundTest()
        {
            //Arrange
            var repository = new UsersRepository();

            //Act
            ICollection<User> obtainedResult = repository.GetAll();

            //Assert
            Assert.AreEqual(obtainedResult.Count, 0);
        }

        [TestMethod]
        public void GetUserByUserNameOkTest()
        {
            //Arrange
            var testUser =
                new User
                {
                    FirstName = "John",
                    LastName = "Mallek",
                    UserName = "johnm",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = testRoles.First()
                };
            var testUserName = testUser.UserName;

            var repository = new UsersRepository();
            repository.Add(testUser);

            //Act
            User obtainedResult = repository.GetByUserName(testUserName);
            
            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(testUserName, obtainedResult.UserName);
        }

        [TestMethod]
        public void GetUserByUserNameNotFoundErrorTest()
        {
            //Arrange
            var fakeUserName = Guid.NewGuid().ToString();
            var repository = new UsersRepository();

            //Act
            User obtainedResult = repository.GetByUserName(fakeUserName);

            //Assert
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void CreateNewUserTestOk()
        {
            //Arrange
            var testUser =
                new User
                {
                    FirstName = "John",
                    LastName = "Mallek",
                    UserName = "johnm",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = testRoles.First()
                };
            var repository = new UsersRepository();

            //Act
            repository.Add(testUser);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullUserErrorTest()
        {
            //Arrange
            User nullUser = null;
            var repository = new UsersRepository();

            //Act
            repository.Add(nullUser);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateUserNameRepeatedUserErrorTest()
        {
            //Arrange
            var testUser =
                new User
                {
                    FirstName = "Michael",
                    LastName = "Jackson",
                    UserName = "michael",
                    Password = "m123",
                    PhoneNumber = "4545 7327",
                    Role = testRoles.First()
                };
            var testUser2 =
                new User
                {
                    FirstName = "Michael",
                    LastName = "Jordan",
                    UserName = "michael",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = testRoles.First()
                };
            var repository = new UsersRepository();

            //Act
            repository.Add(testUser);
            repository.Add(testUser2);
        }

        [TestMethod]
        public void UpdateExistingUserOkTest()
        {
            //Arrange
            var testUser =
                new User
                {
                    FirstName = "John",
                    LastName = "Mallek",
                    UserName = "johnm",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = testRoles.First()
                };
            var expectedResult = true;
            var repository = new UsersRepository();
            repository.Add(testUser);
            testUser.LastName = "Smith";

            //Act
            var obtainedResult = repository.Update(testUser.Id, testUser);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }
        
        [TestMethod]
        public void UpdateUserWithNullIdErrorTest()
        {
            //Arrange
            User nullUser = null;
            var expectedResult = false;
            var repository = new UsersRepository();

            //Act
            var obtainedResult = repository.Update(new Guid(), nullUser);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }
        
        [TestMethod]
        public void DeleteUserOkTest()
        {
            //Arrange
            var testUser =
                new User
                {
                    FirstName = "John",
                    LastName = "Mallek",
                    UserName = "johnm",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = testRoles.First()
                };
            var expectedResult = true;
            var repository = new UsersRepository();
            repository.Add(testUser);

            //Act
            var obtainedResult = repository.DeleteById(testUser.Id);

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }
        
        [TestMethod]
        public void DeleteUserWithNullIdErrorTest()
        {
            //Arrange
            var expectedResult = false;
            var repository = new UsersRepository();

            //Act
            var obtainedResult = repository.DeleteById(new Guid());

            //Assert
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        private static ICollection<User> GetTestUsers()
        {
            List<Role> roles = testRoles.ToList();
            return new List<User>
            {
                new User
                {
                    //Id = new Guid(),
                    UserName = "johng",
                    Password  = "abc123",
                    FirstName = "John",
                    LastName = "Gallor",
                    PhoneNumber = "123 54 643 22",
                    Role = roles[0]
                },
                new User
                {
                    //Id = new Guid(),
                    UserName = "wallym",
                    Password  = "fred321",
                    FirstName = "Wally",
                    LastName = "Menner",
                    PhoneNumber = "3442 4342",
                    Role = roles[2]
                },
                new User
                {
                    //Id = new Guid(),
                    FirstName = "John",
                    LastName = "Mallek",
                    UserName = "johnm",
                    Password = "abc123",
                    PhoneNumber = "2373 7327",
                    Role = roles[0]
                },
                new User
                {
                    //Id = new Guid(),
                    FirstName = "Luke",
                    LastName = "Cahng",
                    UserName = "lukec",
                    Password = "deb322",
                    PhoneNumber = "8345 8453",
                    Role = roles[3]
                }
            };
        }

        private static ICollection<Role> GetTestRoles()
        {
            List<Permission> permissions = testPermissions.ToList();
            return new List<Role>
            {
                new Role
                {
                    //Id = new Guid("111ecccc-6fce-4b9f-a492-746c6c8a1bfa"),
                    Name = UserRole.Administrator,
                    Permissions = new List<Permission>
                    {
                        permissions[0],
                        permissions[1],
                        permissions[3]
                    }
                },
                new Role
                {
                    //Id = new Guid("111ecccc-6fce-4b9f-a492-746c6c8a1bfb"),
                    Name = UserRole.Carrier,
                    Permissions = new List<Permission>
                    {
                        permissions[2],
                        permissions[3]
                    }
                },
                new Role
                {
                    Id = new Guid("111ecccc-6fce-4b9f-a492-746c6c8a1bfc"),
                    Name = UserRole.PortOperator,
                    Permissions = new List<Permission>
                    {
                        permissions[1],
                        permissions[2]
                    }
                },
                new Role
                {
                    Id = new Guid("111ecccc-6fce-4b9f-a492-746c6c8a1bfd"),
                    Name = UserRole.YardOperator,
                    Permissions = new List<Permission>
                    {
                        permissions[0]
                    }
                }
            };
        }

        private static ICollection<Permission> GetTestPermissions()
        {
            return new List<Permission>
            {
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddInspection
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddLot
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddLotTransportation
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddUser
                },
                new Permission
                {
                    Id = Guid.NewGuid(),
                    Name = RolePermission.AddVehicle
                }
            };
        }

        private User GetATestUser()
        {
            return testUsers.FirstOrDefault();
        }

        private void AddUsersList(IUsersRepository repository)
        {
            foreach(User user in testUsers)
            {
                repository.Add(user);
            }
        }
    }
}