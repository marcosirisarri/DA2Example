﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.Data.Mappings
{
    public class LotMap : EntityTypeConfiguration<Lot>
    {
        public LotMap()
        {
            ToTable("Lots");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            //Property(c => c.ComponentType).IsRequired();
            Property(c => c.Name).IsRequired().HasMaxLength(250);
            Property(c => c.Description).HasMaxLength(250);
            //Property(c => c.Device).;
            //HasRequired(x => x.Type).WithMany().HasForeignKey(x => x.DeviceTypeId);
            //HasRequired(x => x.Type).WithOptional(x => x.Device);
        }
    }
}
