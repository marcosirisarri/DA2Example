﻿public enum VehicleType
{
    Car = 0,
    Truck = 1,
    SUV = 2,
    Van = 3,
    Minivan = 4
}

public enum UserRole
{
    Administrator = 0,
    Carrier = 1,
    PortOperator = 2,
    YardOperator = 3,
    Salesman = 4
}

public enum RolePermission
{
    AddLot = 1,
    AddInspection = 3,
    AddLotInspection = 17,
    AddLotTransportation = 2,
    AddSale = 21,
    AddYardInspection = 19,
    AddUser = 0,
    AddVehicle = 4,
    AddZone = 14,
    DeleteUser = 11,
    DeleteVehicle = 20,
    DeleteZone = 16,
    FinishTransport = 7,
    RetrieveInspection = 22,
    RetrieveLot = 9,
    RetrieveLotsReadyToDepart = 8,
    RetrieveUser = 10,
    RetrieveVehicle = 18,
    RetrieveZone = 13,
    StartTransport = 5,
    UpdateUser = 12,
    UpdateVehicle = 6,
    UpdateZone = 15
}

public enum VehicleState
{
    Arrived = 0,
    ReadyToDepart = 1,
    Departed = 2,
    YardArrived = 3,
    YardInspected = 4,
    ReadyForSale = 5,
    Sold = 6
}

public enum LotState
{
    Created = 0,
    ReadyToDepart = 1,
    Departed = 2,
    Delivered = 3
}

public enum InspectionTypes
{
    Lot = 0,
    Yard = 1
}

public enum LogAction
{
    UserLogin = 0,
    VehicleImport = 1
}