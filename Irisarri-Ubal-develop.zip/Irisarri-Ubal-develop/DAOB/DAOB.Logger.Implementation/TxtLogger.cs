﻿using DAOB.Logger.Definition;
using System;
using System.Collections.Generic;
using System.IO;

namespace DAOB.Logger.Implementation
{
    public class TxtLogger : LogBase
    {
        private string path = @"logs\application.log";

        public override void AddEntry(LogEntry entry)
        {
            CreateFileIfNotExistent();
            TextWriter tw = new StreamWriter(path, true);
            tw.WriteLine(entry);
            tw.Close();
        }

        private void CreateFileIfNotExistent()
        {
            string directoryName = Path.GetDirectoryName(path);
            if (!Directory.Exists(directoryName))
            {
                Directory.CreateDirectory("logs");
            }

            if (!File.Exists(path))
            {
                File.Create(path);
            }
        }

        public override ICollection<LogEntry> GetLogsBetweenDates(DateTime starDate, DateTime endDate)
        {
            ICollection<LogEntry> logEntries = new List<LogEntry>();
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    string[] entryFields = line.Split(LogBase.SEPARATOR);
                    LogEntry entry = GetLogEntry(entryFields);

                    if (entry.DateTime >= starDate && entry.DateTime <= endDate)
                    {
                        logEntries.Add(entry);
                    }
                }
            }
            return logEntries;
        }

        private static LogEntry GetLogEntry(string[] entryFields)
        {
            LogEntry entry = new LogEntry();
            entry.DateTime = Convert.ToDateTime(entryFields[0].Trim());
            entry.UserName = entryFields[1].Trim();
            entry.Action = entry.GetAction(entryFields[2].Trim());
            entry.Message = entryFields[3].Trim();
            return entry;
        }
    }
}
