﻿using System;
using System.Collections.Generic;
using System.IO;

namespace DAOB.Logger
{
    public class TxtLogger : ILogger
    {
        private string path = @"logs\log.txt";

        public void AddEntry(LogEntry entry)
        {
            CreateFileIfNotExistent();
            TextWriter tw = new StreamWriter(path, true);
            tw.WriteLine(entry);
            tw.Close();
        }

        private void CreateFileIfNotExistent()
        {
            string directoryName = Path.GetDirectoryName(path);
            if (!Directory.Exists(directoryName))
            {
                Directory.CreateDirectory("logs");
            }

            if (!File.Exists(path))
            {
                File.Create(path);
            }
        }

        public ICollection<LogEntry> GetLogsBetweenDates(DateTime starDate, DateTime endDate)
        {
            ICollection<LogEntry> result = new List<LogEntry>();
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    LogEntry entry = new LogEntry();
                }
            }
            return result;
        }
    }
}
