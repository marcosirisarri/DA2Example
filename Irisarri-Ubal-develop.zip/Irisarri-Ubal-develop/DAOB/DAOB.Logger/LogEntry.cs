﻿using System;

namespace DAOB.Logger
{
    public class LogEntry
    {
        public Guid Id { get; set; }
        public DateTime DateTime { get; set; }
        public string UserName { get; set; }
        public LogAction Action { get; set; }
        public string Message { get; set; }

        public override string ToString()
        {
            string logAction = Action == LogAction.UserLogin ? "Login" : "Vehicle import";
            return $"{DateTime} User: {UserName} Action: {logAction} Message: {Message}";
        }
    }
}
