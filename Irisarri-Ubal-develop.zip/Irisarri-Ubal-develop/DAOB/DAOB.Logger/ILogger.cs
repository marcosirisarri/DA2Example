﻿using System;
using System.Collections.Generic;

namespace DAOB.Logger
{
    public interface ILogger
    {
        void AddEntry(LogEntry entry);
        ICollection<LogEntry> GetLogsBetweenDates(DateTime starDate, DateTime endDate);
    }
}
