﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using DAOB.Logger.Definition;
using DAOB.Logger.Facade;

namespace DAOB.Logger.Tests
{
    [TestClass]
    public class LoggerTests
    {
        [TestMethod]
        public void AddLogEntryOkTest()
        {
            LogEntry entry = new LogEntry
            {
                Id = new Guid(),
                Action = LogAction.UserLogin,
                UserName = "admin",
                DateTime = DateTime.Now,
                Message = "One log entry"
            };

            LoggerUtil.AddEntry(entry);
        }

        [TestMethod]
        public void GetLogsBetweenDatesOkTest()
        {
            ICollection<LogEntry> logEntries = GetLogEntries();
            ICollection<LogEntry> expectedResult = new List<LogEntry>();
            expectedResult.Add(logEntries.ElementAt(1));
            expectedResult.Add(logEntries.ElementAt(2));
            foreach (LogEntry entry in logEntries)
            {
                LoggerUtil.AddEntry(entry);
            }

            DateTime startDate = Convert.ToDateTime("20/10/2017");
            DateTime endDate = Convert.ToDateTime("30/10/2017");
            ICollection<LogEntry> entriesBetweenDates = LoggerUtil.GetLogsBetweenDates(startDate, endDate);

            Assert.AreEqual(entriesBetweenDates.Count, expectedResult.Count);
        }

        private ICollection<LogEntry> GetLogEntries()
        {
            return new List<LogEntry>
            {
                new LogEntry
                {
                    Id = new Guid(),
                    Action = LogAction.UserLogin,
                    UserName = "admin",
                    DateTime = Convert.ToDateTime("09/10/2017" ),
                    Message = "admin logs in"
                },
                new LogEntry
                {
                    Id = new Guid(),
                    Action = LogAction.VehicleImport,
                    UserName = "admin",
                    DateTime = Convert.ToDateTime("21/10/2017" ),
                    Message = "A vehicle is imported"
                },
                new LogEntry
                {
                    Id = new Guid(),
                    Action = LogAction.VehicleImport,
                    UserName = "josef",
                    DateTime = Convert.ToDateTime("25/10/2017" ),
                    Message = "Another vehicle is imported"
                }
            };
        }
    }
}
