﻿using DAOB.Data.Entities;
using DAOB.Repository.Mappings;
using System.Data.Entity;

namespace DAOB.Repository
{
    public class DAOBDbContext : DbContext
    {
        public DAOBDbContext() : base("name=DAOBDatabase") 
        {
            var ensureDLLIsCopied = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
            Database.Connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DAOBDatabase"].ConnectionString;
            Configuration.ProxyCreationEnabled = false;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new Base64ImageMapping());
            modelBuilder.Configurations.Add(new ChangeHistoryMapping());
            modelBuilder.Configurations.Add(new DamageMapping());
            modelBuilder.Configurations.Add(new InspectionMapping());
            modelBuilder.Configurations.Add(new LotMap());
            modelBuilder.Configurations.Add(new PermissionMap());
            modelBuilder.Configurations.Add(new RoleMap());
            modelBuilder.Configurations.Add(new SaleMappping());
            modelBuilder.Configurations.Add(new SessionMapping());
            modelBuilder.Configurations.Add(new SubzoneMapping());
            modelBuilder.Configurations.Add(new TransportMapping());
            modelBuilder.Configurations.Add(new UserMap());
            modelBuilder.Configurations.Add(new VehicleMap());
            modelBuilder.Configurations.Add(new ZoneMapping());

            base.OnModelCreating(modelBuilder);
        }

        public virtual DbSet<ChangeHistory> ChangeHistories { get; set; }
        public virtual DbSet<Base64Image> DamageImages { get; set; }
        public virtual DbSet<Damage> Damages { get; set; }
        public virtual DbSet<Inspection> Inspections { get; set; }
        public virtual DbSet<Lot> Lots { get; set; }
        public virtual DbSet<Permission> Permissions { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Sale> Sales { get; set; }
        public virtual DbSet<Session> Sessions { get; set; }
        public virtual DbSet<Subzone> Subzones { get; set; }
        public virtual DbSet<Transport> Transports { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Vehicle> Vehicles { get; set; }
        public virtual DbSet<Zone> Zones { get; set; }
    }
}
