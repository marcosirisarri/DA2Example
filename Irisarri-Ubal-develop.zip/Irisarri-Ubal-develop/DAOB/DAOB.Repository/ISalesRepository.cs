﻿using DAOB.Data.Entities;

namespace DAOB.Repository
{
    public interface ISalesRepository
    {
        void Add(Sale newSale);
    }
}
