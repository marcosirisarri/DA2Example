﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.Repository
{
    public interface ILotsRepository
    {
        ICollection<Lot> GetAll();
        Lot GetById(Guid id);
        Lot GetByName(string name);
        ICollection<Lot> GetReadyToDepartLots();
        void Add(Lot newLot);
        bool Update(Guid id, Lot updatedLot);
    }
}