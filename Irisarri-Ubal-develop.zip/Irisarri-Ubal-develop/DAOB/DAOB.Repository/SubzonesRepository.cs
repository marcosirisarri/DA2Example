﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository
{
    public class SubzonesRepository : ISubzonesRepository
    {
        public ICollection<Subzone> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Subzones.ToList();
            }
        }

        public Subzone GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Subzones.FirstOrDefault(s => s.Id.Equals(id));
            }
        }

        public Subzone GetByName(string name)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Subzones.FirstOrDefault(s => s.Name.Equals(name));
            }
        }

        public void Add(Subzone newSubzone)
        {
            if (newSubzone == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                if (context.Subzones.Any(s => s.Name.Equals(newSubzone.Name)))
                {
                    throw new ArgumentException("Subzone name already registered");
                }

                context.Subzones.Add(newSubzone);
                context.SaveChanges();
            }
        }

        public bool Update(Guid id, Subzone updatedSubzone)
        {
            using (var context = new DAOBDbContext())
            {
                Subzone originalSubzone = context.Subzones.FirstOrDefault(s => s.Id == id);
                if (originalSubzone == null)
                {
                    return false;
                }
                originalSubzone.Name = originalSubzone.Name;
                originalSubzone.MaxCapacity = originalSubzone.MaxCapacity;
                context.SaveChanges();
                return true;
            }
        }

        public bool DeleteById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                Subzone originalSubzone = context.Subzones.FirstOrDefault(s => s.Id == id);
                if (originalSubzone == null)
                {
                    return false;
                }
                context.Subzones.Remove(originalSubzone);
                context.SaveChanges();
                return true;
            }
        }
    }
}
