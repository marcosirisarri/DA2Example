﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository
{
    public class InspectionsRepository : IInspectionsRepository
    {
        public ICollection<Inspection> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Inspections.Include("Vehicle").Include("Inspector").Include("Damages").ToList();
            }
        }
        
        public Inspection GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Inspections.FirstOrDefault(i => i.Id.Equals(id));
            }
        }

        public void Add(Inspection newInspection)
        {
            if (newInspection == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                Vehicle vehicle = context.Vehicles.FirstOrDefault(v => v.Id.Equals(newInspection.Vehicle.Id));
                if (vehicle == null)
                {
                    throw new ArgumentException("Selected vehicle does not exist");
                }
                newInspection.Vehicle = vehicle;

                User inspector = context.Users.FirstOrDefault(u => u.Id.Equals(newInspection.Inspector.Id));
                if (inspector == null)
                {
                    throw new ArgumentException("Selected inspector does not exist");
                }
                newInspection.Inspector = inspector;
                
                context.Inspections.Add(newInspection);
                context.SaveChanges();
            }
        }
    }
}
