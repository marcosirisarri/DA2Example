﻿using System.Collections.Generic;
using DAOB.Data.Entities;
using System;

namespace DAOB.Repository
{
    public interface IVehiclesRepository
    {
        ICollection<Vehicle> GetAll();
        Vehicle GetById(Guid id);
        Vehicle GetByVIN(string VIN);
        void Add(Vehicle newVehicle);
        bool Update(Guid id, Vehicle updatedVehicle);
        bool DeleteById(Guid id);
    }
}