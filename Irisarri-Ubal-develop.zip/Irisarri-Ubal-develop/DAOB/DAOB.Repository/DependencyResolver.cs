﻿using DAOB.DependencyResolver;
using System.ComponentModel.Composition;

namespace DAOB.Repository
{
    [Export(typeof(IComponent))]
    public class DependencyResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<IChangeHistoryRepository, ChangeHistoryRepository>();
            registerComponent.RegisterType<IInspectionsRepository, InspectionsRepository>();
            registerComponent.RegisterType<ILotsRepository, LotsRepository>();
            registerComponent.RegisterType<ISessionsRepository, SessionsRepository>();
            registerComponent.RegisterType<ISubzonesRepository, SubzonesRepository>();
            registerComponent.RegisterType<ITransportsRepository, TransportsRepository>();
            registerComponent.RegisterType<IUsersRepository, UsersRepository>();
            registerComponent.RegisterType<IVehiclesRepository, VehiclesRepository>();
            registerComponent.RegisterType<IZonesRepository, ZonesRepository>();
            //Aca registraríamos otros tipos.
        }
    }
}
