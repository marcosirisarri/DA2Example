﻿using System.Collections.Generic;
using DAOB.Data.Entities;
using System;

namespace DAOB.Repository
{
    public interface IZonesRepository
    {
        ICollection<Zone> GetAll();
        Zone GetByName(string name);
        Zone GetById(Guid id);
        void Add(Zone newZone);
        bool Update(Guid id, Zone updatedZone);
        bool DeleteById(Guid id);
    }
}