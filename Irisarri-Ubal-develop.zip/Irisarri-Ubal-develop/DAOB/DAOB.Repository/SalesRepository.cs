﻿using DAOB.Data.Entities;
using System;

namespace DAOB.Repository
{
    public class SalesRepository : ISalesRepository
    {
        public void Add(Sale newSale)
        {
            if (newSale == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                context.Sales.Add(newSale);
                context.SaveChanges();
            }
        }
    }
}
