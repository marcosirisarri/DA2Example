﻿using System;
using System.Collections.Generic;
using DAOB.Data.Entities;

namespace DAOB.Repository
{
    public interface ISubzonesRepository
    {
        ICollection<Subzone> GetAll();
        Subzone GetById(Guid id);
        Subzone GetByName(string name);
        void Add(Subzone newSubzone);
        bool Update(Guid id, Subzone updatedSubzone);
        bool DeleteById(Guid id);
    }
}