﻿using DAOB.Data.Entities;
using System;
using System.Linq;

namespace DAOB.Repository
{
    public class SessionsRepository : ISessionsRepository
    {
        public Session Add(User user)
        {
            using (var context = new DAOBDbContext())
            {
                bool exists = context.Sessions.Any(s => s.User.Id.Equals(user.Id));
                if (exists)
                {
                    Session session = context.Sessions.FirstOrDefault<Session>(s => s.User.Id.Equals(user.Id));
                    return session;
                }
                else
                {
                    Session session = new Session();
                    User obtainedUser = context.Users.FirstOrDefault(u => u.Id == user.Id);
                    session.User = obtainedUser;
                    context.Sessions.Add(session);
                    context.SaveChanges();
                    return session;
                }
            }
        }

        public bool CheckPermission(Guid sessionToken, RolePermission permission)
        {
            using (var context = new DAOBDbContext())
            {
                Session session = context.Sessions.Include("User.Role.Permissions").FirstOrDefault<Session>(s => s.Id.Equals(sessionToken));
                if (session != null)
                {
                    bool hasPermission = session.User.Role.Permissions.Any(x => x.Name.Equals(permission));
                    Role administratorRole = context.Roles.FirstOrDefault(x => x.Name == UserRole.Administrator);
                    return hasPermission || session.User.Role.Id.Equals(administratorRole.Id);
                }
                return false;
            }
        }
    }
}
