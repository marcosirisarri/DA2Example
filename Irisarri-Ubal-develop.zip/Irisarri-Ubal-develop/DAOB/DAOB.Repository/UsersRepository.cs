﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository
{
    public class UsersRepository : IUsersRepository
    {
        public ICollection<User> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Users.Include("Role.Permissions").ToList();
            }
        }

        public User GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Users.Include("Role.Permissions").FirstOrDefault(u => u.Id.Equals(id));
            }
        }

        public User GetByUserName(string userName)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Users.Include("Role.Permissions").FirstOrDefault(u => u.UserName.Equals(userName));
            }
        }

        public void Add(User newUser)
        {
            if (newUser == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                Role role = context.Roles.FirstOrDefault(r => r.Id.Equals(newUser.Role.Id));
                if (role == null)
                {
                    throw new ArgumentException("Selected role does not exist");
                }
                newUser.Role = role;
                
                if (context.Users.Any(u => u.UserName.Equals(newUser.UserName)))
                {
                    throw new ArgumentException("User name already registered");
                }
                
                context.Users.Add(newUser);
                context.SaveChanges();
            }
        }

        public User Check(User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                User result = context.Users.Include("Role").FirstOrDefault(u => u.UserName.Equals(user.UserName) && u.Password.Equals(user.Password));
                return result;
            }
        }

        public bool Update(Guid id, User updatedUser)
        {
            using (var context = new DAOBDbContext())
            {
                User originalUser = context.Users.FirstOrDefault(u => u.Id == id);
                if (originalUser == null)
                {
                    return false;
                }
                Role role = context.Roles.FirstOrDefault(r => r.Id.Equals(updatedUser.Role.Id));
                if (role == null)
                {
                    throw new ArgumentException("Selected role does not exist");
                }
                originalUser.UserName = updatedUser.UserName;
                originalUser.Password = updatedUser.Password;
                originalUser.FirstName = updatedUser.FirstName;
                originalUser.LastName = updatedUser.LastName;
                originalUser.PhoneNumber = updatedUser.PhoneNumber;
                originalUser.Role = role;
                context.SaveChanges();
                return true;
            }
        }

        public bool DeleteById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                User user = context.Users.FirstOrDefault(u => u.Id == id);
                if (user == null)
                {
                    return false;
                }
                context.Users.Remove(user);
                context.SaveChanges();
                return true;
            }
        }

        public Role GetRoleById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Roles.FirstOrDefault(r => r.Id == id);
            }
        }
    }
}
