﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.Repository
{
    public class ChangeHistoryRepository : IChangeHistoryRepository
    {
        public ICollection<ChangeHistory> Get(Guid vehicleId)
        {
            using (var context = new DAOBDbContext())
            {
                return null;//CAMBIAR return context.ChangeHistories.Where(v => v.VehicleId.Equals(vehicleId)).ToList<ChangeHistory>();
            }
        }
    }
}
