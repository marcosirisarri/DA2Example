﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace DAOB.Repository
{
    public class TransportsRepository : ITransportsRepository
    {
        public Transport GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Transports.Include("Lots").Include("Vehicles").FirstOrDefault(t => t.Id.Equals(id));
            }
        }

        public void Add(Transport newTransport)
        {
            if (newTransport == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                User carrier = context.Users.FirstOrDefault(u => u.Id.Equals(newTransport.Carrier.Id));
                if (carrier == null)
                {
                    throw new ArgumentException("Selected carrier does not exist");
                }
                newTransport.Carrier = carrier;

                ICollection<Lot> lots = new List<Lot>(newTransport.Lots);
                newTransport.Lots.Clear();
                foreach (Lot l in lots)
                {
                    Lot lot = context.Lots.FirstOrDefault(x => x.Id.Equals(l.Id));
                    newTransport.Lots.Add(lot);
                }
                context.Transports.Add(newTransport);
                context.SaveChanges();
            }
        }

        public bool MarkAsFinished(Transport transport, DateTime endDate)
        {
            try
            {
                using (var context = new DAOBDbContext())
                {
                    transport.EndDate = endDate;
                    //context.Transports.Add(transport);
                    context.Entry(transport).State = EntityState.Modified;
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
