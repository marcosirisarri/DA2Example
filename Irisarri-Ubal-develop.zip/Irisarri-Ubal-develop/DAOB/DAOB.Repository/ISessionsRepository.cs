﻿using System;
using DAOB.Data.Entities;

namespace DAOB.Repository
{
    public interface ISessionsRepository
    {
        Session Add(User user);
        bool CheckPermission(Guid sessionToken, RolePermission addLot);
    }
}