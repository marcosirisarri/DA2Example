﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class Base64ImageMapping : EntityTypeConfiguration<Base64Image>
    {
        public Base64ImageMapping() 
        {
            ToTable("DamageImages");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Base64EncodedImage).IsRequired().HasMaxLength(5000);
            //HasRequired<Damage>(s => s.Damage).WithMany(s => s.Images).HasForeignKey(s => s.DamageId);
        }
    }
}
