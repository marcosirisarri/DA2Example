﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;


namespace DAOB.Repository.Mappings
{
    public class ZoneMapping : EntityTypeConfiguration<Zone>
    {
        public ZoneMapping()
        {
            ToTable("Zones");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Name).IsRequired().HasMaxLength(250);
            Property(c => c.MaxCapacity).IsRequired();
            HasMany<Subzone>(x => x.Subzones);
        }
    }
}
