﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.Repository.Mappings
{
    public class TransportMapping : EntityTypeConfiguration<Transport>
    {
        public TransportMapping()
        {
            ToTable("Transports");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.StartDate);
            Property(c => c.EndDate);
            HasRequired<User>(x => x.Carrier).WithMany().WillCascadeOnDelete(false);//.HasForeignKey(x => x.CarrierId).WillCascadeOnDelete(false);
            //HasMany(x => x.Lots);//.WithOptional().HasForeignKey(s => s.TransportId);//.WithRequired(t => t.Transport).HasForeignKey(s => s.TransportId).WillCascadeOnDelete(false);
        }
    }
}
