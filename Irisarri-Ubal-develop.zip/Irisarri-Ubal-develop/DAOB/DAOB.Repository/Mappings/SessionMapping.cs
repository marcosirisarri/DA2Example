﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class SessionMapping : EntityTypeConfiguration<Session>
    {
        public SessionMapping()
        {
            ToTable("Sessions");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasRequired(x => x.User).WithMany();//.WithMany().HasForeignKey(x => x.UserId).WillCascadeOnDelete(false);
        }
    }
}
