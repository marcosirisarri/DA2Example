﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class DamageMapping : EntityTypeConfiguration<Damage>
    {
        public DamageMapping()
        {
            ToTable("Damages");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Description).IsRequired().HasMaxLength(250);
            //HasRequired(x => x.Inspection).WithMany(s => s.Damages).HasForeignKey(s => s.InspectionId);
            HasMany(x => x.Images).WithMany();//.WithRequired(t => t.Damage).HasForeignKey(s => s.DamageId).WillCascadeOnDelete(true);
        }
    }
}
