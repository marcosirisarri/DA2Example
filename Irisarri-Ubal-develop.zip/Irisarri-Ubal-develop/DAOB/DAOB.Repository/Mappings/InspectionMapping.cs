﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class InspectionMapping : EntityTypeConfiguration<Inspection>
    {
        public InspectionMapping()
        {
            ToTable("Inspections");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Place).IsRequired().HasMaxLength(250);
            Property(c => c.DateTime).IsRequired();
            HasRequired<User>(x => x.Inspector).WithMany().WillCascadeOnDelete(false);
            HasRequired<Vehicle>(x => x.Vehicle).WithMany().WillCascadeOnDelete(false);
            HasMany(x => x.Damages);//.WithRequired(t => t.Inspection).HasForeignKey(s => s.InspectionId).WillCascadeOnDelete(true);
        }
    }
}