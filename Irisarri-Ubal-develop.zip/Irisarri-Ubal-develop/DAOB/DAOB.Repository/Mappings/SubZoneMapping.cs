﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;


namespace DAOB.Repository.Mappings
{
    public class SubzoneMapping : EntityTypeConfiguration<Subzone>
    {
        public SubzoneMapping() 
        {
            ToTable("Subzones");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Name).IsRequired().HasMaxLength(250);
            Property(c => c.MaxCapacity).IsRequired();
        }
    }
}
