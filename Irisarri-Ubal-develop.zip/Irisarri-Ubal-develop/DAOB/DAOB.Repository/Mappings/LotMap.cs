﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class LotMap : EntityTypeConfiguration<Lot>
    {
        public LotMap()
        {
            ToTable("Lots");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Name).IsRequired().HasMaxLength(250);
            Property(c => c.Description).HasMaxLength(250);
            HasRequired(x => x.Carrier).WithMany().WillCascadeOnDelete(false);
            HasRequired(x => x.CreatedBy).WithMany().WillCascadeOnDelete(false);
            //HasOptional<Transport>(x => x.Transport).WithOptionalDependent().Map(x => x.MapKey("TransportId"));
            //Property(c => c.Device).;
            //HasRequired(x => x.Type).WithMany().HasForeignKey(x => x.DeviceTypeId);
            //HasRequired(x => x.Type).WithOptional(x => x.Device);
        }
    }
}
