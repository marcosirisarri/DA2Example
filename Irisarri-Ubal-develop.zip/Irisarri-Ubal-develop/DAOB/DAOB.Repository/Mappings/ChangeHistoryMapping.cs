﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.Repository.Mappings
{
    public class ChangeHistoryMapping : EntityTypeConfiguration<ChangeHistory>
    {
        public ChangeHistoryMapping()
        {
            ToTable("ChangeHistories");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.Datetime).IsRequired();
            Property(c => c.Description).IsRequired().HasMaxLength(250);
            //HasRequired(x => x.Vehicle).WithMany(s => s.History).HasForeignKey(s => s.VehicleId);
        }
    }
}
