﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure.Annotations;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class VehicleMap : EntityTypeConfiguration<Vehicle>
    {
        public VehicleMap()
        {
            ToTable("Vehicles");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.VIN).IsRequired().HasMaxLength(250)
                .HasColumnAnnotation(IndexAnnotation.AnnotationName, new IndexAnnotation(new IndexAttribute("IX_VIN", 1) { IsUnique = true }));
            Property(c => c.Brand).IsRequired().HasMaxLength(250);
            Property(c => c.Model).IsRequired().HasMaxLength(250);
            Property(c => c.Year).IsRequired();
            Property(c => c.Type).IsRequired();
            Property(c => c.State).IsRequired();
            HasMany<ChangeHistory>(x => x.History);//.WithRequired(t => t.Vehicle).HasForeignKey(s => s.VehicleId).WillCascadeOnDelete(true);
            HasOptional(x => x.FirstInspection).WithOptionalDependent().Map(x => x.MapKey("FirstInspectionId"));
            HasOptional(x => x.YardInspection).WithOptionalDependent().Map(x => x.MapKey("YardInspectionId"));
        }
    }
}
