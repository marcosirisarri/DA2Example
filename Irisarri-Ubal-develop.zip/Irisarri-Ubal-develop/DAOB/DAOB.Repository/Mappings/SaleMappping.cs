﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class SaleMappping : EntityTypeConfiguration<Sale>
    {
        public SaleMappping()
        {
            ToTable("Sales");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasRequired(x => x.Vehicle).WithMany();
            HasRequired(x => x.Salesman).WithMany();
            HasRequired(x => x.Buyer).WithMany();
        }
    }
}
