﻿using DAOB.Data.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure.Annotations;
using System.Data.Entity.ModelConfiguration;

namespace DAOB.Repository.Mappings
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            ToTable("Users");

            HasKey(c => c.Id);
            Property(c => c.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(c => c.FirstName).IsRequired().HasMaxLength(250);
            Property(c => c.LastName).IsRequired().HasMaxLength(250);
            Property(c => c.UserName).IsRequired().HasMaxLength(250)
                .HasColumnAnnotation(IndexAnnotation.AnnotationName, new IndexAnnotation(new IndexAttribute("IX_UserName", 1) { IsUnique = true })); ;
            Property(c => c.Password).IsRequired().HasMaxLength(250);
            HasRequired(x => x.Role).WithMany();//.HasForeignKey(x => x.Role);
        }
    }
}
