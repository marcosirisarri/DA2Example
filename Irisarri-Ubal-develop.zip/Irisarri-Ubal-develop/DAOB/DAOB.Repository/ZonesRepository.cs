﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository
{
    public class ZonesRepository : IZonesRepository
    {
        public ICollection<Zone> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Zones.Include("Subzones").ToList();
            }
        }

        public Zone GetByName(string name)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Zones.Include("Subzones").FirstOrDefault(z => z.Name.Equals(name));
            }
        }

        public Zone GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Zones.Include("Subzones").FirstOrDefault(z => z.Id.Equals(id));
            }
        }

        public void Add(Zone newZone)
        {
            if (newZone == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                if (context.Zones.Any(z => z.Name.Equals(newZone.Name)))
                {
                    throw new ArgumentException("Zone name already registered");
                }
                
                context.Zones.Add(newZone);
                context.SaveChanges();
            }
        }

        public bool Update(Guid id, Zone updatedZone)
        {
            using (var context = new DAOBDbContext())
            {
                Zone originalZone = context.Zones.Include("Subzones").FirstOrDefault(z => z.Id == id);
                int maxCapacity = 0;
                if (originalZone == null)
                {
                    return false;
                }
                
                foreach (var subzone in updatedZone.Subzones)
                {
                    if (subzone.Id.Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                    {
                        originalZone.Subzones.Add(subzone);
                    }
                    maxCapacity += subzone.MaxCapacity;
                }

                originalZone.Name = updatedZone.Name;
                originalZone.MaxCapacity = maxCapacity;
                //context.Zones.Attach(originalZone);
                context.SaveChanges();
                return true;
            }
        }

        public bool DeleteById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                Zone zone = context.Zones.FirstOrDefault(z => z.Id == id);
                if (zone == null)
                {
                    return false;
                }
                context.Zones.Remove(zone);
                context.SaveChanges();
                return true;
            }
        }
    }
}
