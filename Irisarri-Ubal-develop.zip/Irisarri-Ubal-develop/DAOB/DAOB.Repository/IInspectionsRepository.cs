﻿using System.Collections.Generic;
using DAOB.Data.Entities;
using System;

namespace DAOB.Repository
{
    public interface IInspectionsRepository
    {
        ICollection<Inspection> GetAll();
        Inspection GetById(Guid id);
        void Add(Inspection newInspection);
    }
}