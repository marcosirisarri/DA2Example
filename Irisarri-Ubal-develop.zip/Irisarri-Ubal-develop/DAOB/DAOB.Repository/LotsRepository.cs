﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace DAOB.Repository
{
    public class LotsRepository : ILotsRepository
    {
        public ICollection<Lot> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Lots.Include("Vehicles").Include("CreatedBy").Include("Carrier").ToList();
            }
        }

        public Lot GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Lots.Include("Vehicles").Include("CreatedBy").Include("Carrier").FirstOrDefault(l => l.Id.Equals(id));
            }
        }

        public Lot GetByName(string name)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Lots.Include("Vehicles").Include("CreatedBy").Include("Carrier").FirstOrDefault(l => l.Name.Equals(name));
            }
        }

        public ICollection<Lot> GetReadyToDepartLots()
        {
            using (var context = new DAOBDbContext())
            {
                var query = context.Lots.Include("Vehicles").Include("CreatedBy").Include("Carrier").Where(l => l.Status == LotState.ReadyToDepart);
                List<Lot> lots = query.ToList();
                return lots;
            }
        }

        public void Add(Lot newLot)
        {
            if (newLot == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                User carrier = context.Users.FirstOrDefault(u => u.Id.Equals(newLot.Carrier.Id));
                if (carrier == null)
                {
                    throw new ArgumentException("Selected carrier does not exist");
                }
                newLot.Carrier = carrier;
                
                User creator = context.Users.FirstOrDefault(u => u.Id.Equals(newLot.CreatedBy.Id));
                if (creator == null)
                {
                    throw new ArgumentException("Selected creator does not exist");
                }
                newLot.CreatedBy = creator;

                ICollection<Vehicle> vehicles = new List<Vehicle>(newLot.Vehicles);
                newLot.Vehicles.Clear();
                foreach (Vehicle v in vehicles)
                {
                    Vehicle vehicle = context.Vehicles.FirstOrDefault(x => x.Id.Equals(v.Id));
                    newLot.AddVehicle(vehicle);
                }
                context.Lots.Add(newLot);
                context.SaveChanges();
            }
        }

        public bool Update(Guid id, Lot updatedLot)
        {
            using (var context = new DAOBDbContext())
            {
                Lot originalLot = context.Lots.FirstOrDefault(v => v.Id == id);
                if (originalLot == null)
                {
                    return false;
                }

                originalLot.Name = updatedLot.Name;
                originalLot.Description = updatedLot.Description;
                originalLot.Status = updatedLot.Status;

                User carrier = context.Users.FirstOrDefault(u => u.Id.Equals(updatedLot.Carrier.Id));
                if (carrier == null)
                {
                    throw new ArgumentException("Selected carrier does not exist");
                }
                originalLot.Carrier = carrier;

                User creator = context.Users.FirstOrDefault(u => u.Id.Equals(updatedLot.CreatedBy.Id));
                if (creator == null)
                {
                    throw new ArgumentException("Selected creator does not exist");
                }
                originalLot.CreatedBy = creator;

                originalLot.Vehicles.Clear();
                foreach (Vehicle v in updatedLot.Vehicles)
                {
                    Vehicle vehicle = context.Vehicles.FirstOrDefault(x => x.Id.Equals(v.Id));
                    originalLot.AddVehicle(vehicle);
                }

                context.SaveChanges();
                return true;
            }
        }
    }
}
