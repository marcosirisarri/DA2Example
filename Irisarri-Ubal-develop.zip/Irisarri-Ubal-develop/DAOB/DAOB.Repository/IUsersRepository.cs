﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;

namespace DAOB.Repository
{
    public interface IUsersRepository
    {
        ICollection<User> GetAll();
        User GetById(Guid id);
        User GetByUserName(string userName);
        void Add(User newUser);
        User Check(User user);
        bool Update(Guid id, User updatedUser);
        bool DeleteById(Guid id);

        Role GetRoleById(Guid id);
    }
}