﻿using System;
using System.Collections.Generic;
using DAOB.Data.Entities;

namespace DAOB.Repository
{
    public interface IChangeHistoryRepository
    {
        ICollection<ChangeHistory> Get(Guid vehicleId);
    }
}