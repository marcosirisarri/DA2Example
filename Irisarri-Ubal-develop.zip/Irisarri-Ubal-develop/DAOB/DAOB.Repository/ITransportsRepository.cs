﻿using System;
using DAOB.Data.Entities;

namespace DAOB.Repository
{
    public interface ITransportsRepository
    {
        Transport GetById(Guid id);
        void Add(Transport newTransport);
        bool MarkAsFinished(Transport transport, DateTime endDate);
    }
}