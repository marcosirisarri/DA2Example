﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Repository
{
    public class VehiclesRepository : IVehiclesRepository
    {
        public ICollection<Vehicle> GetAll()
        {
            using (var context = new DAOBDbContext())
            {
                return context.Vehicles.Include("History").ToList();
            }
        }

        public Vehicle GetById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Vehicles.Include("History").FirstOrDefault(v => v.Id.Equals(id));
            }
        }

        public Vehicle GetByVIN(string VIN)
        {
            using (var context = new DAOBDbContext())
            {
                return context.Vehicles.Include("History").FirstOrDefault<Vehicle>(v => v.VIN.Equals(VIN));
            }
        }

        public void Add(Vehicle newVehicle)
        {
            if(newVehicle == null)
            {
                throw new ArgumentNullException();
            }

            using (var context = new DAOBDbContext())
            {
                if(context.Vehicles.Any(v => v.VIN.Equals(newVehicle.VIN)))
                {
                    throw new ArgumentException("Vehicle VIN already registered");
                }

                context.Vehicles.Add(newVehicle);
                context.SaveChanges();
            }
        }

        public bool Update(Guid id, Vehicle updatedVehicle)
        {
            using (var context = new DAOBDbContext())
            {
                Vehicle originalVehicle = context.Vehicles.FirstOrDefault(v => v.Id == id);
                if (originalVehicle == null)
                {
                    return false;
                }
                originalVehicle.VIN = updatedVehicle.VIN;
                originalVehicle.Brand = updatedVehicle.Brand;
                originalVehicle.Model = updatedVehicle.Model;
                originalVehicle.Year = updatedVehicle.Year;
                originalVehicle.Color = updatedVehicle.Color;

                if (updatedVehicle.FirstInspection != null)
                {
                    Inspection firstInspection = context.Inspections.FirstOrDefault(i => i.Id == updatedVehicle.FirstInspection.Id);
                    originalVehicle.FirstInspection = firstInspection;
                }
                if (updatedVehicle.YardInspection != null)
                {
                    Inspection yardInspection = context.Inspections.FirstOrDefault(i => i.Id == updatedVehicle.YardInspection.Id);
                    originalVehicle.YardInspection = yardInspection;
                }
                originalVehicle.Type = updatedVehicle.Type;
                originalVehicle.State = updatedVehicle.State;

                if(updatedVehicle.History != null)
                {
                    originalVehicle.History = new List<ChangeHistory>();
                    foreach (ChangeHistory history in updatedVehicle.History)
                    {
                        ChangeHistory ch = context.ChangeHistories.FirstOrDefault(h => h.Id == history.Id);
                        if (ch != null)
                        {
                            originalVehicle.History.Add(ch);
                        }
                        else
                        {
                            originalVehicle.History.Add(history);
                        }
                    }
                }

                context.SaveChanges();
                return true;
            }
        }

        public bool DeleteById(Guid id)
        {
            using (var context = new DAOBDbContext())
            {
                Vehicle vehicle = context.Vehicles.Include("History").FirstOrDefault(v => v.Id == id);
                if (vehicle == null)
                {
                    return false;
                }
                context.Vehicles.Attach(vehicle);
                context.Vehicles.Remove(vehicle);
                context.SaveChanges();
                return true;
            }
        }
    }
}
