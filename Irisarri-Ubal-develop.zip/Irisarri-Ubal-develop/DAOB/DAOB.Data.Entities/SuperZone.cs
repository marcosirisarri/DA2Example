﻿using System;

namespace DAOB.Data.Entities
{
    public abstract class SuperZone
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int MaxCapacity { get; set; }
    }
}
