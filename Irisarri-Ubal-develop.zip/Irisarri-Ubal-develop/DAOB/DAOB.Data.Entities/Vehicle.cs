﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Vehicle
    {
        public Guid Id { get; set; }
        public string VIN { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
        public virtual Inspection FirstInspection { get; set; }
        public virtual Inspection YardInspection { get; set; }
        public VehicleType Type { get; set; }
        public VehicleState State { get; set; }
        public virtual ICollection<ChangeHistory> History { get; set; }
        
        public Vehicle()
        {
            State = VehicleState.Arrived;
            History = new List<ChangeHistory>();
        }

        public void AddChangeDetails(string description)
        {
            History.Add(new ChangeHistory()
            {
                Datetime = DateTime.Now,
                Description = description
            });
        }

        public void AddFirstInspection(Inspection inspection)
        {
            AddChangeDetails("Inspección de lote realizada.");
            FirstInspection = inspection;
            State = VehicleState.ReadyToDepart;
        }

        public void AddYardInspection(Inspection inspection)
        {
            AddChangeDetails("Inspección de patio realizada.");
            YardInspection = inspection;
            State = VehicleState.YardInspected;
        }

        public override bool Equals(object obj)
        {
            Vehicle vehicle = (Vehicle)obj;
            return vehicle.Id == Id;
        }
    }
}