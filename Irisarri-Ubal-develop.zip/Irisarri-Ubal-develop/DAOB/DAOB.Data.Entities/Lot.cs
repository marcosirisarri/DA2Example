﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Lot
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public LotState Status { get; set; }
        public virtual User Carrier { get; set; }
        public virtual User CreatedBy { get; set; }
        public virtual ICollection<Vehicle> Vehicles { get; set; }
        public virtual Transport Transport { get; set; }

        public Lot()
        {
            Status = LotState.Created;
            Vehicles = new List<Vehicle>();
        }

        public void AddVehicle(Vehicle v)
        {
            if (v != null)
            {
                Vehicles.Add(v);
            }
        }

        public void UpdateStatusAfterFirstInspection()
        {
            bool readytoDepart = true;
            foreach(Vehicle v in Vehicles)
            {
                if (v.State != VehicleState.ReadyToDepart)
                {
                    readytoDepart = false;
                }
            }

            if (readytoDepart)
            {
                Status = LotState.ReadyToDepart;
            }
        }

        // override object.Equals
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }
            
            return this.Id.Equals(((Lot)obj).Id);
        }

        public override int GetHashCode()
        {
            var hashCode = 1829809407;
            hashCode = hashCode * -1521134295 + EqualityComparer<Guid>.Default.GetHashCode(Id);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Description);
            return hashCode;
        }
    }
}
