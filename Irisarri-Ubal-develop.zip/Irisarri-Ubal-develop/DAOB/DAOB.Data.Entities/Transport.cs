﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Transport
    {
        public Guid Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual User Carrier { get; set; }
        public virtual ICollection<Lot> Lots { get; set; }

        public Transport()
        {
            Lots = new List<Lot>();
        }
    }
}
