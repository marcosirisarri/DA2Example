﻿using System;

namespace DAOB.Data.Entities
{
    public class Base64Image
    {
        public Guid Id { get; set; }
        public string Base64EncodedImage { get; set; }
    }
}
