﻿using System;

namespace DAOB.Data.Entities
{
    public class ChangeHistory
    {
        public Guid Id { get; set; }
        public DateTime Datetime { get; set; }
        public string Description { get; set; }
    }
}
