﻿using System;

namespace DAOB.Data.Entities
{
    public class Session
    {
        public Guid Id { get; set; }
        public virtual User User { get; set; }
    }
}
