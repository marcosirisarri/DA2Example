﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.Data.Entities
{
    public class User
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public virtual Role Role { get; set; }

        public bool CheckPermission(string permissionName)
        {
            return Role.Permissions.Any(x => x.Name.Equals(permissionName));
        }

        public override bool Equals(Object obj)
        {

            User userToCompare = obj as User;
            if (userToCompare == null)
            {
                return false;
            }
            else
            {
                return Id == userToCompare.Id;
            }
            
        }

        public override int GetHashCode()
        {
            var hashCode = -300303872;
            hashCode = hashCode * -1521134295 + EqualityComparer<Guid>.Default.GetHashCode(Id);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Password);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FirstName);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(LastName);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(PhoneNumber);
            hashCode = hashCode * -1521134295 + EqualityComparer<Role>.Default.GetHashCode(Role);
            return hashCode;
        }
    }
}
