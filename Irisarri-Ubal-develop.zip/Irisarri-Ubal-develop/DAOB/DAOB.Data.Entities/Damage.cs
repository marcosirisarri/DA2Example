﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Damage
    {
        public Guid Id { get; set; }
        public string Description { get; set; }
        public virtual ICollection<Base64Image> Images { get; set; }
    }
}
