﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Role
    {
        public Guid Id { get; set; }
        public UserRole Name { get; set; }
        public ICollection<Permission> Permissions { get; set; }

        public Role()
        {
            Permissions = new List<Permission>();
        }
    }
}
