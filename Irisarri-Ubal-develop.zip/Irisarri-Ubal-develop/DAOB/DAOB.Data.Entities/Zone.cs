﻿using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Zone : SuperZone
    {
        public virtual ICollection<Subzone> Subzones { get; set; }
    }
}
