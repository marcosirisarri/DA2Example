﻿using System;
using System.Collections.Generic;

namespace DAOB.Data.Entities
{
    public class Inspection
    {
        public Guid Id { get; set; }
        public DateTime DateTime { get; set; }
        public string Place { get; set; }
        public virtual Vehicle Vehicle { get; set; }
        public virtual User Inspector { get; set; }
        public virtual ICollection<Damage> Damages { get; set; }
        public InspectionTypes Type { get; set; }
    }
}