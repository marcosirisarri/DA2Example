﻿using System;

namespace DAOB.Data.Entities
{
    public class Buyer
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}
