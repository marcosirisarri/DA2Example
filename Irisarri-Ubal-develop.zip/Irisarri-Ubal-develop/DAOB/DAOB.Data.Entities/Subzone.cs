﻿namespace DAOB.Data.Entities
{
    public class Subzone : SuperZone
    {
    }
}
