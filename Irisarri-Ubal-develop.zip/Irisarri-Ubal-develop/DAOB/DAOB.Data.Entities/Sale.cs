﻿using System;

namespace DAOB.Data.Entities
{
    public class Sale
    {
        public Guid Id { get; set; }
        public virtual User Salesman { get; set; }
        public virtual Vehicle Vehicle { get; set; }
        public virtual Buyer Buyer { get; set; }
        public decimal Price { get; set; }
    }
}
