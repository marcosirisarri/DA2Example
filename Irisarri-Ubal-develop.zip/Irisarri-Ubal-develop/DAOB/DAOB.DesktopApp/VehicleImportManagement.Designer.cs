﻿namespace DAOB.DesktopApp
{
    partial class VehicleImportManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.vehiclePanel = new System.Windows.Forms.Panel();
            this.btnLoadImporter = new System.Windows.Forms.Button();
            this.btnReloadFiles = new System.Windows.Forms.Button();
            this.btnObtainVehicles = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstFiles
            // 
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.ItemHeight = 16;
            this.lstFiles.Location = new System.Drawing.Point(12, 73);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(249, 324);
            this.lstFiles.TabIndex = 0;
            // 
            // vehiclePanel
            // 
            this.vehiclePanel.Location = new System.Drawing.Point(379, 24);
            this.vehiclePanel.Name = "vehiclePanel";
            this.vehiclePanel.Size = new System.Drawing.Size(662, 566);
            this.vehiclePanel.TabIndex = 1;
            // 
            // btnLoadImporter
            // 
            this.btnLoadImporter.Location = new System.Drawing.Point(42, 515);
            this.btnLoadImporter.Name = "btnLoadImporter";
            this.btnLoadImporter.Size = new System.Drawing.Size(110, 56);
            this.btnLoadImporter.TabIndex = 2;
            this.btnLoadImporter.Text = "Cargar importador";
            this.btnLoadImporter.UseVisualStyleBackColor = true;
            this.btnLoadImporter.Click += new System.EventHandler(this.btnLoadImporter_Click);
            // 
            // btnReloadFiles
            // 
            this.btnReloadFiles.Location = new System.Drawing.Point(42, 421);
            this.btnReloadFiles.Name = "btnReloadFiles";
            this.btnReloadFiles.Size = new System.Drawing.Size(110, 56);
            this.btnReloadFiles.TabIndex = 3;
            this.btnReloadFiles.Text = "Recargar archivos";
            this.btnReloadFiles.UseVisualStyleBackColor = true;
            this.btnReloadFiles.Click += new System.EventHandler(this.btnReloadFiles_Click);
            // 
            // btnObtainVehicles
            // 
            this.btnObtainVehicles.Location = new System.Drawing.Point(183, 515);
            this.btnObtainVehicles.Name = "btnObtainVehicles";
            this.btnObtainVehicles.Size = new System.Drawing.Size(110, 56);
            this.btnObtainVehicles.TabIndex = 4;
            this.btnObtainVehicles.Text = "Obtener Vehiculos";
            this.btnObtainVehicles.UseVisualStyleBackColor = true;
            this.btnObtainVehicles.Click += new System.EventHandler(this.btnObtainVehicles_Click);
            // 
            // VehicleImportManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 619);
            this.Controls.Add(this.btnObtainVehicles);
            this.Controls.Add(this.btnReloadFiles);
            this.Controls.Add(this.btnLoadImporter);
            this.Controls.Add(this.vehiclePanel);
            this.Controls.Add(this.lstFiles);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "VehicleImportManagement";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Importar vehiculos";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstFiles;
        private System.Windows.Forms.Panel vehiclePanel;
        private System.Windows.Forms.Button btnLoadImporter;
        private System.Windows.Forms.Button btnReloadFiles;
        private System.Windows.Forms.Button btnObtainVehicles;
    }
}