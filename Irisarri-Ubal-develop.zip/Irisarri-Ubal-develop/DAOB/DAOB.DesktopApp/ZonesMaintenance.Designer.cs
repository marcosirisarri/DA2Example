﻿namespace DAOB.DesktopApp
{
    partial class ZonesMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstZones = new System.Windows.Forms.ListBox();
            this.btnAddZone = new System.Windows.Forms.Button();
            this.lstSubZones = new System.Windows.Forms.ListBox();
            this.btnModifyZone = new System.Windows.Forms.Button();
            this.btnDeleteZone = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDeleteSubZone = new System.Windows.Forms.Button();
            this.btnAddSubZone = new System.Windows.Forms.Button();
            this.btnModifySubZone = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstZones
            // 
            this.lstZones.FormattingEnabled = true;
            this.lstZones.ItemHeight = 16;
            this.lstZones.Location = new System.Drawing.Point(28, 38);
            this.lstZones.Name = "lstZones";
            this.lstZones.Size = new System.Drawing.Size(298, 276);
            this.lstZones.TabIndex = 0;
            this.lstZones.SelectedValueChanged += new System.EventHandler(this.lstZones_SelectedValueChanged);
            // 
            // btnAddZone
            // 
            this.btnAddZone.Location = new System.Drawing.Point(446, 57);
            this.btnAddZone.Name = "btnAddZone";
            this.btnAddZone.Size = new System.Drawing.Size(81, 33);
            this.btnAddZone.TabIndex = 1;
            this.btnAddZone.Text = "Agregar";
            this.btnAddZone.UseVisualStyleBackColor = true;
            this.btnAddZone.Click += new System.EventHandler(this.btnAddZone_Click);
            // 
            // lstSubZones
            // 
            this.lstSubZones.FormattingEnabled = true;
            this.lstSubZones.ItemHeight = 16;
            this.lstSubZones.Location = new System.Drawing.Point(28, 38);
            this.lstSubZones.Name = "lstSubZones";
            this.lstSubZones.Size = new System.Drawing.Size(298, 276);
            this.lstSubZones.TabIndex = 2;
            // 
            // btnModifyZone
            // 
            this.btnModifyZone.Enabled = false;
            this.btnModifyZone.Location = new System.Drawing.Point(446, 107);
            this.btnModifyZone.Name = "btnModifyZone";
            this.btnModifyZone.Size = new System.Drawing.Size(81, 33);
            this.btnModifyZone.TabIndex = 3;
            this.btnModifyZone.Text = "Modificar";
            this.btnModifyZone.UseVisualStyleBackColor = true;
            this.btnModifyZone.Click += new System.EventHandler(this.btnModifyZone_Click);
            // 
            // btnDeleteZone
            // 
            this.btnDeleteZone.Enabled = false;
            this.btnDeleteZone.Location = new System.Drawing.Point(446, 157);
            this.btnDeleteZone.Name = "btnDeleteZone";
            this.btnDeleteZone.Size = new System.Drawing.Size(81, 33);
            this.btnDeleteZone.TabIndex = 4;
            this.btnDeleteZone.Text = "Eliminar";
            this.btnDeleteZone.UseVisualStyleBackColor = true;
            this.btnDeleteZone.Click += new System.EventHandler(this.btnDeleteZone_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lstZones);
            this.groupBox1.Controls.Add(this.btnDeleteZone);
            this.groupBox1.Controls.Add(this.btnAddZone);
            this.groupBox1.Controls.Add(this.btnModifyZone);
            this.groupBox1.Location = new System.Drawing.Point(23, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(691, 336);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mantenimiento de Zonas";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDeleteSubZone);
            this.groupBox2.Controls.Add(this.lstSubZones);
            this.groupBox2.Controls.Add(this.btnAddSubZone);
            this.groupBox2.Controls.Add(this.btnModifySubZone);
            this.groupBox2.Location = new System.Drawing.Point(23, 374);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(696, 336);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Mantenimiento de SubZonas";
            // 
            // btnDeleteSubZone
            // 
            this.btnDeleteSubZone.Enabled = false;
            this.btnDeleteSubZone.Location = new System.Drawing.Point(446, 166);
            this.btnDeleteSubZone.Name = "btnDeleteSubZone";
            this.btnDeleteSubZone.Size = new System.Drawing.Size(81, 33);
            this.btnDeleteSubZone.TabIndex = 7;
            this.btnDeleteSubZone.Text = "Eliminar";
            this.btnDeleteSubZone.UseVisualStyleBackColor = true;
            this.btnDeleteSubZone.Click += new System.EventHandler(this.btnDeleteSubZone_Click);
            // 
            // btnAddSubZone
            // 
            this.btnAddSubZone.Location = new System.Drawing.Point(446, 66);
            this.btnAddSubZone.Name = "btnAddSubZone";
            this.btnAddSubZone.Size = new System.Drawing.Size(81, 33);
            this.btnAddSubZone.TabIndex = 5;
            this.btnAddSubZone.Text = "Agregar";
            this.btnAddSubZone.UseVisualStyleBackColor = true;
            this.btnAddSubZone.Click += new System.EventHandler(this.btnAddSubZone_Click);
            // 
            // btnModifySubZone
            // 
            this.btnModifySubZone.Enabled = false;
            this.btnModifySubZone.Location = new System.Drawing.Point(446, 116);
            this.btnModifySubZone.Name = "btnModifySubZone";
            this.btnModifySubZone.Size = new System.Drawing.Size(81, 33);
            this.btnModifySubZone.TabIndex = 6;
            this.btnModifySubZone.Text = "Modificar";
            this.btnModifySubZone.UseVisualStyleBackColor = true;
            this.btnModifySubZone.Click += new System.EventHandler(this.btnModifySubZone_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(784, 79);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(81, 33);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Salir";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ZonesMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 734);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ZonesMaintenance";
            this.Text = "ZonesMaintenance";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstZones;
        private System.Windows.Forms.Button btnAddZone;
        private System.Windows.Forms.ListBox lstSubZones;
        private System.Windows.Forms.Button btnModifyZone;
        private System.Windows.Forms.Button btnDeleteZone;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDeleteSubZone;
        private System.Windows.Forms.Button btnAddSubZone;
        private System.Windows.Forms.Button btnModifySubZone;
        private System.Windows.Forms.Button btnExit;
    }
}