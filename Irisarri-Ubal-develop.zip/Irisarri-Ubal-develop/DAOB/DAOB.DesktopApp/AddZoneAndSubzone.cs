﻿using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAOB.DesktopApp
{
    public partial class AddZoneAndSubzone : Form
    {
        public int Capacity { get; set; }
        public SuperZone Superzone { get; set; }
        private bool modify = false;
        private bool isSubZone = false;

        public AddZoneAndSubzone(SuperZone zone, bool isSubzone)
        {
            InitializeComponent();
            Superzone = zone;
            this.isSubZone = isSubzone;
            if (zone != null)
            {
                modify = true;
                this.Text = "Modificar";
                txtName.Text = Superzone.Name;
                numCapacity.Value = Superzone.MaxCapacity;
            }
        }

        
        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Debe ingresar un nombre", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!modify)
            {
                if (isSubZone)
                {
                    Superzone = new Subzone();
                }else
                {
                    Superzone = new Zone();
                }
            }
            Superzone.Name = txtName.Text;
            Superzone.MaxCapacity = (int)numCapacity.Value;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
