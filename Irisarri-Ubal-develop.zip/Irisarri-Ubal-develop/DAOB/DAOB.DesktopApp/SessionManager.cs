﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace DAOB.DesktopApp
{
    public class SessionManager
    {
        private static SessionManager instance = null;
        public Session Session { get; set; }

        public IUnityContainer Container { get; set; }

        private SessionManager() {
        }

        public static SessionManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new SessionManager();
                }
                return instance;
            }
        }
     
    }
}
