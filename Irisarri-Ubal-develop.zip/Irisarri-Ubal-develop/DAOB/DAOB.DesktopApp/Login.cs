﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAOB.DesktopApp
{
    public partial class Login : Form, ILogin
    {
        ISessionsBusinessLogic logic;
        SessionManager sessionManager;

        public Login()
        {
            InitializeComponent();
            SessionsRepository sessionsRepository = new SessionsRepository();
            UsersRepository usersRepository = new UsersRepository();
            logic = new SessionsBusinessLogic(sessionsRepository, usersRepository);
            sessionManager = SessionManager.Instance;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Debe ingresar un nombre de usuario", "Error de ingreso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            User user = new User()
            {
                UserName = txtUsername.Text,
                Password = mskPassword.Text
            };
            Session session = logic.Add(user);
            if (session != null)
            {
                sessionManager.Session = session;
                MainWindow mainWindow = new MainWindow();
                this.Hide();

                DialogResult result = mainWindow.ShowDialog();
                if (result == DialogResult.Cancel)
                {
                    this.Dispose();
                }

            }
            else
            {
                MessageBox.Show("Usuario y/o clave incorrectos", "Error de ingreso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
