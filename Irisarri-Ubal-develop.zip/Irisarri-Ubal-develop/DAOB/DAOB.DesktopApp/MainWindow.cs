﻿using DAOB.BusinessLogic;
using DAOB.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAOB.DesktopApp
{
    public partial class MainWindow : Form
    {
        IVehiclesBusinessLogic vehiclesBusinessLogic;
        IVehiclesRepository vehiclesRepository;
        ISessionsBusinessLogic sessionsBusinessLogic;
        ISessionsRepository sessionsRepository;
        IZonesBusinessLogic zonesBusinessLogic;
        IZonesRepository zonesRepository;
        ISubzonesBusinessLogic subzonesBusinessLogic;
        ISubzonesRepository subzonesRepository;

        SessionManager sessionManager;

        public MainWindow()
        {
            InitializeComponent();
            sessionManager = SessionManager.Instance;
            zonesRepository = new ZonesRepository();
            subzonesRepository = new SubzonesRepository();
            vehiclesRepository = new VehiclesRepository();
            sessionsRepository = new SessionsRepository();
            zonesBusinessLogic = new ZonesBusinessLogic(zonesRepository, sessionsRepository);
            subzonesBusinessLogic = new SubzonesBusinessLogic(subzonesRepository, sessionsRepository);
            vehiclesBusinessLogic = new VehiclesBusinessLogic(vehiclesRepository, sessionsRepository);
        }

        private void vehiclesMenuItem_Click(object sender, EventArgs e)
        {
            VehicleMaintenance maintenance = new VehicleMaintenance(vehiclesBusinessLogic, sessionsBusinessLogic);
            maintenance.ShowDialog();
        }

        private void zonesMenuItem_Click(object sender, EventArgs e)
        {
            ZonesMaintenance maintenance = new ZonesMaintenance(zonesBusinessLogic, subzonesBusinessLogic);
            maintenance.ShowDialog();
        }

        private void vehiclesImportMenuItem_Click(object sender, EventArgs e)
        {
            VehicleImportManagement vehicleImportManagement = new VehicleImportManagement();
            vehicleImportManagement.ShowDialog();
        }
    }
}
