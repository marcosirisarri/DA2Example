﻿using DAOB.BusinessLogic;
using DAOB.DependencyResolver;
using DAOB.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Unity;

namespace DAOB.DesktopApp
{
    static class Program
    {
        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var container = SessionManager.Instance.Container;
            //Application.Run(container.Resolve<Login>());
            Application.Run(new Login());
        }

        //public static IUnityContainer BuildContainer()
        //{
        //    var currentContainer = new UnityContainer();
        //    currentContainer.RegisterType<ISessionsBusinessLogic, SessionsBusinessLogic>();
        //    currentContainer.RegisterType<ILogin, Login>();
        //    currentContainer.RegisterType<ILotsRepository, LotsRepository>();
        //    currentContainer.RegisterType<IUsersRepository, UsersRepository>();
        //    currentContainer.RegisterType<IVehiclesRepository, VehiclesRepository>();
        //    currentContainer.RegisterType<IZonesRepository, ZonesRepository>();
        //    currentContainer.RegisterType<ISessionsRepository, SessionsRepository>();
        //    currentContainer.RegisterType<ITransportsRepository, TransportsRepository>();
        //    currentContainer.RegisterType<IInspectionsRepository, InspectionsRepository>();
        //    currentContainer.RegisterType<IChangeHistoryRepository, ChangeHistoryRepository>();
        //    return currentContainer;
        //}

    }
}
