﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace DAOB.DesktopApp
{
    public partial class VehicleMaintenance : Form
    {
        ICollection<Vehicle> vehicles;
        IVehiclesBusinessLogic vehiclesBusinessLogic;
        ISessionsBusinessLogic sessionsBusinessLogic;
        SessionManager sessionManager;
        bool isModify = false;

        public VehicleMaintenance(IVehiclesBusinessLogic businessLogic, ISessionsBusinessLogic sessionsBusinessLogic)
        {
            InitializeComponent();
            this.vehiclesBusinessLogic = businessLogic;
            this.sessionsBusinessLogic = sessionsBusinessLogic;
            sessionManager = SessionManager.Instance;
            ReloadVehicles();
            txtVINFilter.Focus();            
        }
        
        private void LoadVehicles(string filter)
        {
            var query = vehicles.Where(x => x.VIN.Contains(filter)).ToList<Vehicle>();
            lstVehicles.DataSource = query;
            lstVehicles.DisplayMember = "VIN";
            lstVehicles.Refresh();
            if (lstVehicles.Items.Count == 0)
            {
                CleanVehicleFields();
                btnDelete.Enabled = false;
                btnModify.Enabled = false;
            }
        }

        private void txtVINFilter_TextChanged(object sender, EventArgs e)
        {
            LoadVehicles(txtVINFilter.Text);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            isModify = false;
            btnModify.Enabled = false;
            btnDelete.Enabled = false;
            btnAccept.Enabled = true;
            btnCancel.Enabled = true;
            CleanVehicleFields();
            SetReadOnlyFields(false);
            txtVIN.Focus();
        }

        private void SetReadOnlyFields(bool status)
        {
            txtVIN.ReadOnly = status;
            txtBrand.ReadOnly = status;
            txtModel.ReadOnly = status;
            txtColor.ReadOnly = status;
            numYear.ReadOnly = status;
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txtVIN.Text))
            {
                MessageBox.Show("Debe ingresar un VIN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (String.IsNullOrWhiteSpace(txtBrand.Text))
            {
                MessageBox.Show("Debe ingresar una marca", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (String.IsNullOrWhiteSpace(txtModel.Text))
            {
                MessageBox.Show("Debe ingresar un modelo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (String.IsNullOrWhiteSpace(txtColor.Text))
            {
                MessageBox.Show("Debe ingresar un color", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            btnModify.Enabled = false;

            if (isModify)
            {
                Vehicle selectedVehicle = lstVehicles.SelectedItem as Vehicle;
                Vehicle vehicle = vehicles.FirstOrDefault(x => x.VIN == selectedVehicle.VIN);
                vehicle.Brand = txtBrand.Text;
                vehicle.Model = txtModel.Text;
                vehicle.Color = txtColor.Text;
                vehicle.Year = (int)numYear.Value;
                vehiclesBusinessLogic.Update(vehicle.Id, vehicle, sessionManager.Session.Id);
            }
            else
            {
                Vehicle vehicle = new Vehicle();
                vehicle.VIN = txtVIN.Text;
                vehicle.Brand = txtBrand.Text;
                vehicle.Model = txtModel.Text;
                vehicle.Color = txtColor.Text;
                vehicle.Year = (int)numYear.Value;

                vehiclesBusinessLogic.Add(vehicle, sessionManager.Session.Id);
                MessageBox.Show("Vehiculo ingresado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CleanVehicleFields();
            }
            EnableActionButtons();
            SetReadOnlyFields(true);
            ReloadVehicles();
        }

        private void ReloadVehicles()
        {
            vehicles = vehiclesBusinessLogic.GetAllVehicles(sessionManager.Session.Id);
            lstVehicles.DataSource = vehicles;
            lstVehicles.DisplayMember = "VIN";
            lstVehicles.Refresh();
        }

        private void EnableActionButtons()
        {
            btnAdd.Enabled = true;
            btnModify.Enabled = true;
            btnDelete.Enabled = true;
            btnDelete.Enabled = true;
            btnCancel.Enabled = false;
            btnAccept.Enabled = false;
        }

        private void CleanVehicleFields()
        {
            txtVIN.Text = "";
            txtBrand.Text = "";
            txtModel.Text = "";
            txtColor.Text = "";
            numYear.Value = DateTime.Now.Year;
        }

        private void lstVehicles_SelectedValueChanged(object sender, EventArgs e)
        {
            if (lstVehicles.SelectedIndex >= 0)
            {
                Vehicle vehicle = lstVehicles.SelectedItem as Vehicle;
                txtVIN.Text = vehicle.VIN;
                txtBrand.Text = vehicle.Brand;
                txtModel.Text = vehicle.Model;
                txtColor.Text = vehicle.Color;
                EnableActionButtons();
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (lstVehicles.SelectedIndex >= 0)
            {
                isModify = true;
                btnAdd.Enabled = false;
                btnDelete.Enabled = false;
                btnAccept.Enabled = true;
                btnCancel.Enabled = true;
                SetReadOnlyFields(false);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            SetReadOnlyFields(true);
            btnAdd.Enabled = true;
            btnAccept.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lstVehicles.SelectedIndex >= 0)
            {
                Vehicle selectedVehicle = lstVehicles.SelectedItem as Vehicle;
                DialogResult result = MessageBox.Show("¿Desea borrar el vehiculo de VIN " + selectedVehicle.VIN, "Borrado", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                
                if (result == DialogResult.Yes)
                {
                    vehiclesBusinessLogic.Delete(selectedVehicle.Id, sessionManager.Session.Id);
                    ReloadVehicles();
                }
            }
        }

        private void lstVehicles_DataSourceChanged(object sender, EventArgs e)
        {
            
        }
    }
}
