﻿using DAOB.BusinessLogic;
using DAOB.DependencyResolver;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.DesktopApp
{
    [Export(typeof(IComponent))]
    public class DependencyResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<ISessionsBusinessLogic, SessionsBusinessLogic>();
            registerComponent.RegisterType<IVehiclesBusinessLogic, VehiclesBusinessLogic>();
        }

    }
}
