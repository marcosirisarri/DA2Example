﻿using DAOB.VehicleImport;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.Repository;
using System.Reflection;
using System.IO;

namespace DAOB.DesktopApp
{
    public partial class VehicleImportManagement : Form
    {
        #region Loaded assembly fields
        SessionManager sessionManager;
        Assembly vehicleImportAssembly = null;
        Type vehicleImportType = null;
        object importInstance = null;
        #endregion

        #region Fields
        Dictionary<string, object> fieldsToReturn = new Dictionary<string, object>();
        List<AssemblyExtendedInfo> validAssemblies = new List<AssemblyExtendedInfo>();

        const int originalPositionY = 50;
        const int positionYIncrement = 30;

        int labelPositionX = 50;
        int labelPositionY = 50;
        int fieldPositionX = 200;
        int fieldPositionY = 50;
        #endregion
        #region Constructor
        public VehicleImportManagement()
        {
            InitializeComponent();
            sessionManager = SessionManager.Instance;
            LoadAssemblies();
        }
        #endregion

        #region private Methods
        private void LoadAssemblies()
        {
            validAssemblies.Clear();
            var files = Directory.GetFiles(@"D:\Plugins\", "*.dll"); //Environment.CurrentDirectory, "*.dll");
            
            foreach (var file in files)
            {
                Type[] types;
                try
                {
                    byte[] b = File.ReadAllBytes(file);
                    Assembly assembly = Assembly.Load(b);
                    types = assembly.GetTypes();
                }
                catch(Exception e)
                {
                    continue;  // Can't load as .NET assembly, so ignore
                }

                var interestingTypes =
                    types.Where(t => t.IsClass &&
                                     t.GetInterfaces().Contains(typeof(IVehicleImport))).ToList();// && t.Name.Equals(opcode, StringComparison.InvariantCultureIgnoreCase));
                foreach (var t in types)
                {
                    if (t.IsClass)
                    {
                        foreach (var i in t.GetInterfaces())
                        {
                            if (i.Name.Equals(typeof(IVehicleImport).Name))
                            {
                                validAssemblies.Add(new AssemblyExtendedInfo
                                {
                                    DisplayName = t.Assembly.GetName().Name,
                                    FilePath = file
                                });
                            }
                        }
                    }
                }
            }
            lstFiles.DataSource = validAssemblies;
            lstFiles.DisplayMember = "DisplayName";
            lstFiles.Refresh();
        }

        private void LoadAssembly(AssemblyExtendedInfo info)
        {
            try
            {
                vehicleImportAssembly = Assembly.LoadFile(@info.FilePath);
                vehicleImportType = vehicleImportAssembly.GetType("VehicleImport.VehicleImport");
                importInstance = Activator.CreateInstance(vehicleImportType);
                MethodInfo met = vehicleImportType.GetMethod("RequestFields");

                Dictionary<RequestedFieldType, string> fields = met.Invoke(importInstance, null) as Dictionary<RequestedFieldType, string>;
                if (fields != null && fields.Count > 0)
                {
                    DrawFields(fields);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void LoadAssembly(string path)
        {
            try
            {
                vehicleImportAssembly = Assembly.LoadFile(@path);
                vehicleImportType = vehicleImportAssembly.GetType("VehicleImport.VehicleImport");
                importInstance = Activator.CreateInstance(vehicleImportType);
                MethodInfo met = vehicleImportType.GetMethod("RequestFields");
                
                Dictionary<RequestedFieldType, string> fields = met.Invoke(importInstance, null) as Dictionary<RequestedFieldType, string>;
                if (fields != null && fields.Count > 0)
                {
                    DrawFields(fields);
                }                
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void DrawFields(Dictionary<RequestedFieldType, string> fields)
        {
            labelPositionY = originalPositionY;
            fieldPositionY = originalPositionY;
            vehiclePanel.Controls.Clear();
            fieldsToReturn.Clear();

            foreach (var field in fields)
            {
                ReturnValue returnValue = new ReturnValue();
                fieldsToReturn.Add(field.Value, returnValue);
                PlaceLabel(field.Value);

                switch (field.Key)
                {
                    case RequestedFieldType.String:
                    case RequestedFieldType.ConnectionString:
                        PlaceTextBox(returnValue);
                        break;
                    case RequestedFieldType.FilePath:
                        PlaceOpenFileDialog(returnValue);
                        break;
                    case RequestedFieldType.Date:
                        PlaceDatePicker(returnValue);
                        break;
                }
            }
        }

        private Vehicle VehicleFromImportDTO(VehicleImportDTO vehicleDTO)
        {
            return new Vehicle
            {
                VIN = vehicleDTO.VIN,
                Brand = vehicleDTO.Brand,
                Model = vehicleDTO.Model,
                Color = vehicleDTO.Color,
                Year = vehicleDTO.Year,
                Type = (VehicleType)vehicleDTO.Type
            };
        }

        private void PlaceLabel(string fieldName)
        {
            Label label = new Label();
            label.Text = fieldName;
            vehiclePanel.Controls.Add(label);
            label.Location = new Point(labelPositionX, labelPositionY);
        }

        private void PlaceTextBox(ReturnValue bindingObject)
        {
            TextBox textBox = new TextBox();
            textBox.Width = 200;
            textBox.DataBindings.Add("Text",
                                bindingObject,
                                "Value",
                                false,
                                DataSourceUpdateMode.OnPropertyChanged);
            vehiclePanel.Controls.Add(textBox);
            textBox.Location = new Point(fieldPositionX, fieldPositionY);
            UpdateFieldYPosition();
        }

        private void PlaceOpenFileDialog(ReturnValue bindingObject)
        {
            TextBox textBox = new TextBox();
            textBox.Width = 200;
            textBox.DataBindings.Add("Text",
                                bindingObject,
                                "Value",
                                false,
                                DataSourceUpdateMode.OnPropertyChanged);
            vehiclePanel.Controls.Add(textBox);
            textBox.Location = new Point(fieldPositionX, fieldPositionY);
            Button button = new Button();
            vehiclePanel.Controls.Add(button);
            button.Text = "Abrir";
            button.Location = new Point(fieldPositionX + 220, fieldPositionY);
            button.Click += delegate(object sender, EventArgs args) 
                            {
                                OpenFileDialog dialog = new OpenFileDialog();
                                DialogResult result = dialog.ShowDialog();
                                if (result != DialogResult.Cancel)
                                {
                                    textBox.Text = dialog.FileName;
                                }
                            };
            UpdateFieldYPosition();
        }

        private void PlaceDatePicker(ReturnValue bindingObject)
        {
            DateTimePicker picker = new DateTimePicker();
            picker.Width = 200;
            picker.DataBindings.Add("Value",
                                bindingObject,
                                "Value",
                                false,
                                DataSourceUpdateMode.OnPropertyChanged);
            vehiclePanel.Controls.Add(picker);
            picker.Location = new Point(fieldPositionX, fieldPositionY);
            UpdateFieldYPosition();
        }

        private void UpdateFieldYPosition()
        {
            labelPositionY += positionYIncrement;
            fieldPositionY += positionYIncrement;
        }
        #endregion

        #region Events

        private void btnObtainVehicles_Click(object sender, EventArgs e)
        {
            List<string> keys = new List<string>(fieldsToReturn.Keys);

            foreach (var key in keys)
            {
                ReturnValue returnValue = fieldsToReturn[key] as ReturnValue;
                fieldsToReturn[key] = returnValue.Value;
            }
            if (vehicleImportAssembly != null)
            {
                try
                {
                    VehicleImportDTO vehicleImportDTO = new VehicleImportDTO();
                    MethodInfo met = vehicleImportType.GetMethod("ObtainVehicles");
                    List<VehicleImportDTO> vehiclesDTO = met.Invoke(importInstance, new object[] { fieldsToReturn }) as List<VehicleImportDTO>;
                    VehiclesBusinessLogic logic = new VehiclesBusinessLogic(new VehiclesRepository(), new SessionsRepository());

                    foreach (var v in vehiclesDTO)
                    {
                        Vehicle vehicle = VehicleFromImportDTO(v);
                        logic.Add(vehicle, sessionManager.Session.Id);
                    }
                    MessageBox.Show("importación finalizada", "Importar vehículos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error al importar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void btnReloadFiles_Click(object sender, EventArgs e)
        {
            LoadAssemblies();
        }

        private void btnLoadImporter_Click(object sender, EventArgs e)
        {
            labelPositionY = originalPositionY;
            fieldPositionY = originalPositionY;
            vehiclePanel.Controls.Clear();
            if (lstFiles.SelectedItem != null)
            {
                AssemblyExtendedInfo info = lstFiles.SelectedItem as AssemblyExtendedInfo;
                LoadAssembly(info.FilePath);
            }
        }

        #endregion
    }

    public class ReturnValue
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public ReturnValue()
        {

        }
    }

    internal class AssemblyExtendedInfo
    {
        internal string FilePath { get; set; }
        internal string DisplayName { get; set; }
        public override string ToString()
        {
            return DisplayName;
        }
    }
}
