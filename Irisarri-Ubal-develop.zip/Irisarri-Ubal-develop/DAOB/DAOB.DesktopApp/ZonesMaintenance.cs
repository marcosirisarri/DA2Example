﻿using DAOB.BusinessLogic;
using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAOB.DesktopApp
{
    public partial class ZonesMaintenance : Form
    {
        ICollection<Zone> zones;
        ICollection<Subzone> subzones;
        IZonesBusinessLogic zonesBusinessLogic;
        ISubzonesBusinessLogic subzonesBusinessLogic;
        ISessionsBusinessLogic sessionsBusinessLogic;

        SessionManager sessionManager;

        public ZonesMaintenance(IZonesBusinessLogic zonesBusinessLogic, ISubzonesBusinessLogic subzonesBusinessLogic)
        {
            InitializeComponent();
            this.zonesBusinessLogic = zonesBusinessLogic;
            this.subzonesBusinessLogic = subzonesBusinessLogic;
            sessionManager = SessionManager.Instance;
            
            LoadZones();
        }

        private void LoadZones()
        {
            GetZonesFromDatabase();
            lstZones.DataSource = zones;
            lstZones.DisplayMember = "Name";
            lstZones.Refresh();
            btnModifyZone.Enabled = zones.Count > 0;
            btnDeleteZone.Enabled = zones.Count > 0;
        }

        private void GetZonesFromDatabase()
        {
            zones = zonesBusinessLogic.GetAllZones(sessionManager.Session.Id);
        }
        
        private void LoadSubZones()
        {
            Zone zone = lstZones.SelectedItem as Zone;
            if (zone != null)
            {
                subzones = zone.Subzones;
                IList<Subzone> sub = subzones.ToList();
                lstSubZones.DataSource = sub;
                lstSubZones.DisplayMember = "Name";
                lstSubZones.Refresh();

                btnModifySubZone.Enabled = sub.Count > 0;
                btnDeleteSubZone.Enabled = sub.Count > 0;
            }
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnAddZone_Click(object sender, EventArgs e)
        {
            AddZoneAndSubzone addZoneAndSubzone = new AddZoneAndSubzone(null, false);
            DialogResult result = addZoneAndSubzone.ShowDialog();
            if (result != DialogResult.Cancel)
            {
                Zone zone = addZoneAndSubzone.Superzone as Zone;
                zonesBusinessLogic.Add(zone, sessionManager.Session.Id);
                LoadZones();
            }
        }

        private void btnModifyZone_Click(object sender, EventArgs e)
        {
            if (lstZones.SelectedItem != null)
            {
                Zone zone = lstZones.SelectedItem as Zone;
                AddZoneAndSubzone addZoneAndSubzone = new AddZoneAndSubzone(zone, false);
                DialogResult result = addZoneAndSubzone.ShowDialog();
                if (result != DialogResult.Cancel)
                {
                    zone = addZoneAndSubzone.Superzone as Zone;
                    zonesBusinessLogic.Update(zone.Id, zone, sessionManager.Session.Id);
                    LoadZones();
                }
            }

        }

        private void btnAddSubZone_Click(object sender, EventArgs e)
        {
            if (lstZones.SelectedItem != null)
            {
                Zone zone = lstZones.SelectedItem as Zone;
                AddZoneAndSubzone addSubzone = new AddZoneAndSubzone(null, true);
                DialogResult result = addSubzone.ShowDialog();
                if (result != DialogResult.Cancel)
                {
                    Subzone subzone = addSubzone.Superzone as Subzone;
                    if (zone.Subzones == null)
                    {
                        zone.Subzones = new List<Subzone>();
                    }
                    zone.Subzones.Add(subzone);
                    zonesBusinessLogic.Update(zone.Id, zone, sessionManager.Session.Id);
                    LoadSubZones();
                }
            }
        }

        private void lstZones_SelectedValueChanged(object sender, EventArgs e)
        {
            if (lstZones.SelectedItem != null)
            {
                Zone zone = lstZones.SelectedItem as Zone;
                subzones = zone.Subzones;
                btnAddSubZone.Enabled = true;
                LoadSubZones();
            }
            else
            {
                btnAddSubZone.Enabled = false;
            }

        }

        private void btnModifySubZone_Click(object sender, EventArgs e)
        {
            Subzone subzone = lstSubZones.SelectedItem as Subzone;
            if (subzone != null)
            {
                AddZoneAndSubzone addZoneAndSubzone = new AddZoneAndSubzone(subzone, true);
                DialogResult result = addZoneAndSubzone.ShowDialog();
                if (result != DialogResult.Cancel)
                {
                    subzone = addZoneAndSubzone.Superzone as Subzone;
                    subzonesBusinessLogic.Update(subzone.Id, subzone, sessionManager.Session.Id);
                    LoadZones();
                    lstZones_SelectedValueChanged(sender, e);
                }
            }
        }

        private void btnDeleteSubZone_Click(object sender, EventArgs e)
        {
            Subzone subzone = lstSubZones.SelectedItem as Subzone;
            if (subzone != null)
            {
                AddZoneAndSubzone addZoneAndSubzone = new AddZoneAndSubzone(subzone, true);
                DialogResult result = MessageBox.Show("¿Desea eliminar la subzona '"+ subzone.Name + "' ?\n Solo podrá eliminar una subzona si no hay vehiculos en la misma.", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        subzonesBusinessLogic.Delete(subzone.Id, sessionManager.Session.Id);
                        LoadZones();
                    }
                    catch (Exception exception)
                    {
                        throw (exception);
                    }
                    LoadSubZones();
                }
            }
        }

        private void btnDeleteZone_Click(object sender, EventArgs e)
        {
            Zone zone = lstZones.SelectedItem as Zone;
            if (zone != null)
            {
                AddZoneAndSubzone addZoneAndSubzone = new AddZoneAndSubzone(zone, true);
                DialogResult result = MessageBox.Show("¿Desea eliminar la zona '" + zone.Name + "' ?\n Solo podrá eliminar una zona si esta no posee subzonas.", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        zonesBusinessLogic.Delete(zone.Id, sessionManager.Session.Id);
                    }
                    catch(DeleteZoneWithSubzonesException ex)
                    {
                        MessageBox.Show("La zona '" + zone.Name + "' contiene subzonas dentro.\n Debe eliminarlas primero antes de eliminar la zona.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception exception)
                    {
                        throw (exception);
                    }
                    finally
                    {
                        GetZonesFromDatabase();
                    }
                    LoadZones();
                }
            }
        }
    }
}
