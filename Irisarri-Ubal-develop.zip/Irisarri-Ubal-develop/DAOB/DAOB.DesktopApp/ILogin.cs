﻿using DAOB.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOB.DesktopApp
{
    public interface ILogin
    {
        //Login(ISessionBusinessLogic businessLogic);
    }
}
