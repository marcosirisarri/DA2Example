﻿using DAOB.BusinessLogic;
using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using System.Net.Http;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class TransportControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };

        }
        [TestMethod]
        public void AddTransportOk()
        {
            //Arrange
            Transport fakeTransport = new Transport();
            fakeTransport.Id = Guid.NewGuid();
            fakeTransport.StartDate = new DateTime();
            fakeTransport.EndDate = new DateTime();
            fakeTransport.Carrier = new User();
            fakeTransport.Lots = new List<Lot>();
            Assert.IsNotNull(fakeTransport);
        }

        [TestMethod]
        public void AddTransportOk2()
        {
            var fakeTransport = GetFakeTransport();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id));

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            IHttpActionResult obtainedResult = controller.Post(fakeTransport);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<TransportDTO>;

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeTransport.StartDate, createdResult.RouteValues["StartDate"]);
            Assert.AreEqual(fakeTransport, createdResult.Content);
        }

        [TestMethod]
        public void CreateNullTransportErrorTest()
        {
            //Arrange
            TransportDTO fakeTransport = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeTransport);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void CreateTransporWithoutLotsTest()
        {
            //Arrange
            TransportDTO fakeTransport = GetFakeTransport();
            fakeTransport.LotIds.Clear();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id))
                .Throws(new TransportWithoutVehiclesException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeTransport);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void CreateTransporWithoutPermissionsTest()
        {
            //Arrange
            TransportDTO fakeTransport = GetFakeTransport();
            Role role = new Role()
            {
                Id = Guid.NewGuid(),
                Name = UserRole.YardOperator,
                Permissions = new List<Permission>()
            };

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id))
                .Throws(new MissingPermissionException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeTransport);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        //[ExpectedException(typeof(ArgumentNullException))]
        public void CreateTransporWithoutCarrierTest()
        {
            //Arrange
            TransportDTO fakeTransport = GetFakeTransport();
            fakeTransport.CarrierId = new Guid();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id))
                .Throws(new TransportWithoutCarrierException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeTransport);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        //[ExpectedException(typeof(ArgumentNullException))]
        public void CreateTransporWithoutCarrierTest2()
        {
            //Arrange
            TransportDTO fakeTransport = GetFakeTransport();
            fakeTransport.CarrierId = new Guid();
            
            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.Add(fakeTransport, currentSession.Id))
                .Throws(new TransportWithoutCarrierException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeTransport);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }


        [TestMethod]
        public void MarkNullTransportAsFinishedTest()
        {
            //Arrange
            var fakeTransportId = new Guid();
            DateTime endDate = DateTime.Now;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.MarkAsFinished(fakeTransportId, endDate, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeTransportId, endDate);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void MarkTransportAsFinishedTestWithDateGreaterThanNow()
        {
            //Arrange
            var fakeTransport = GetFakeTransport();
            var fakeTransportId = fakeTransport.Id;
            DateTime endDate = DateTime.MaxValue;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.MarkAsFinished(fakeTransportId, endDate, currentSession.Id))
                .Throws(new FutureDateNotExpectedException());

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeTransportId, endDate);

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void MarkTransportAsFinishedTestOk()
        {
            //Arrange
            TransportDTO fakeTransport = GetFakeTransport();
            var fakeTransportId = fakeTransport.Id;
            DateTime endDate = DateTime.Now;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockTransportBusinessLogic = new Mock<ITransportsDataTransfer>();
            mockTransportBusinessLogic
                .Setup(bl => bl.MarkAsFinished(fakeTransportId, endDate, currentSession.Id))
                .Returns(true);

            var controller = new TransportsController(mockTransportBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeTransportId, endDate);
            var createdResult = obtainedResult as OkNegotiatedContentResult<Guid>;

            //Assert
            mockTransportBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(fakeTransportId, createdResult.Content);
        }

        private TransportDTO GetFakeTransport()
        {
            TransportDTO transport = new TransportDTO()
            {
                Id = Guid.NewGuid(),
                StartDate = DateTime.Now,
                LotIds = new List<Guid>(){ new Guid() },
                CarrierId = new Guid()
            };
            return transport;
        }
    }
}