﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using System.Linq;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using DAOB.WebApi.DataTransfer;
using DAOB.Data.Entities;
using DAOB.BusinessLogic.Exceptions;
using System.Net.Http;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class LotsControllerTests
    {
        private UserDTO CreatorWithNoPermissionToAddLot { get; set; }
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid("11111111-2222-3333-4444-555555555555"),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"),
                UserId = loggedUser.Id
            };

        }

        public LotsControllerTests()
        {
            //
            // TODO: Add constructor logic here
            //


        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion
        [ClassCleanup()]
        public static void MyClassCleanup()
        {

        }

        private User GetFakeCarrier()
        {
            User carrier = new User()
            {
                Id = new Guid("eeeeeeee-6fce-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCarrier",
                LastName = "test",
                UserName = "testCarrier",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.Carrier
                }
            };
            carrier.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLotTransportation } };

            return carrier;
        }

        private User GetFakeCreator()
        {
            User creator = new User()
            {
                Id = new Guid("cccccccc-cccc-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestCreator",
                LastName = "testC",
                UserName = "testCreator",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.YardOperator
                }
            };
            creator.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddLot } };

            return creator;
        }

        [TestMethod]
        public void AddNullLot()
        {
            //Arrange
            LotDTO fakeLot = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockLotBL = new Mock<ILotsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeLot, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new LotsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeLot);
            mockLotBL.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void AddLotWithoutName()
        {
            //Arrange
            LotDTO fakeLot = new LotDTO()
            {
                Name = ""
            };

            var mockLotBL = new Mock<ILotsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeLot, currentSession.Id))
                .Throws(new LotNameNotEmptyException());//Cambiar esto!!

            var controller = new LotsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeLot);
            mockLotBL.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));

        }

        [TestMethod]
        public void AddLotWithoutCreator()
        {
            //Arrange
            LotDTO fakeLot = new LotDTO()
            {
                Name = "TestLot",
                CreatedById = new Guid(),
                CarrierId = GetFakeCarrier().Id
            };

            var mockLotBL = new Mock<ILotsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeLot, currentSession.Id))
                .Throws(new LotWithoutCreatorException());//Cambiar esto!!

            var controller = new LotsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeLot);
            mockLotBL.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void AddLotWithACreator()
        {
            //Arrange
            var fakeLot = new LotDTO
            {
                Id = new Guid("e5020d0b-6fce-4b9f-a492-746c6c8a1bfa"),
                Name = "TestLot",
                CreatedById = GetFakeCreator().Id,
                CarrierId = GetFakeCarrier().Id
            };

            var mockLotBL = new Mock<ILotsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeLot, currentSession.Id));

            var controller = new LotsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeLot);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<LotDTO>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeLot.Name, createdResult.RouteValues["name"]);
            Assert.AreEqual(fakeLot, createdResult.Content);
        }


        [TestMethod]
        public void GetReadyToDepartLots()
        {
            LotDTO fakeLot = new LotDTO()
            {
                CreatedById = GetFakeCreator().Id,
                CarrierId = GetFakeCarrier().Id,
                Id = Guid.NewGuid(),
                Name = "TestLot",
                Description = "it's Ready To Depart",
                //Status = LotState.ReadyToDepart,
                VehicleIds = new List<Guid>()
                {
                    GetFakeVehicle().Id
                }
            };
            Inspection inspection = new Inspection()
            {
                Id = Guid.NewGuid(),
                Inspector = GetFakeCreator(),
                Place = "Top roof",
                DateTime = DateTime.Now
            };
            Vehicle vehicle = GetFakeVehicle();
            vehicle.FirstInspection = inspection;
            ICollection<LotDTO> fakeLots = new List<LotDTO>()
            {
                fakeLot
            };
            var mockLotBL = new Mock<ILotsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.GetReadyToDepartLots(currentSession.Id))
                .Returns(fakeLots);

            var controller = new LotsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.GetReadyToDepartLots();
            var createdResult = obtainedResult as OkNegotiatedContentResult<ICollection<LotDTO>>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual(fakeLots, createdResult.Content);
        }

        private Vehicle GetFakeVehicle()
        {
            return new Vehicle()
            {
                Id = Guid.NewGuid(),
                VIN = "A89CD8DS735F232Q3",
                Brand = "Mercedes Benz",
                Model = "GLX-223",
                Year = 2015,
                Color = "Black",
                Type = VehicleType.Truck,
                State = VehicleState.ReadyToDepart
            };
        }
            
        /*
        [TestMethod]
        public void AddLotWithoutACarrier()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = null
            };
            try
            {
                l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
                controller.POST(l);
                Assert.Fail();
            }
            catch (LotWithoutCarrierException e)
            {
                
            }
        }
        */

        /*
        [TestMethod]
        public void AddLotWithACarrier()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = this.Carrier
            };
            try
            {
                l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
                controller.POST(l);

            }
            catch (LotWithoutCarrierException e)
            {
                Assert.Fail();
            }
        }
        */
        /*
        [TestMethod]
        public void AddLotWithoutStatus()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = this.Carrier,
                Status = ""
            };
            l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
            controller.Post(l);
            Assert.AreNotEqual(l.Status, "");            
        }
        */

        /*
        [TestMethod]
        public void AddLotWithStatus()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = this.Carrier,
                Status = "Pronto para partir"
            };
            l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
            controller.POST(l);
            Assert.AreNotEqual(l.Status, "");
        }
        */

        /*
    [TestMethod]
    public void AddLotWithoutVehicles()
    {
        LotController controller = new LotController();
        Lot l = new Lot
        {
            Name = "TestLot",
            CreatedBy = this.Creator,
            Carrier = this.Carrier,
            Status = "Ingresado"
        };
        try
        {
            l.AddVehicle(null);
            controller.POST(l);
            Assert.Fail();
        }
        catch (LotWithoutVehiclesException e)
        {

        }
    }
    */
        /*
        [TestMethod]
        public void AddLotWithAVehicle()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = this.Carrier,
                Status = "Ingresado"
            };
            try
            {
                l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
                controller.POST(l);
            }
            catch (LotWithoutVehiclesException e)
            {
                Assert.Fail();
            }
        }
        */

        /*
    [TestMethod]
    public void AddLotWithAUserWithoutPermission()
    {
        LotController controller = new LotController();
        Lot l = new Lot
        {
            Name = "TestLot",
            CreatedBy = this.Carrier,
            Carrier = this.Carrier,
            Status = "Ingresado"
        };
        try
        {
            l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });                
            controller.POST(l);
            Assert.Fail();
        }
        catch (MissingPermissionException e)
        {

        }
    }
    */
        /*
        [TestMethod]
        public void AddLotWithAUserWithPermission()
        {
            LotController controller = new LotController();
            Lot l = new Lot
            {
                Name = "TestLot",
                CreatedBy = this.Creator,
                Carrier = this.Carrier,
                Status = "Ingresado"
            };
            try
            {
                l.AddVehicle(new Vehicle() { VIN = Guid.NewGuid().ToString() });
                controller.POST(l);
            }
            catch (MissingPermissionException e)
            {
                Assert.Fail();
            }
        }
        */

        [TestMethod]
        public void GetAllLotsOkTest()
        {
            //Arrange: Construimos el mock y seteamos las expectativas
            List<LotDTO> fakeLots = new List<LotDTO>();
            fakeLots.Add(GetFakeLot());
            fakeLots.Add(GetFakeLot2());
            var expectedLots = fakeLots;
            var mockLotsBusinessLogic = new Mock<ILotsDataTransfer>();
            mockLotsBusinessLogic
                .Setup(bl => bl.GetAllLots(currentSession.Id))
                .Returns(expectedLots);

            var controller = new LotsController(mockLotsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());
            
            //Act: Efectuamos la llamada al controller
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<LotDTO>>;
            mockLotsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedLots, contentResult.Content);
        }

        [TestMethod]
        public void GetNoLotsOkTest()
        {
            //Arrange: Construimos el mock y seteamos las expectativas
            List<LotDTO> fakeLots = new List<LotDTO>();
            var expectedLots = fakeLots;
            var mockLotsBusinessLogic = new Mock<ILotsDataTransfer>();
            mockLotsBusinessLogic
                .Setup(bl => bl.GetAllLots(currentSession.Id))
                .Returns(expectedLots);

            var controller = new LotsController(mockLotsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act: Efectuamos la llamada al controller
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<LotDTO>>;
            mockLotsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedLots, contentResult.Content);
        }
        /*
        [TestMethod]
        public void GetLotByIdOkTest()
        {
            //Arrange: Construimos el mock y seteamos las expectativas
            var expectedLots = GetFakeLot();
            var mockLotsBusinessLogic = new Mock<ILotsDataTransfer>();
            mockLotsBusinessLogic
                .Setup(bl => bl.GetById(new Guid("11111111-bbbb-cccc-dddd-eeeeeeeeeeee"), currentSession.Id))
                .Returns(expectedLots);

            var controller = new LotsController(mockLotsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());


            //Act: Efectuamos la llamada al controller
            IHttpActionResult obtainedResult = controller.Get(new Guid("11111111-bbbb-cccc-dddd-eeeeeeeeeeee"));

            //Assert
            var contentResult = obtainedResult as OkNegotiatedContentResult<Lot>;
            mockLotsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedLots, contentResult.Content);
        }
        */
        private LotDTO GetFakeLot()
        {
            var vehicle1 = new Vehicle()
            {
                Id = new Guid("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"),
                VIN = new Guid().ToString(),
                Brand = "Nissan",
                Model = "Note",
                Color = "Black",
                Year = 2017,
                Type = VehicleType.Car,
                State = VehicleState.Arrived
            };
            var vehicle2 = new Vehicle()
            {
                Id = new Guid(),
                VIN = new Guid().ToString(),
                Brand = "For",
                Model = "Focus",
                Color = "White",
                Year = 2016,
                Type = VehicleType.Car,
                State = VehicleState.Arrived
            };
            var vehicleIds = new List<Guid>();
            vehicleIds.Add(vehicle1.Id);
            vehicleIds.Add(vehicle2.Id);
            LotDTO l = new LotDTO()
            {
                Id = new Guid("11111111-bbbb-cccc-dddd-eeeeeeeeeeee"),
                Name = "TestLotOk_1",
                CarrierId = GetFakeCarrier().Id,
                CreatedById = GetFakeCreator().Id,
                Description = "Test Lot 1",
                //Status = LotState.Created,
                VehicleIds = vehicleIds
            };
            return l;
        }

        private LotDTO GetFakeLot2()
        {
            var vehicle1 = new Vehicle()
            {
                Id = new Guid(),
                VIN = new Guid().ToString(),
                Brand = "Nissan",
                Model = "Sentra",
                Color = "Grey",
                Year = 2017,
                Type = VehicleType.Car,
                State = VehicleState.Arrived
            };
            var vehicle2 = new Vehicle()
            {
                Id = new Guid(),
                VIN = new Guid().ToString(),
                Brand = "Chevrolet",
                Model = "Cruze",
                Color = "Grey",
                Year = 2015,
                Type = VehicleType.Car,
                State = VehicleState.Arrived
            };
            var vehicleIds = new List<Guid>();
            vehicleIds.Add(vehicle1.Id);
            vehicleIds.Add(vehicle2.Id);
            LotDTO l = new LotDTO()
            {
                Id = new Guid(),
                Name = "TestLot2_Ok",
                CarrierId = GetFakeCarrier().Id,
                CreatedById = GetFakeCreator().Id,
                Description = "Test Lot 2",
                //Status = LotState.Created,
                VehicleIds = vehicleIds,
            };
            return l;
        }

    }
}
