﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Http;
using System.Web.Http.Results;
using Moq;
using DAOB.BusinessLogic;
using System.Collections.Generic;
using DAOB.Data.Entities;
using System.Linq;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using DAOB.WebApi.DataTransfer;
using System.Net.Http;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class InspectionsControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };
        }

        [TestMethod]
        public void GetAllInspectionsOkTest()
        {
            //Arrange
            var expectedInspections = GetFakeInspections();

            var mockInspectionsBusinessLogic = new Mock<IInspectionsDataTransfer>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.GetAllInspections(currentSession.Id))
                .Returns(expectedInspections);

            var controller = new InspectionsController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<InspectionDTO>>;

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedInspections, contentResult.Content);
        }

        [TestMethod]
        public void GetAllInspectionsErrorNotFoundTest()
        {
            //Arrange
            List<InspectionDTO> expectedInspections = null;

            var mockInspectionsBusinessLogic = new Mock<IInspectionsDataTransfer>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.GetAllInspections(currentSession.Id))
                .Returns(expectedInspections);

            var controller = new InspectionsController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void GetInspectionByIdOkTest()
        {
            //Arrange
            var fakeInspection = GetAFakeInspection();
            fakeInspection.Id = new Guid("e502aaaa-6fce-4b9f-a492-746c6c8a1bfa");
            
            var mockInspectionsBusinessLogic = new Mock<IInspectionsDataTransfer>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.GetById(fakeInspection.Id, currentSession.Id))
                .Returns(fakeInspection);

            var controller = new InspectionsController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeInspection.Id);
            var contentResult = obtainedResult as OkNegotiatedContentResult<InspectionDTO>;

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(fakeInspection.Id, contentResult.Content.Id);
        }

        [TestMethod]
        public void GetInspectionByVehicleVINNotFoundErrorTest()
        {
            //Arrange
            var fakeInspection = GetAFakeInspection();
            
            fakeInspection.Id = new Guid("e502aaaa-6fce-4b9f-a492-746c6c8a1bfa");
            fakeInspection.Type = InspectionTypes.Lot;
            /*var vehicle = GetFakeVehicle2();
            vehicle.FirstInspection = fakeInspection;
            fakeInspection.VehicleId = vehicle.Id;
            */
            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockInspectionsBusinessLogic = new Mock<IInspectionsDataTransfer>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.GetById(fakeInspection.Id, currentSession.Id))
                .Returns((InspectionDTO)null);

            // Debemos retornar null, es lo que le exigimos al Mock para lograr
            // que el controller nos de NotFound

            var controller = new InspectionsController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeInspection.Id);

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void AddNullInspection()
        {
            //Arrange
            InspectionDTO fakeInspection = null;
            Vehicle vehicle = GetFakeVehicle2();

            var mockLotBL = new Mock<IInspectionsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeInspection, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new InspectionsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeInspection);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<InspectionDTO>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }
        
        [TestMethod]
        public void AddInspectionOkTest()
        {
            //Arrange
            var fakeInspection = new InspectionDTO
            {
                Id = new Guid("e502aaaa-6fce-4b9f-a492-746c6c8a1bfa"),
                DateTime = DateTime.Now,
                InspectorId = GetFakeInspector().Id,
                Place = "Garage 1",
                Type = InspectionTypes.Lot
            };
            Vehicle vehicle = GetFakeVehicle();
            var mockLotBL = new Mock<IInspectionsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeInspection, currentSession.Id));

            var controller = new InspectionsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeInspection);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<InspectionDTO>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeInspection.DateTime, createdResult.RouteValues["DateTime"]);
            Assert.AreEqual(fakeInspection, createdResult.Content);
        }

        [TestMethod]
        public void AddInspectionWithoutDamages()
        {
            //Arrange
            var fakeVehicle = GetFakeVehicle2();
            var fakeInspection = new InspectionDTO
            {
                Id = new Guid("e502aaaa-6fce-4b9f-a492-746c6c8a1bfa"),
                DateTime = DateTime.Now,
                InspectorId = GetFakeInspector().Id,
                Place = "Garage 1",
                Damages = null,
                Type = InspectionTypes.Lot
            };

            var mockLotBL = new Mock<IInspectionsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeInspection, currentSession.Id));

            var controller = new InspectionsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeInspection);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<InspectionDTO>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeInspection.DateTime, createdResult.RouteValues["DateTime"]);
            Assert.AreEqual(fakeInspection, createdResult.Content);
        }

        private Vehicle GetFakeVehicle()
        {
            var vehicle = new Vehicle()
            {
                Id = new Guid(),
                VIN = new Guid().ToString(),
                Brand = "Nissan",
                Model = "Sentra",
                Color = "Grey",
                Year = 2017
            };
            return vehicle;
        }

        [TestMethod]
        public void AddYardInspectionOkTest()
        {
            //Arrange
            var fakeInspection = new InspectionDTO
            {
                Id = new Guid("e502aaaa-6fce-4b9f-a492-746c6c8a1bfa"),
                DateTime = DateTime.Now,
                InspectorId = GetFakeInspector().Id,
                Place = "Garage 1",
                Type = InspectionTypes.Yard
            };
            Vehicle vehicle = GetFakeVehicle();
            var mockLotBL = new Mock<IInspectionsDataTransfer>();
            mockLotBL
                .Setup(bl => bl.Add(fakeInspection, currentSession.Id));

            var controller = new InspectionsController(mockLotBL.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeInspection);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<InspectionDTO>;

            //Assert
            mockLotBL.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeInspection.DateTime, createdResult.RouteValues["DateTime"]);
            Assert.AreEqual(fakeInspection, createdResult.Content);
        }

        private User GetFakeInspector()
        {
            User inspector = new User()
            {
                Id = new Guid("bbbbcccc-cccc-4b9f-a492-746c6c8a1bfa"),
                FirstName = "TestInspector",
                LastName = "testI",
                UserName = "testInspector",
                Password = "test",
                Role = new Role()
                {
                    Id = new Guid(),
                    Name = UserRole.YardOperator
                }
            };
            inspector.Role.Permissions = new List<Permission>() { new Permission() { Id = new Guid(), Name = RolePermission.AddInspection } };

            return inspector;
        }

        private ICollection<InspectionDTO> GetFakeInspections()
        {
            return new List<InspectionDTO>
            {
                new InspectionDTO
                {
                    Id = Guid.NewGuid(),
                    DateTime = DateTime.Now,
                    Place  = "Here",
                    InspectorId = new Guid()
                }
            };
        }

        private InspectionDTO GetAFakeInspection()
        {
            List<InspectionDTO> inspections = GetFakeInspections().ToList();
            return inspections.FirstOrDefault();
        }

        private Vehicle GetFakeVehicle2()
        {
            Vehicle v = new Vehicle
            {
                Id = Guid.NewGuid(),
                VIN = "SDFJ43SFD545892PAN34S",
                Brand = "Ford",
                Model = "Ka",
                Color = "Green",
                Year = 2009,
                Type = VehicleType.Car
            };
            return v;
        }

    }
}
