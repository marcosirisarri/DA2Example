﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Web.Http;
using System.Web.Http.Results;
using System.Collections.Generic;
using DAOB.Data.Entities;
using System.Linq;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using System.Net.Http;
using DAOB.WebApi.DataTransfer;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class VehiclesControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };
        }

        [TestMethod]
        public void GetAllVehiclesOkTest()
        {
            //Arrange
            var expectedVehicles = GetFakeVehicles();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            
            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.GetAllVehicles(currentSession.Id))
                .Returns(expectedVehicles);

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<VehicleDTO>>;

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedVehicles, contentResult.Content);
        }

        [TestMethod]
        public void GetAllVehiclesErrorNotFoundTest()
        {
            //Arrange
            List<VehicleDTO> expectedVehicles = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.GetAllVehicles(currentSession.Id))
                .Returns(expectedVehicles);

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void GetVehicleByVINOkTest()
        {
            //Arrange
            var fakeVehicle = GetAFakeVehicle();
            var fakeVIN = fakeVehicle.VIN;

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.GetByVIN(fakeVIN, currentSession.Id))
                .Returns(fakeVehicle);

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeVIN);
            var contentResult = obtainedResult as OkNegotiatedContentResult<VehicleDTO>;

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(fakeVIN, contentResult.Content.VIN);
        }

        [TestMethod]
        public void GetVehicleByVINNotFoundErrorTest()
        {
            //Arrange
            var fakeVIN = Guid.NewGuid().ToString();

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.GetByVIN(fakeVIN, currentSession.Id))
                .Returns((VehicleDTO) null);

            // Debemos retornar null, es lo que le exigimos al Mock para lograr
            // que el controller nos de NotFound

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeVIN);

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void CreateNewVehicleTestOk()
        {
            //Arrange
            var fakeVehicle = GetAFakeVehicle();

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Add(fakeVehicle, currentSession.Id));

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeVehicle);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<VehicleDTO>;
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeVehicle.VIN, createdResult.RouteValues["VIN"]);
            Assert.AreEqual(fakeVehicle, createdResult.Content);
        }

        [TestMethod]
        public void CreateNullVehicleErrorTest()
        {
            //Arrange
            VehicleDTO fakeVehicle = null;

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Add(fakeVehicle, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeVehicle);

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void CreateVINRepeatedVehicleErrorTest()
        {
            //Arrange
            VehicleDTO fakeVehicle = GetAFakeVehicle();
            VehicleDTO fakeVehicle2 = GetAFakeVehicle();

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Add(fakeVehicle, currentSession.Id));
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Add(fakeVehicle2, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult1 = controller.Post(fakeVehicle);
            IHttpActionResult obtainedResult2 = controller.Post(fakeVehicle2);
            var createdResult = obtainedResult1 as CreatedAtRouteNegotiatedContentResult<VehicleDTO>;

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeVehicle.VIN, createdResult.RouteValues["VIN"]);
            Assert.AreEqual(fakeVehicle, createdResult.Content);
            Assert.IsInstanceOfType(obtainedResult2, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void UpdateExistingVehicleOkTest()
        {
            //Arrange
            var fakeVehicle = GetAFakeVehicle();
            var expectedResult = true;

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<VehicleDTO>(), currentSession.Id))
                .Returns(true);

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeVehicle);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<VehicleDTO>;
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(expectedResult, createdResult.RouteValues["updated"]);
            Assert.AreEqual(fakeVehicle, createdResult.Content);
        }

        [TestMethod]
        public void UpdateVehicleWithNullIdErrorTest()
        {
            //Arrange
            VehicleDTO fakeVehicle = null;

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            //mockVehiclesBusinessLogic
            //    .Setup(bl => bl.Update(new Guid(), fakeVehicle, currentSession.Id))
            //    .Returns(false);
                //.Throws(new ArgumentNullException());

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeVehicle);

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void DeleteVehicleOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();

            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Delete(It.IsAny<Guid>(), currentSession.Id))
                .Returns(It.IsAny<bool>());

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(fakeGuid);

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult);
        }

        [TestMethod]
        public void DeleteVehicleWithNullIdErrorTest()
        {
            //Arrange
            
            var mockVehiclesBusinessLogic = new Mock<IVehiclesDataTransfer>();
            mockVehiclesBusinessLogic
                .Setup(bl => bl.Delete(new Guid(), currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new VehiclesController(mockVehiclesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(new Guid());

            //Assert
            mockVehiclesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        private ICollection<VehicleDTO> GetFakeVehicles()
        {
            return new List<VehicleDTO>
            {
                new VehicleDTO
                {
                    VIN = "A89CD8DS735F232Q3",
                    Brand  = "Mercedes Benz",
                    Model = "GLX-223",
                    Year = 2015,
                    Color = "Black",
                    Type = VehicleType.Truck
                },
                new VehicleDTO
                {
                    VIN = "HY98UJC337UOK3MF2",
                    Brand  = "Audi",
                    Model = "A8",
                    Year = 2016,
                    Color = "White",
                    Type = VehicleType.Car
                },
                new VehicleDTO
                {
                    VIN = "AHS76GAR4342HER43",
                    Brand  = "Peugeot",
                    Model = "Partner",
                    Year = 2011,
                    Color = "Grey",
                    Type = VehicleType.Van
                }
            };
        }

        private VehicleDTO GetAFakeVehicle()
        {
            List<VehicleDTO> vehicles = GetFakeVehicles().ToList();
            return vehicles.FirstOrDefault();
        }

        private string GetARandomFakeVIN()
        {
            return GetAFakeVehicle().VIN;
        }
    }
}
