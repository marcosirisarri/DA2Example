﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using DAOB.WebApi.Models;
using DAOB.Data.Entities;
using System.Web.Http;
using System.Web.Http.Results;
using DAOB.WebApi.DataTransfer;
using Moq;
using DAOB.WebApi.Controllers;

namespace WebApi.Tests.Controllers
{
    [TestClass]
    public class SalesControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };
        }

        [TestMethod]
        public void AddSaleTestOk()
        {
            //Arrange
            var fakeSale = GetAFakeSale();

            var mockVehiclesDataTransfer = new Mock<ISalesDataTransfer>();
            mockVehiclesDataTransfer
                .Setup(bl => bl.Add(fakeSale, currentSession.Id));

            var controller = new SalesController(mockVehiclesDataTransfer.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeSale);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<SaleDTO>;
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Assert
            mockVehiclesDataTransfer.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeSale.VehicleId, createdResult.RouteValues["vehicleId"]);
            Assert.AreEqual(fakeSale, createdResult.Content);
        }

        private SaleDTO GetAFakeSale()
        {
            return new SaleDTO
            {
                SalesmanId = new Guid(),
                BuyerId = new Guid(),
                Price = 200,
                VehicleId = new Guid()
            };
        }
    }
}
