﻿using DAOB.BusinessLogic;
using DAOB.Data.Entities;
using DAOB.WebApi.DataTransfer;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class ChangeHistoryControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };

        }

        [TestMethod]
        public void GetChangeToVehicleOk()
        {
            //Arrange
            Vehicle fakeVehicle = GetFakeVehicle();
            List<ChangeHistoryDTO> history = new List<ChangeHistoryDTO>();
            var mockInspectionsBusinessLogic = new Mock<IChangeHistoryDataTransfer>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.Get(fakeVehicle.Id))
                .Returns(history);

            var controller = new ChangeHistoryController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeVehicle.Id);
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<ChangeHistoryDTO>>;

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(history, contentResult.Content);
        }
        /*CORREGIR
        [TestMethod]
        public void GetChangeToVehicleOk2()
        {
            //Arrange
            Vehicle fakeVehicle = GetFakeVehicle();
            fakeVehicle.History.Add(new ChangeHistory()
            {
                Id = Guid.NewGuid(),
                Datetime = DateTime.Now.AddDays(-1),
                Description = "Yesterday"
            });
            List<ChangeHistoryDTO> history = fakeVehicle.History.ToList();

            var mockInspectionsBusinessLogic = new Mock<IChangeHistoryBusinessLogicCommunication>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.Get(fakeVehicle.Id))
                .Returns(history);

            var controller = new ChangeHistoryController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeVehicle.Id);
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<ChangeHistory>>;

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(history, contentResult.Content);
            Assert.AreEqual(1, fakeVehicle.History.Count);
        }


        [TestMethod]
        public void GetChangeToVehicleOk3()
        {
            //Arrange
            Vehicle fakeVehicle = GetFakeVehicle();
            fakeVehicle.History.Add(new ChangeHistory()
            {
                Id = Guid.NewGuid(),
                Datetime = DateTime.Now.AddDays(-1),
                Description = "Yesterday",
                //Vehicle = fakeVehicle,
                //CAMBIARVehicleId = fakeVehicle.Id
            });
            fakeVehicle.History.Add(new ChangeHistory()
            {
                Id = Guid.NewGuid(),
                Datetime = DateTime.Now,
                Description = "Lets go testing",
                //CAMBIARVehicle = fakeVehicle,
                //VehicleId = fakeVehicle.Id
            });
            List<ChangeHistory> history = fakeVehicle.History.ToList();
            

            var mockInspectionsBusinessLogic = new Mock<IChangeHistoryBusinessLogicCommunication>();
            mockInspectionsBusinessLogic
                .Setup(bl => bl.Get(fakeVehicle.Id))
                .Returns(history);

            var controller = new ChangeHistoryController(mockInspectionsBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeVehicle.Id);
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<ChangeHistory>>;

            //Assert
            mockInspectionsBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(history, contentResult.Content);
            Assert.AreEqual(2, fakeVehicle.History.Count);
        }
        */


        private Vehicle GetFakeVehicle()
        {
            return new Vehicle()
            {
                Id = Guid.NewGuid(),
                VIN = "A89CD8DS735F232Q3",
                Brand = "Mercedes Benz",
                Model = "GLX-223",
                Year = 2015,
                Color = "Black",
                Type = VehicleType.Truck,
                State = VehicleState.ReadyToDepart
            };
        }

        private List<ChangeHistoryDTO> GetFakeChangeHistories()
        {
            return new List<ChangeHistoryDTO>
            {
                new ChangeHistoryDTO
                {
                    Id = new Guid(),
                    Description = "One change",
                    Datetime = DateTime.Now
                },
                new ChangeHistoryDTO
                {
                    Id = new Guid(),
                    Description = "Another change",
                    Datetime = DateTime.Now
                }
            };
        }
    }
}
