﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Http;
using System.Web.Http.Results;
using System.Collections.Generic;
using Moq;
using DAOB.BusinessLogic;
using System.Linq;
using DAOB.Data.Entities;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using DAOB.WebApi.DataTransfer;
using System.Net.Http;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class ZonesControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };
        }

        [TestMethod]
        public void GetAllZonesOkTest()
        {
            //Arrange
            var expectedZones = GetFakeZones();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.GetAllZones(currentSession.Id))
                .Returns(expectedZones);

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<ZoneDTO>>;

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedZones, contentResult.Content);
        }

        [TestMethod]
        public void GetAllZonesErrorNotFoundTest()
        {
            //Arrange
            List<ZoneDTO> expectedZones = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.GetAllZones(currentSession.Id))
                .Returns(expectedZones);

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void GetZoneByNameOkTest()
        {
            //Arrange
            var fakeZone = GetAFakeZone();
            var fakeName = fakeZone.Name;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.GetByName(fakeName, currentSession.Id))
                .Returns(fakeZone);

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeName);
            var contentResult = obtainedResult as OkNegotiatedContentResult<ZoneDTO>;

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(fakeName, contentResult.Content.Name);
        }

        [TestMethod]
        public void GetZoneByNameNotFoundErrorTest()
        {
            //Arrange
            var fakeName = Guid.NewGuid().ToString();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.GetByName(fakeName, currentSession.Id))
                .Returns((ZoneDTO)null);

            // Debemos retornar null, es lo que le exigimos al Mock para lograr
            // que el controller nos de NotFound

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeName);

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }

        [TestMethod]
        public void CreateNewZoneTestOk()
        {
            //Arrange
            var fakeZone = GetAFakeZone();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Add(fakeZone, currentSession.Id));

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeZone);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<ZoneDTO>;

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeZone.Name, createdResult.RouteValues["name"]);
            Assert.AreEqual(fakeZone, createdResult.Content);
        }

        [TestMethod]
        public void CreateNullZoneErrorTest()
        {
            //Arrange
            ZoneDTO fakeZone = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Add(fakeZone, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeZone);

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void CreateNameRepeatedZoneErrorTest()
        {
            //Arrange
            ZoneDTO fakeZone = GetAFakeZone();
            ZoneDTO fakeZone2 = GetAFakeZone();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Add(fakeZone, currentSession.Id));
            mockZonesBusinessLogic
                .Setup(bl => bl.Add(fakeZone2, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult1 = controller.Post(fakeZone);
            IHttpActionResult obtainedResult2 = controller.Post(fakeZone2);
            var createdResult = obtainedResult1 as CreatedAtRouteNegotiatedContentResult<ZoneDTO>;

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeZone.Name, createdResult.RouteValues["name"]);
            Assert.AreEqual(fakeZone, createdResult.Content);
            Assert.IsInstanceOfType(obtainedResult2, typeof(BadRequestErrorMessageResult));
        }
        
        [TestMethod]
        public void UpdateExistingZoneOkTest()
        {
            //Arrange
            var fakeZone = GetAFakeZone();
            var expectedResult = true;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<ZoneDTO>(), currentSession.Id))
                .Returns(true);

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(new Guid(), fakeZone);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<ZoneDTO>;

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(expectedResult, createdResult.RouteValues["updated"]);
            Assert.AreEqual(fakeZone, createdResult.Content);
        }

        [TestMethod]
        public void UpdateZoneWithNullIdErrorTest()
        {
            //Arrange
            ZoneDTO fakeZone = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Update(new Guid(), It.IsAny<ZoneDTO>(), currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(new Guid(), fakeZone);

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void DeleteZoneOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Delete(It.IsAny<Guid>(), currentSession.Id))
                .Returns(It.IsAny<bool>());

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(fakeGuid);

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult);
        }

        [TestMethod]
        public void DeleteZonesWithNullIdErrorTest()
        {
            //Arrange
            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockZonesBusinessLogic = new Mock<IZonesDataTransfer>();
            mockZonesBusinessLogic
                .Setup(bl => bl.Delete(new Guid(), currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new ZonesController(mockZonesBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(new Guid());

            //Assert
            mockZonesBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        private ICollection<ZoneDTO> GetFakeZones()
        {
            return new List<ZoneDTO>
            {
                new ZoneDTO
                {
                    Id = Guid.NewGuid(),
                    Name = "Z1",
                    MaxCapacity = 20,
                    SubzoneIds = new List<Guid>()
                },
                new ZoneDTO
                {
                    Id = Guid.NewGuid(),
                    Name = "Z2",
                    MaxCapacity = 30, 
                    SubzoneIds = new List<Guid>()
                },
                new ZoneDTO
                {
                    Id = Guid.NewGuid(),
                    Name = "Z3",
                    MaxCapacity = 25, 
                    SubzoneIds = new List<Guid>()
                }
            };
        }

        private ZoneDTO GetAFakeZone()
        {
            List<ZoneDTO> zones = GetFakeZones().ToList();
            return zones.FirstOrDefault();
        }
    }
}
