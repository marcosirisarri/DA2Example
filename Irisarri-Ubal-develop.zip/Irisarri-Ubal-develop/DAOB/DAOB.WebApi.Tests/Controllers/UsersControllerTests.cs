﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Web.Http;
using System.Web.Http.Results;
using System.Collections.Generic;
using DAOB.Data.Entities;
using DAOB.BusinessLogic;
using System.Linq;
using DAOB.WebApi.Controllers;
using DAOB.WebApi.Models;
using System.Net.Http;
using DAOB.WebApi.DataTransfer;

namespace DAOB.WebApi.Tests.Controllers
{
    [TestClass]
    public class UsersControllerTests
    {
        UserDTO loggedUser;
        SessionDTO currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new UserDTO()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                RoleId = role.Id
            };
            currentSession = new SessionDTO()
            {
                Id = new Guid(),
                UserId = loggedUser.Id
            };
        }

        [TestMethod]
        public void GetAllUsersOkTest()
        {
            //Arrange
            var expectedUsers = GetFakeUsers();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.GetAllUsers(currentSession.Id))
                .Returns(expectedUsers);

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();
            var contentResult = obtainedResult as OkNegotiatedContentResult<ICollection<UserDTO>>;

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(expectedUsers, contentResult.Content);
        }

        [TestMethod]
        public void GetAllUsersErrorNotFoundTest()
        {
            //Arrange
            List<UserDTO> expectedUsers = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.GetAllUsers(currentSession.Id))
                .Returns(expectedUsers);

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get();

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }
        
        [TestMethod]
        public void GetUserByUserNameOkTest()
        {
            //Arrange
            var fakeUser = GetFakeUsers().FirstOrDefault();
            var fakeUserName = fakeUser.UserName;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.GetByUserName(fakeUserName, currentSession.Id))
                .Returns(fakeUser);

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeUserName);
            var contentResult = obtainedResult as OkNegotiatedContentResult<UserDTO>;

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(fakeUserName, contentResult.Content.UserName);
        }

        [TestMethod]
        public void GetUserByUserNameNotFoundErrorTest()
        {
            //Arrange
            var fakeUserName = Guid.NewGuid().ToString();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.GetByUserName(fakeUserName, currentSession.Id))
                .Returns((UserDTO) null);

            // Debemos retornar null, es lo que le exigimos al Mock para lograr
            // que el controller nos de NotFound

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Get(fakeUserName);

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(NotFoundResult));
        }
        
        [TestMethod]
        public void CreateNewUserTestOk()
        {
            //Arrange
            var fakeUser = GetAFakeUser();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Add(fakeUser, currentSession.Id));

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeUser);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<UserDTO>;

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeUser.UserName, createdResult.Content.UserName);
        }

        [TestMethod]
        public void CreateNullUserErrorTest()
        {
            //Arrange
            UserDTO fakeUser = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Add(fakeUser, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Post(fakeUser);

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void CreateUserNameRepeatedUserErrorTest()
        {
            //Arrange
            var fakeUser = GetAFakeUser();
            var fakeUser2 = GetAFakeUser();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Add(fakeUser, currentSession.Id));
            mockUsersBusinessLogic
                .Setup(bl => bl.Add(fakeUser2, currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult1 = controller.Post(fakeUser);
            IHttpActionResult obtainedResult2 = controller.Post(fakeUser2);
            var createdResult = obtainedResult1 as CreatedAtRouteNegotiatedContentResult<UserDTO>;

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult1);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(fakeUser.UserName, createdResult.Content.UserName);
            Assert.IsInstanceOfType(obtainedResult2, typeof(BadRequestErrorMessageResult));
        }

        [TestMethod]
        public void UpdateExistingUserOkTest()
        {
            //Arrange
            var fakeUser = GetAFakeUser();
            var expectedResult = true;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<UserDTO>(), currentSession.Id))
                .Returns(true);

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeUser);
            var createdResult = obtainedResult as CreatedAtRouteNegotiatedContentResult<UserDTO>;

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(createdResult);
            Assert.AreEqual("DefaultApi", createdResult.RouteName);
            Assert.AreEqual(expectedResult, createdResult.RouteValues["updated"]);
            Assert.AreEqual(fakeUser, createdResult.Content);
        }

        [TestMethod]
        public void UpdateUserWithNullIdErrorTest()
        {
            //Arrange
            UserDTO fakeUser = null;

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Update(new Guid(), It.IsAny<UserDTO>(), currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Put(fakeUser);

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }
        
        [TestMethod]
        public void DeleteUserOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();

            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Delete(It.IsAny<Guid>(), currentSession.Id))
                .Returns(It.IsAny<bool>());

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(fakeGuid);

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsNotNull(obtainedResult);
        }

        [TestMethod]
        public void DeleteUserWithNullIdErrorTest()
        {
            //Arrange
            var mockSessionBusinessLogic = new Mock<ISessionsDataTransfer>();
            mockSessionBusinessLogic
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);

            var mockUsersBusinessLogic = new Mock<IUsersDataTransfer>();
            mockUsersBusinessLogic
                .Setup(bl => bl.Delete(new Guid(), currentSession.Id))
                .Throws(new ArgumentNullException());

            var controller = new UsersController(mockUsersBusinessLogic.Object);
            controller.Request = new HttpRequestMessage();
            controller.Request.Headers.Add("sessiontoken", currentSession.Id.ToString());

            //Act
            IHttpActionResult obtainedResult = controller.Delete(new Guid());

            //Assert
            mockUsersBusinessLogic.VerifyAll();
            Assert.IsInstanceOfType(obtainedResult, typeof(BadRequestErrorMessageResult));
        }

        private ICollection<UserDTO> GetFakeUsers()
        {
            return new List<UserDTO>
            {
                new UserDTO
                {
                    Id = Guid.NewGuid(),
                    UserName = "johng",
                    Password  = "abc123",
                    FirstName = "John",
                    LastName = "Gallor",
                    PhoneNumber = "123 54 643 22"
                },
                new UserDTO
                {
                    Id = Guid.NewGuid(),
                    UserName = "wallym",
                    Password  = "fred321",
                    FirstName = "Wally",
                    LastName = "Menner",
                    PhoneNumber = "3442 4342"
                }
            };
        }

        private UserDTO GetAFakeUser()
        {
            List<UserDTO> users = GetFakeUsers().ToList();
            return users.FirstOrDefault();
        }
    }
}
