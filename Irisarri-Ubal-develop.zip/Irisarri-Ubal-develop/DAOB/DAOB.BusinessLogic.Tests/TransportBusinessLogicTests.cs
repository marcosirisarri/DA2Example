﻿using DAOB.BusinessLogic.Exceptions;
using DAOB.Data.Entities;
using DAOB.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace DAOB.BusinessLogic.Tests
{
    [TestClass]
    public class TransportBusinessLogicTests
    {
        User loggedUser;
        Session currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new User()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                Role = role
            };
            currentSession = new Session()
            {
                Id = new Guid(),
                User = loggedUser
            };
        }
        

        [TestMethod]
        [ExpectedException(typeof(TransportWithoutCarrierException))]
        public void StartTransportWithoutCarrierErrorTest()
        {
            //Arrange
            Transport fakeTransport = GetFakeTransport();
            fakeTransport.Carrier = null;
            Vehicle fakeVehicle = new Vehicle();
            Lot fakeLot = new Lot();


            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.StartTransport))
                .Returns(true);

            var mockTransportRepository = new Mock<ITransportsRepository>();
            mockTransportRepository
                .Setup(bl => bl.Add(fakeTransport))
                .Throws(new TransportWithoutCarrierException());

            var mockLotRepository = new Mock<ILotsRepository>();
            mockLotRepository
                .Setup(bl => bl.Update(fakeLot.Id, fakeLot))
                .Returns(true);

            var mockVehicleRepository = new Mock<IVehiclesRepository>();
            mockVehicleRepository
                .Setup(bl => bl.Update(fakeVehicle.Id, fakeVehicle))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();

            var businessLogic = new TransportsBusinessLogic(mockTransportRepository.Object, mockLotRepository.Object, mockVehicleRepository.Object, mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeTransport, currentSession.Id);

            //Assert
            mockTransportRepository.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(TransportWithoutCarrierException))]
        public void StartTransportWithoutCarrierErrorTest2()
        {
            //Arrange
            Transport fakeTransport = GetFakeTransport();
            fakeTransport.Carrier = null;
            Vehicle fakeVehicle = new Vehicle();
            Lot fakeLot = new Lot();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.StartTransport))
                .Returns(true);

            var mockTransportRepository = new Mock<ITransportsRepository>();
            mockTransportRepository
                .Setup(bl => bl.Add(fakeTransport))
                .Throws(new TransportWithoutCarrierException());

            var mockLotRepository = new Mock<ILotsRepository>();
            mockLotRepository
                .Setup(bl => bl.Update(fakeLot.Id, fakeLot))
                .Returns(true);

            var mockVehicleRepository = new Mock<IVehiclesRepository>();
            mockVehicleRepository
                .Setup(bl => bl.Update(fakeVehicle.Id, fakeVehicle))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();

            var businessLogic = new TransportsBusinessLogic(mockTransportRepository.Object, mockLotRepository.Object, mockVehicleRepository.Object, mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeTransport, currentSession.Id);

            //Assert
            mockTransportRepository.VerifyAll();
        }

        private Transport GetFakeTransport()
        {
            Transport transport = new Transport()
            {
                Id = Guid.NewGuid(),
                Carrier = new User()
                {
                    FirstName = "Test",
                    LastName = "Carrier",
                    Password = "no",
                    UserName = "testcarrier",
                    Role = new Role()
                    {
                        Id = Guid.NewGuid(),
                        Name = UserRole.Carrier,
                        Permissions = new List<Permission>()
                        {
                            new Permission()
                            {
                                Id = Guid.NewGuid(),
                                Name = RolePermission.StartTransport
                            }
                        }
                    }
                },
                StartDate = DateTime.Now,
                Lots = GetFakeLots()
            };
            return transport;
        }
        
        private ICollection<Lot> GetFakeLots()
        {
            return new List<Lot>()
            {
                new Lot()
                {
                    Description = "description1",
                    Name="fakeLot1",
                    Vehicles = GetFakeVehicles()
                }
            };
        }

        private ICollection<Vehicle> GetFakeVehicles()
        {
            return new List<Vehicle>
            {
                new Vehicle
                {
                    VIN = "A89CD8DS735F232Q3",
                    Brand  = "Mercedes Benz",
                    Model = "GLX-223",
                    Year = 2015,
                    Color = "Black",
                    Type = VehicleType.Truck
                },
                new Vehicle
                {
                    VIN = "HY98UJC337UOK3MF2",
                    Brand  = "Audi",
                    Model = "A8",
                    Year = 2016,
                    Color = "White",
                    Type = VehicleType.Car
                },
                new Vehicle
                {
                    VIN = "AHS76GAR4342HER43",
                    Brand  = "Peugeot",
                    Model = "Partner",
                    Year = 2011,
                    Color = "Grey",
                    Type = VehicleType.Van
                }
            };
        }
    }
}