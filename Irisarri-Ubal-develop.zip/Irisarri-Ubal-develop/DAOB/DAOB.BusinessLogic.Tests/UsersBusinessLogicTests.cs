﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using DAOB.Repository;
using DAOB.Data.Entities;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.BusinessLogic.Tests
{
    [TestClass]
    public class UsersBusinessLogicTests
    {
        User loggedUser;
        Session currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new User()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                Role = role
            };
            currentSession = new Session()
            {
                Id = new Guid(),
                User = loggedUser
            };
        }

        [TestMethod]
        public void GetAllUsersOkTest()
        {
            //Arrange
            var expectedUsers = GetFakeUsers();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedUsers);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            ICollection<User> obtainedResult = businessLogic.GetAllUsers(currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedUsers, obtainedResult);
        }

        [TestMethod]
        public void GetAllUsersErrorNotFoundTest()
        {
            //Arrange
            List<User> expectedUsers = null;
            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedUsers);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            ICollection<User> obtainedResult = businessLogic.GetAllUsers(currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.AreEqual(expectedUsers, obtainedResult);
        }

        [TestMethod]
        public void GetUserByUserNameOkTest()
        {
            //Arrange
            var fakeUser = GetAFakeUser();
            var fakeUserName = fakeUser.UserName;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.GetByUserName(fakeUserName))
                .Returns(fakeUser);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            User obtainedResult = businessLogic.GetByUserName(fakeUserName, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(fakeUserName, obtainedResult.UserName);
        }

        [TestMethod]
        public void GetUserByUserNameNotFoundErrorTest()
        {
            //Arrange
            var fakeUserName = Guid.NewGuid().ToString();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.GetByUserName(fakeUserName))
                .Returns((User)null);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            User obtainedResult = businessLogic.GetByUserName(fakeUserName, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void CreateNewUserTestOk()
        {
            //Arrange
            var fakeUser = GetAFakeUser();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            //mockUsersRepository
            //    .Setup(bl => bl.Add(fakeUser));

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeUser, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullUserErrorTest()
        {
            //Arrange
            User fakeUser = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.Add(fakeUser))
                .Throws(new ArgumentNullException());

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeUser, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
        }
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateUserNameRepeatedUserErrorTest()
        {
            //Arrange
            User fakeUser = GetAFakeUser();
            User fakeUser2 = GetAFakeUser();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.Add(fakeUser));
            mockUsersRepository
                .Setup(bl => bl.Add(fakeUser2))
                .Throws(new ArgumentException());

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeUser, currentSession.Id);
            businessLogic.Add(fakeUser2, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
        }
        
        [TestMethod]
        public void UpdateExistingUserOkTest()
        {
            //Arrange
            var fakeUser = GetAFakeUser();
            var expectedResult = true;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<User>()))
                .Returns(true);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeUser, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void UpdateUserWithNullIdErrorTest()
        {
            //Arrange
            User fakeUser = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateUser))
                .Returns(true);
            
            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.Update(new Guid(), It.IsAny<User>()))
                .Throws(new ArgumentNullException());

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeUser, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
        }
        
        [TestMethod]
        public void DeleteUserOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();
            var expectedResult = true;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.DeleteById(It.IsAny<Guid>()))
                .Returns(true);

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(fakeGuid, currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DeleteUserWithNullIdErrorTest()
        {
            //Arrange
            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteUser))
                .Returns(true);

            var mockUsersRepository = new Mock<IUsersRepository>();
            mockUsersRepository
                .Setup(bl => bl.DeleteById(new Guid()))
                .Throws(new ArgumentNullException());

            var businessLogic = new UsersBusinessLogic(mockUsersRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(new Guid(), currentSession.Id);

            //Assert
            mockUsersRepository.VerifyAll();
        }
        
        private ICollection<User> GetFakeUsers()
        {
            return new List<User>
            {
                new User
                {
                    UserName = "johng",
                    Password  = "abc123",
                    FirstName = "John",
                    LastName = "Gallor",
                    PhoneNumber = "123 54 643 22",
                    Role = new Role
                    {
                        Name = UserRole.Administrator,
                        Permissions = new List<Permission>
                        {
                            new Permission
                            {
                                Id = Guid.NewGuid(),
                                Name = RolePermission.AddVehicle
                            },
                            new Permission
                            {
                                Id = Guid.NewGuid(),
                                Name = RolePermission.AddUser
                            }
                        }
                    }
                },
                new User
                {
                    UserName = "wallym",
                    Password  = "fred321",
                    FirstName = "Wally",
                    LastName = "Menner",
                    PhoneNumber = "3442 4342",
                    Role = new Role
                    {
                        Name = UserRole.Carrier,
                        Permissions = new List<Permission>
                        {
                            new Permission
                            {
                                Id = Guid.NewGuid(),
                                Name = RolePermission.AddLotTransportation
                            }
                        }
                    }
                },
            };
        }

        private User GetAFakeUser()
        {
            ICollection<User> users = GetFakeUsers();
            return users.FirstOrDefault();
        }
    }
}
