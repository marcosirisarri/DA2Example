﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DAOB.Repository;
using Moq;
using DAOB.Data.Entities;

namespace DAOB.BusinessLogic.Tests
{
    [TestClass]
    public class SalesBusinessLogicTests
    {
        User loggedUser;
        Session currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new User()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                Role = role
            };
            currentSession = new Session()
            {
                Id = new Guid(),
                User = loggedUser
            };
        }

        [TestMethod]
        public void AddSaleTestOk()
        {
            //Arrange
            var fakeSale = GetAFakeSale();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddSale))
                .Returns(true);

            var mockSalesRepository = new Mock<ISalesRepository>();
            var mockVehiclesRepository = new Mock<IVehiclesRepository>();

            var businessLogic = new SalesBusinessLogic(mockSalesRepository.Object, mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeSale, currentSession.Id);

            //Assert
            mockSalesRepository.VerifyAll();
        }

        private Sale GetAFakeSale()
        {
            return new Sale
            {
                Vehicle = new Vehicle(),
                Salesman = new User(),
                Buyer = new Buyer(),
                Price = 200
            };
        }
    }
}
