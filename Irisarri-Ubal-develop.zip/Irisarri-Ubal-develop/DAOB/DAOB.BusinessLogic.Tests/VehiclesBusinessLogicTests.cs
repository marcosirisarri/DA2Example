﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DAOB.Data.Entities;
using System.Collections.Generic;
using DAOB.Repository;
using Moq;
using System.Linq;

namespace DAOB.BusinessLogic.Tests
{
    [TestClass]
    public class VehiclesBusinessLogicTests
    {
        User loggedUser;
        Session currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new User()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                Role = role
            };
            currentSession = new Session()
            {
                Id = new Guid(),
                User = loggedUser
            };
        }

        [TestMethod]
        public void GetAllVehiclesOkTest()
        {
            //Arrange
            var expectedVehicles = GetFakeVehicles();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedVehicles);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetAllVehicles(currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedVehicles, obtainedResult);
        }

        [TestMethod]
        public void GetAllVehiclesErrorNotFoundTest()
        {
            //Arrange
            List<Vehicle> expectedVehicles = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveUser))
                .Returns(true);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);
            
            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedVehicles);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetAllVehicles(currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.AreEqual(expectedVehicles, obtainedResult);
        }

        [TestMethod]
        public void GetVehicleByVINOkTest()
        {
            //Arrange
            var fakeVehicle = GetAFakeVehicle();
            var fakeVIN = fakeVehicle.VIN;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.GetByVIN(fakeVIN))
                .Returns(fakeVehicle);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetByVIN(fakeVIN, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(fakeVIN, obtainedResult.VIN);
        }

        [TestMethod]
        public void GetVehicleByVINNotFoundErrorTest()
        {
            //Arrange
            var fakeVIN = Guid.NewGuid().ToString();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.GetByVIN(fakeVIN))
                .Returns((Vehicle)null);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetByVIN(fakeVIN, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void AddNewVehicleTestOk()
        {
            //Arrange
            var fakeVehicle = GetAFakeVehicle();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeVehicle, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
        }
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullVehicleErrorTest()
        {
            //Arrange
            Vehicle fakeVehicle = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.Add(fakeVehicle))
                .Throws(new ArgumentNullException());

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeVehicle, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateVINRepeatedVehicleErrorTest()
        {
            //Arrange
            Vehicle fakeVehicle = GetAFakeVehicle();
            Vehicle fakeVehicle2 = GetAFakeVehicle();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.Add(fakeVehicle));
            mockVehiclesRepository
                .Setup(bl => bl.Add(fakeVehicle2))
                .Throws(new ArgumentException());

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeVehicle, currentSession.Id);
            businessLogic.Add(fakeVehicle2, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
        }

        [TestMethod]
        public void UpdateExistingVehicleOkTest()
        {
            //Arrange
            var fakeVehicleDTO = GetAFakeVehicle();
            var expectedResult = true;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateVehicle))
                .Returns(true);


            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<Vehicle>()))
                .Returns(true);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeVehicleDTO, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void UpdateVehicleWithNullIdErrorTest()
        {
            //Arrange
            Vehicle fakeVehicle = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveVehicle))
                .Returns(true);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateVehicle))
                .Returns(true);
            
            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.Update(new Guid(), It.IsAny<Vehicle>()))
                .Throws(new ArgumentNullException());

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeVehicle, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
        }

        [TestMethod]
        public void DeleteVehicleOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();
            var expectedResult = true;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.DeleteById(It.IsAny<Guid>()))
                .Returns(true);

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(fakeGuid, currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DeleteVehicleWithNullIdErrorTest()
        {
            //Arrange

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteVehicle))
                .Returns(true);

            var mockVehiclesRepository = new Mock<IVehiclesRepository>();
            mockVehiclesRepository
                .Setup(bl => bl.DeleteById(new Guid()))
                .Throws(new ArgumentNullException());

            var businessLogic = new VehiclesBusinessLogic(mockVehiclesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(new Guid(), currentSession.Id);

            //Assert
            mockVehiclesRepository.VerifyAll();
        }

        private ICollection<Vehicle> GetFakeVehicles()
        {
            return new List<Vehicle>
            {
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "A89CD8DS735F232Q3",
                    Brand  = "Mercedes Benz",
                    Model = "GLX-223",
                    Year = 2015,
                    Color = "Black",
                    Type = VehicleType.Truck,
                    State = VehicleState.Arrived
                },
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "HY98UJC337UOK3MF2",
                    Brand  = "Audi",
                    Model = "A8",
                    Year = 2016,
                    Color = "White",
                    Type = VehicleType.Car,
                    State = VehicleState.Arrived
                },
                new Vehicle
                {
                    Id = Guid.NewGuid(),
                    VIN = "AHS76GAR4342HER43",
                    Brand  = "Peugeot",
                    Model = "Partner",
                    Year = 2011,
                    Color = "Grey",
                    Type = VehicleType.Van,
                    State = VehicleState.Arrived
                }
            };
        }

        private Vehicle GetAFakeVehicle()
        {
            List<Vehicle> vehicles = GetFakeVehicles().ToList();
            return vehicles.FirstOrDefault();
        }
        
        private string GetARandomFakeVIN()
        {
            return GetAFakeVehicle().VIN;
        }
    }
}
