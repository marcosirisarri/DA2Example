﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using DAOB.Repository;
using DAOB.Data.Entities;
using System.Collections.Generic;
using System.Linq;

namespace DAOB.BusinessLogic.Tests
{
    [TestClass]
    public class ZonesBusinessLogicTests
    {
        User loggedUser;
        Session currentSession;

        [TestInitialize]
        public void LogUser()
        {
            Role role = new Role()
            {
                Id = new Guid(),
                Name = UserRole.Administrator
            };

            loggedUser = new User()
            {
                Id = new Guid(),
                FirstName = "John",
                LastName = "Robertson",
                UserName = "johnr",
                Password = "pass",
                PhoneNumber = "123",
                Role = role
            };
            currentSession = new Session()
            {
                Id = new Guid(),
                User = loggedUser
            };
        }



        [TestMethod]
        public void GetAllZonesOkTest()
        {
            //Arrange
            var expectedZones = GetFakeZones();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedZones);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetAllZones(currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedZones, obtainedResult);
        }

        [TestMethod]
        public void GetAllZonesErrorNotFoundTest()
        {
            //Arrange
            List<Zone> expectedZones = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.GetAll())
                .Returns(expectedZones);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetAllZones(currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.AreEqual(obtainedResult, expectedZones);
        }

        [TestMethod]
        public void GetZoneByNameOkTest()
        {
            //Arrange
            var fakeZone = GetAFakeZone();
            var fakeName = fakeZone.Name;


            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.GetByName(fakeName))
                .Returns(fakeZone);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetByName(fakeName, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(fakeName, obtainedResult.Name);
        }

        [TestMethod]
        public void GetZoneByIdOkTest()
        {
            //Arrange
            var fakeZone = GetAFakeZone();
            var fakeId = fakeZone.Id;


            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.GetById(fakeId))
                .Returns(fakeZone);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetById(fakeId, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(fakeId, obtainedResult.Id);
        }

        [TestMethod]
        public void GetZoneByNameNotFoundErrorTest()
        {
            //Arrange
            var fakeName = Guid.NewGuid().ToString();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.RetrieveZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.GetByName(fakeName))
                .Returns((Zone)null);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.GetByName(fakeName, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNull(obtainedResult);
        }

        [TestMethod]
        public void CreateNewZoneTestOk()
        {
            //Arrange
            var fakeZone = GetAFakeZone();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.Add(fakeZone));

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeZone, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNullZoneErrorTest()
        {
            //Arrange
            Zone fakeZone = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.Add(fakeZone))
                .Throws(new ArgumentNullException());

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeZone, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateNameRepeatedZoneErrorTest()
        {
            //Arrange
            Zone fakeZone = GetAFakeZone();
            Zone fakeZone2 = GetAFakeZone();

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.AddZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.Add(fakeZone));
            mockZonesRepository
                .Setup(bl => bl.Add(fakeZone2))
                .Throws(new ArgumentException());

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            businessLogic.Add(fakeZone, currentSession.Id);
            businessLogic.Add(fakeZone2, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
        }

        [TestMethod]
        public void UpdateExistingZoneOkTest()
        {
            //Arrange
            var fakeZone = GetAFakeZone();
            var expectedResult = true;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.Update(It.IsAny<Guid>(), It.IsAny<Zone>()))
                .Returns(true);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeZone, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void UpdateZoneWithNullIdErrorTest()
        {
            //Arrange
            Zone fakeZone = null;

            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.UpdateZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.Update(new Guid(), It.IsAny<Zone>()))
                .Throws(new ArgumentNullException());

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Update(new Guid(), fakeZone, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
        }

        [TestMethod]
        public void DeleteZoneOkTest()
        {
            //Arrange
            Guid fakeGuid = Guid.NewGuid();
            var expectedResult = true;
            Zone fakeZone = new Zone()
            {
                Name = "FakeZone",
                MaxCapacity = 100,
                Subzones = new List<Subzone>()
            };
            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.DeleteById(It.IsAny<Guid>()))
                .Returns(true);
            mockZonesRepository
                .Setup(bl => bl.GetById(It.IsAny<Guid>()))
                .Returns(fakeZone);

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(fakeGuid, currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
            Assert.IsNotNull(obtainedResult);
            Assert.AreEqual(expectedResult, obtainedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DeleteZonesWithNullIdErrorTest()
        {
            //Arrange
            var mockSessionRepository = new Mock<ISessionsRepository>();
            mockSessionRepository
                .Setup(bl => bl.Add(loggedUser))
                .Returns(currentSession);
            mockSessionRepository
                .Setup(r => r.CheckPermission(currentSession.Id, RolePermission.DeleteZone))
                .Returns(true);

            var mockZonesRepository = new Mock<IZonesRepository>();
            mockZonesRepository
                .Setup(bl => bl.DeleteById(new Guid()))
                .Throws(new ArgumentNullException());

            var businessLogic = new ZonesBusinessLogic(mockZonesRepository.Object, mockSessionRepository.Object);

            //Act
            var obtainedResult = businessLogic.Delete(new Guid(), currentSession.Id);

            //Assert
            mockZonesRepository.VerifyAll();
        }

        private ICollection<Zone> GetFakeZones()
        {
            return new List<Zone>
            {
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z1",
                    Subzones = new List<Subzone>()
                },
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z2",
                    Subzones = new List<Subzone>()
                },
                new Zone
                {
                    Id = Guid.NewGuid(),
                    Name = "Z3",
                    Subzones = new List<Subzone>()
                }
            };
        }

        private Zone GetAFakeZone()
        {
            List<Zone> zones = GetFakeZones().ToList();
            return zones.FirstOrDefault();
        }
    }
}
