﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAOB.VehicleImport;
using System.IO;
using System.Xml.Linq;

namespace VehicleImport
{
    public class VehicleImport : IVehicleImport
    {
        #region private fields
        string filePath = "";
        Dictionary<string, object> fields;
        #endregion

        #region interface methods

        public Dictionary<RequestedFieldType, string> RequestFields()
        {
            Dictionary<RequestedFieldType, string> fields = new Dictionary<RequestedFieldType, string>();
            fields.Add(RequestedFieldType.FilePath, "filePath");
            return fields;
        }

        public List<VehicleImportDTO> ObtainVehicles(Dictionary<string, object> fields)
        {
            List<VehicleImportDTO> vehicles = new List<VehicleImportDTO>();
            this.fields = fields;
            filePath = fields["filePath"].ToString();
            if (!CheckIfFileExists())
            {
                throw new Exception("No existe el archivo indicado.");
            }

            using (var xmlReader = new StreamReader(filePath))
            {
                var doc = XDocument.Load(xmlReader);
                XNamespace nonamespace = XNamespace.None;
                var xmlVehicles = doc.Descendants(nonamespace + "Vehicle");

                foreach (var item in xmlVehicles)
                {
                    var vehicle = new VehicleImportDTO
                    {
                        VIN = item.Element("VIN").Value,
                        Brand = item.Element("Brand").Value,
                        Model = item.Element("Model").Value,
                        Color = item.Element("Color").Value,
                        Year = int.Parse(item.Element("Year").Value),
                        Type = (VehicleType)(int.Parse(item.Element("Type").Value))
                    };

                    vehicles.Add(vehicle);
                }
            }
            return vehicles;
        }
        #endregion

        #region private methods
        private bool CheckIfFileExists()
        {

            return File.Exists(filePath);
        }

        #endregion


    }
}
