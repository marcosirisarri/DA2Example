﻿using DAOB.VehicleImport;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace VehicleImport
{
    public class VehicleImport : IVehicleImport
    {
        #region private fields
        string filePath = "";
        Dictionary<string, object> fields;
        #endregion

        #region interface methods

        public Dictionary<RequestedFieldType, string> RequestFields()
        {
            Dictionary<RequestedFieldType, string> fields = new Dictionary<RequestedFieldType, string>();
            fields.Add(RequestedFieldType.FilePath, "filePath");
            return fields;
        }

        public List<VehicleImportDTO> ObtainVehicles(Dictionary<string, object> fields)
        {
            List<VehicleImportDTO> vehicles = new List<VehicleImportDTO>();
            this.fields = fields;
            filePath = fields["filePath"].ToString();
            if (!CheckIfFileExists())
            {
                throw new Exception("No existe el archivo indicado.");
            }

            var jsonText = File.ReadAllText(filePath);
            vehicles = JsonConvert.DeserializeObject<List<VehicleImportDTO>>(jsonText);

            return vehicles;
        }
        #endregion

        #region private methods
        private bool CheckIfFileExists()
        {

            return File.Exists(filePath);
        }

        #endregion


    }
}

