"use strict";
var Vehicle = (function () {
    function Vehicle(id, vin, brand, model, color, year, state) {
        this.id = id;
        this.vin = vin;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.year = year;
        this.state = state;
        this.selected = false;
    }
    return Vehicle;
}());
exports.Vehicle = Vehicle;
//# sourceMappingURL=vehicle.js.map