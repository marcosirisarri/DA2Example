export class Vehicle {
    id: string;
    vin: string;
    brand: string;
    model: string;
    color: string;
    year: number;
    selected: boolean;
    state : number;

    constructor(id: string, vin: string, brand: string, model: string, color: string, year: number, state: number){
        this.id = id;
        this.vin = vin;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.year = year;
        this.state = state;
        this.selected = false;
    }
}