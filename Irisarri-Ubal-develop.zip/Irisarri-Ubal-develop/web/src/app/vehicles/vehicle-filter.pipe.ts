import { Pipe, PipeTransform} from '@angular/core';
import { Vehicle } from './vehicle';

@Pipe({
    name: 'vehicleFilter'
})
export class VehicleFilterPipe implements PipeTransform {

    transform(value:Array<Vehicle>, filterBy:string): Array<Vehicle> 
    {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        // usamos programacíon funcional (similar a las lambdas expressions en .NET)
        // esto se llama 'arrow syntax' (por la flechita :P)
        return filterBy ? value.filter((v:Vehicle) =>
        v.vin.toLocaleLowerCase().indexOf(filterBy) != -1) : value;
    }
}