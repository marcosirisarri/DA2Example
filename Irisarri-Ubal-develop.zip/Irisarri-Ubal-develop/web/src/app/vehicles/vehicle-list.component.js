"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var vehicle_service_1 = require("./vehicle.service");
var VehicleListComponent = (function () {
    function VehicleListComponent(_vehiclesService) {
        this._vehiclesService = _vehiclesService;
        this.pageTitle = "Vehicle List";
        this.listFilter = "";
        this.imageWidth = 100;
        this.imageMargin = 1;
        this.showSelectedField = false;
        this.vehicleSelectionChanged = new core_1.EventEmitter();
        // esta forma de escribir el parametro en el constructor lo que hace es:
        // 1) declara un parametro de tipo PetService en el constructor
        // 2) declara un atributo de clase privado llamado _petService
        // 3) asigna el valor del parámetro al atributo de la clase
    }
    VehicleListComponent.prototype.toggleImage = function () {
        //this.showImage = !this.showImage;
    };
    VehicleListComponent.prototype.ngOnInit = function () {
        console.log("aca obtengo datos del backend!");
        this.vehicles = this.vehicles == undefined ? this._vehiclesService.getVehicles() : this.vehicles;
    };
    VehicleListComponent.prototype.getSelectedVehicles = function () {
        var vehiclesIds = new Array();
        this.vehicles.forEach(function (x) { return x.selected == true ? vehiclesIds.push(x.id) : null; });
        return vehiclesIds;
    };
    VehicleListComponent.prototype.onClick = function () {
        this.vehicleSelectionChanged.emit(this.getSelectedVehicles());
    };
    return VehicleListComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], VehicleListComponent.prototype, "showSelectedField", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], VehicleListComponent.prototype, "vehicles", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", core_1.EventEmitter)
], VehicleListComponent.prototype, "vehicleSelectionChanged", void 0);
VehicleListComponent = __decorate([
    core_1.Component({
        selector: 'pm-vehicles',
        templateUrl: './vehicle-list.component.html',
        styleUrls: ['./vehicle-list.component.css']
    }),
    __metadata("design:paramtypes", [vehicle_service_1.VehicleService])
], VehicleListComponent);
exports.VehicleListComponent = VehicleListComponent;
//# sourceMappingURL=vehicle-list.component.js.map