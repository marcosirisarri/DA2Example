import { Injectable } from '@angular/core';
import { Vehicle } from './vehicle';
@Injectable()
export class VehicleService {
    
    // esto luego va a ser una llamada a nuestra api REST
    getVehicles(): Array<Vehicle> {
        return [
            new Vehicle("1","autoweb1","Fiat","Uno", "Blanco", 2005, 0),
            new Vehicle("2","autoweb2","Chevrolet","Onix", "Negro", 2015, 0),
            new Vehicle("3","autoweb3","Toyota","Corolla", "Gris", 2017, 1),
            new Vehicle("4","autoweb4","Chevrolet","Camaro", "Negro", 2017, 0)
        ];
    }

}