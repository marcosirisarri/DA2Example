import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Vehicle } from './vehicle';
import { VehicleService } from './vehicle.service';


@Component({
    selector: 'pm-vehicles',
    templateUrl: './vehicle-list.component.html',
    styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {
    pageTitle: string = "Vehicle List";
    listFilter: string = "";
    imageWidth: number = 100;
    imageMargin: number = 1;
    @Input() showSelectedField: boolean = false;
    @Input() vehicles: Array<Vehicle>;

    constructor(private _vehiclesService : VehicleService) {
     // esta forma de escribir el parametro en el constructor lo que hace es:
     // 1) declara un parametro de tipo PetService en el constructor
     // 2) declara un atributo de clase privado llamado _petService
     // 3) asigna el valor del parámetro al atributo de la clase
    }

    toggleImage(): void {
         //this.showImage = !this.showImage;
    }
    
    ngOnInit(): void {
        console.log("aca obtengo datos del backend!");
        this.vehicles = this.vehicles == undefined? this._vehiclesService.getVehicles() : this.vehicles;
    }

    getSelectedVehicles(): Array<string>{
        var vehiclesIds = new Array<string>();
        this.vehicles.forEach(x => x.selected == true? vehiclesIds.push(x.id): null);
        return vehiclesIds;
    }

    @Output() vehicleSelectionChanged: EventEmitter<Array<string>> = new EventEmitter<Array<string>>();

    onClick(): void {
        this.vehicleSelectionChanged.emit(this.getSelectedVehicles());
    }


}

