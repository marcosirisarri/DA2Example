"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var vehicle_1 = require("./vehicle");
var VehicleService = (function () {
    function VehicleService() {
    }
    // esto luego va a ser una llamada a nuestra api REST
    VehicleService.prototype.getVehicles = function () {
        return [
            new vehicle_1.Vehicle("1", "autoweb1", "Fiat", "Uno", "Blanco", 2005, 0),
            new vehicle_1.Vehicle("2", "autoweb2", "Chevrolet", "Onix", "Negro", 2015, 0),
            new vehicle_1.Vehicle("3", "autoweb3", "Toyota", "Corolla", "Gris", 2017, 1),
            new vehicle_1.Vehicle("4", "autoweb4", "Chevrolet", "Camaro", "Negro", 2017, 0)
        ];
    };
    return VehicleService;
}());
VehicleService = __decorate([
    core_1.Injectable()
], VehicleService);
exports.VehicleService = VehicleService;
//# sourceMappingURL=vehicle.service.js.map