"use strict";
var Lot = (function () {
    function Lot(id, name, description, carrierId, createdById, vehicles) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.carrierId = carrierId;
        this.createdById = createdById;
        this.vehicles = vehicles;
    }
    return Lot;
}());
exports.Lot = Lot;
//# sourceMappingURL=lot.js.map