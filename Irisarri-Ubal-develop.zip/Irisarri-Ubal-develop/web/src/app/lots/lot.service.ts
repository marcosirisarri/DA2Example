import { Injectable } from '@angular/core';
import { Lot } from './lot';
import { Vehicle } from '../vehicles/vehicle';

@Injectable()
export class LotService {
    
    // esto luego va a ser una llamada a nuestra api REST
    getLots(): Array<Lot> {
        return [
            new Lot("loteprueba1","Autos de china","Autitos chinos","", "", []),
            new Lot("loteprueba2","Lote Brasil","Autos con posibles fallas","", "", []),
        ];
    }

    getNewVehicles(): Array<Vehicle> {
        return [
            new Vehicle("2","autoweb2","Chevrolet","Onix", "Negro", 2015, 0),
            new Vehicle("4","autoweb4","Chevrolet","Camaro", "Negro", 2017, 0)
        ];
    }

    addLot(newLot : Lot) {
        //llamar al servicio y agregar  el lote
    }

}