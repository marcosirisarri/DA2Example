import { Component, OnInit } from '@angular/core';
import { Lot } from './lot';
import { Vehicle } from '../vehicles/vehicle';
import { LotService } from './lot.service';
import { VehicleListComponent} from '../vehicles/vehicle-list.component'


@Component({
    selector: 'pm-lotAdd',
    templateUrl: './lot-add.component.html',
    styleUrls: ['./lot-add.component.css'],
    
})
export class AddLotComponent implements OnInit {
    pageTitle: string = "Agregar lote";
    //listFilter: string = "";
    imageWidth: number = 100;
    imageMargin: number = 1;
    showImage: boolean = false;
    lots: Array<Lot>;
    newLot: Lot;
    vehicles : Array<Vehicle>;
    selectedVehicles : Array<string>;
    vehicleListRef : VehicleListComponent;
    lotService : LotService;

    constructor(private _lotsService : LotService) {
        this.newLot = new Lot("", "", "", "", "", []);
        this.vehicles = _lotsService.getNewVehicles();
        this.lotService = _lotsService;
        this.selectedVehicles = [];
     // esta forma de escribir el parametro en el constructor lo que hace es:
     // 1) declara un parametro de tipo PetService en el constructor
     // 2) declara un atributo de clase privado llamado _petService
     // 3) asigna el valor del parámetro al atributo de la clase
    }

    addLotHandler(): void {
        if (this.newLot.name ==""){
            alert("Debe ingresar un nombre");
            return;
        }
        if (this.selectedVehicles.values.length > 0){
            this.newLot.vehicles = this.selectedVehicles;
            //alert(this.newLot.vehicles.keys);
            this.lotService.addLot(this.newLot);
        }
    }
    
    ngOnInit(): void {
        console.log("aca obtengo datos del backend!");
        this.lots = this._lotsService.getLots();
    }

    onVehicleSelected(updatedList : Array<string>):void {
        console.log("cambio la lista de vehiculos seleccionados");
        this.selectedVehicles = updatedList;
    }
}
