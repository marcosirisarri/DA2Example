export class Lot {
    id: string;
    name: string;
    description: string;
    carrierId: string;
    createdById: string;
    vehicles: string[];

    constructor(id: string, name: string, description: string, carrierId: string, createdById: string, vehicles: string[]){
        this.id = id;
        this.name = name;
        this.description = description;
        this.carrierId = carrierId;
        this.createdById = createdById;
        this.vehicles = vehicles;
    }
}