USE DAOB
GO


delete from Users
delete from Permissions
delete from Roles


insert into Roles(Id, Name)
values('111ecccc-6fce-4b9f-a492-746c6c8a1bfa', 0)

insert into Permissions(Id,Name, Role_Id)
values('1aa1cccc-6fce-4b9f-a492-746c6c8a1bfa', 0, '111ecccc-6fce-4b9f-a492-746c6c8a1bfa')

insert into Users(Id,UserName,Password,FirstName,LastName,PhoneNumber,RoleId)
values('ddddcccc-6fce-4b9f-a492-746c6c8a1bfa', 'admin', 'pass', 'testadmin', 'user', '09090909', '111ecccc-6fce-4b9f-a492-746c6c8a1bfa')
